'use strict';
(function(root){
  const MAX_FILE_BYTES=8*1024*1024, SOURCE='http://www.spospk.ru/rasp.xlsx';
  const DAYS=['ПОНЕДЕЛЬНИК','ВТОРНИК','СРЕДА','ЧЕТВЕРГ','ПЯТНИЦА','СУББОТА'];
  const clean=s=>String(s||'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
  const nodes=(n,tag)=>Array.from(n.getElementsByTagNameNS('*',tag));
  const first=(n,tag)=>nodes(n,tag)[0]?.textContent||'';
  const key=(r,c)=>r*65536+c;
  const fail=s=>{throw new Error(s);};
  function address(s){
    const m=/^([A-Z]+)([1-9]\d*)$/.exec(s);
    if(!m)fail('Повреждён адрес ячейки.');
    let c=0;for(const ch of m[1])c=c*26+ch.charCodeAt(0)-64;
    const r=Number(m[2]);if(r>5000||c>1000)fail('Размеры таблицы не поддерживаются.');
    return [r,c];
  }
  function xml(bytes){
    if(!bytes)fail('В файле отсутствует часть таблицы.');
    const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
    if(/<!DOCTYPE|<!ENTITY/i.test(text))fail('Неподдерживаемая структура XML.');
    const Parser=root.DOMParser;
    const doc=new Parser({onError:(level,message)=>{if(level!=='warning')fail('Повреждён XML: '+message);}}).parseFromString(text,'application/xml');
    if(!doc||nodes(doc,'parsererror').length)fail('Повреждён XML в таблице.');
    return doc;
  }
  function validate(d){
    const text=s=>typeof s==='string'&&s.length<20000;
    if(!d||d.schema!==1||!Array.isArray(d.groups)||!d.groups.length||d.groups.length>1000||!Number.isFinite(d.fetchedAt))return false;
    const ids=new Set();
    for(const g of d.groups){
      if(!g||!text(g.id)||!g.id||ids.has(g.id)||!text(g.name)||!Array.isArray(g.aliases)||!g.aliases.length||!g.aliases.every(text)||!g.weeks)return false;
      ids.add(g.id);
      for(const parity of ['even','odd'])for(let day=0;day<7;day++){
        const lessons=g.weeks[parity]?.[day];
        if(!Array.isArray(lessons)||lessons.length>30)return false;
        for(const l of lessons){
          if(!l||!Number.isInteger(l.number)||l.number<1||l.number>9||!/^([01]\d|2[0-3]):[0-5]\d$/.test(l.start)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(l.end)||l.start>=l.end||!Array.isArray(l.variants)||!l.variants.length||l.variants.length>2)return false;
          for(const v of l.variants)if(!v||!text(v.subject)||!v.subject||!text(v.teacher)||!text(v.room)||![0,1,2].includes(v.subgroup))return false;
        }
      }
    }
    return Array.isArray(d.mondayNotes)&&d.mondayNotes.every(text);
  }
  function parse(input,fetchedAt=Date.now()){
    const bytes=input instanceof Uint8Array?input:new Uint8Array(input);
    if(bytes.length>MAX_FILE_BYTES)fail('Файл слишком большой. Максимум — 8 МБ.');
    if(bytes.length<22||bytes[0]!==80||bytes[1]!==75)fail('Это не файл XLSX. Скачайте таблицу расписания.');
    let entries=0,total=0;
    const zip=root.fflate||(typeof require==='function'?require('./vendor/fflate.js'):null);
    let files;
    try{files=zip.unzipSync(bytes,{filter(f){
      total+=f.originalSize;
      if(++entries>4000||!Number.isFinite(f.originalSize)||f.originalSize>32*1024*1024||total>64*1024*1024)fail('Слишком большой файл расписания.');
      return /^(xl\/(sharedStrings\.xml|workbook\.xml|_rels\/workbook\.xml\.rels|worksheets\/[^/]+\.xml)|docProps\/core\.xml)$/.test(f.name);
    }});}catch(e){fail('Не удалось прочитать XLSX. '+e.message);}
    const strings=files['xl/sharedStrings.xml']?nodes(xml(files['xl/sharedStrings.xml']),'si').map(n=>nodes(n,'t').map(t=>t.textContent).join('')):[];
    const workbook=xml(files['xl/workbook.xml']), rels=xml(files['xl/_rels/workbook.xml.rels']);
    const paths=new Map();
    for(const r of nodes(rels,'Relationship')){
      if(r.getAttribute('TargetMode')==='External')continue;
      const t=r.getAttribute('Target'),path=t.startsWith('/')?t.slice(1):'xl/'+t;
      if(/^xl\/worksheets\/[^/]+\.xml$/.test(path))paths.set(r.getAttribute('Id'),path);
    }
    let cells,merged,merges,maxRow,hs=[],sheetName='';
    const at=(r,c)=>merged.get(key(r,c))||cells.get(key(r,c));
    const value=(r,c)=>at(r,c)?.value||'';
    for(const sheet of nodes(workbook,'sheet')){
      const id=sheet.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
      const path=paths.get(id);if(!path||!files[path])continue;
      const doc=xml(files[path]);const cs=nodes(doc,'c');
      if(cs.length>150000)fail('Таблица слишком велика.');
      cells=new Map();merged=new Map();merges=[];maxRow=0;
      for(const e of cs){
        const [r,c]=address(e.getAttribute('r'));let v=first(e,'v');
        if(e.getAttribute('t')==='s'&&v){
          if(!/^\d+$/.test(v)||!Object.prototype.hasOwnProperty.call(strings,Number(v)))fail('Повреждена таблица строк.');
          v=strings[Number(v)];
        }else if(e.getAttribute('t')==='inlineStr')v=first(e,'is');
        v=clean(v);if(v)cells.set(key(r,c),{row:r,col:c,value:v});maxRow=Math.max(maxRow,r);
      }
      let covered=0;
      for(const e of nodes(doc,'mergeCell')){
        const parts=e.getAttribute('ref').split(':');if(parts.length!==2)continue;
        const [r1,c1]=address(parts[0]),[r2,c2]=address(parts[1]);
        if(r2<r1||c2<c1)fail('Некорректное объединение ячеек.');
        covered+=(r2-r1+1)*(c2-c1+1);if(covered>500000)fail('Слишком много объединённых ячеек.');
        const m={r1,c1,r2,c2};merges.push(m);const cell=cells.get(key(r1,c1));
        if(cell)for(let r=r1;r<=r2;r++)for(let c=c1;c<=c2;c++)merged.set(key(r,c),cell);
      }
      hs=[];for(let r=1;r<=maxRow;r++)if(value(r,4).toUpperCase()==='ГРУППА:')hs.push(r);
      if(hs.length>=2){sheetName=sheet.getAttribute('name');break;}
    }
    if(hs.length!==2)fail('Формат расписания изменился: не найдены два блока недель.');
    function parityBefore(header,lower){for(let r=header;r>lower;r--)for(let c=1;c<=20;c++){
      const s=value(r,c).toUpperCase().replace(/Ё/g,'Е');
      if(s.includes('НЕЧЕТНАЯ НЕДЕЛЯ'))return 'odd';if(s.includes('ЧЕТНАЯ НЕДЕЛЯ'))return 'even';
    }return '';}
    const parity=[parityBefore(hs[0],0),parityBefore(hs[1],hs[0])];
    if(!parity[0]&&parity[1])parity[0]=parity[1]==='even'?'odd':'even';
    if(!parity[1]&&parity[0])parity[1]=parity[0]==='even'?'odd':'even';
    if(!parity[0]||parity[0]===parity[1])fail('Не удалось определить чётность блоков расписания.');
    const evenHeader=hs[parity[0]==='even'?0:1];
    const ranges=merges.filter(m=>m.r1===hs[0]&&m.r2===m.r1&&m.c1>=6&&m.c2-m.c1===3&&value(m.r1,m.c1)).sort((a,b)=>a.c1-b.c1);
    if(!ranges.length)fail('Не найдены группы в таблице.');
    const normalized=s=>s.replace(/ /g,'').toUpperCase().replace(/(^|\/)[ДD]/g,'$1');
    const ids=new Set(),groups=[];let lessonCount=0;
    for(const gr of ranges){
      const firstName=value(hs[0],gr.c1),name=value(evenHeader,gr.c1),secondName=value(hs[1],gr.c1);
      if(!name||normalized(firstName)!==normalized(secondName))fail('Группы расположены по-разному в блоках недель.');
      if(ids.has(name))fail('В заголовке повторяется группа.');ids.add(name);
      if(!merges.some(m=>m.r1===hs[1]&&m.r2===m.r1&&m.c1===gr.c1&&m.c2===gr.c2))fail('Изменилась структура столбцов групп.');
      const aliases=[name];if(name!==firstName)aliases.push(firstName);const weeks={};
      for(let block=0;block<2;block++){
        const days=Object.fromEntries(Array.from({length:7},(_,i)=>[i,[]]));
        let day=-1,seenDays=0;const end=block===0?hs[1]:maxRow+1;
        for(let r=hs[block]+1;r<end;r++){
          const dayCell=cells.get(key(r,1));if(dayCell){const d=DAYS.indexOf(dayCell.value.toUpperCase());if(d>=0){day=d;seenDays++;}}
          const num=cells.get(key(r,2));if(day<0||!num||!/[1-9]/.test(num.value)||num.value.length!==1)continue;
          const time=/^(\d{1,2})[.:](\d{2})\s*[-–—]\s*(\d{1,2})[.:](\d{2})$/.exec(value(r,4));
          if(!time)fail('Не удалось прочитать время пары в строке '+r+'.');
          const start=time[1].padStart(2,'0')+':'+time[2],finish=time[3].padStart(2,'0')+':'+time[4];
          const variants=[];let previous=null;
          for(let sg=1;sg<=2;sg++){
            const c=gr.c1+(sg-1)*2,subject=at(r,c);if(!subject?.value)continue;
            if(previous===subject){variants[variants.length-1].subgroup=0;continue;}
            let room=at(r,c+1);if(room===subject)room=at(r,gr.c2);if(room===subject)room=null;
            variants.push({subject:subject.value,teacher:value(r+1,c),room:room?.value||'',subgroup:sg});previous=subject;
          }
          if(variants.length){days[day].push({number:Number(num.value),start,end:finish,variants,sourceRow:r});lessonCount++;}
        }
        if(seenDays!==6)fail('В расписании не найдены все шесть учебных дней.');weeks[parity[block]]=days;
      }
      groups.push({id:name,name,aliases,weeks});
    }
    if(lessonCount<10)fail('В загруженном файле слишком мало занятий.');
    const headerCells=Array.from(cells.values()).filter(c=>c.row<hs[0]).sort((a,b)=>a.row-b.row||a.col-b.col);
    const title=headerCells.find(c=>c.value.includes('учебных занятий'))?.value||'';
    const mondayNotes=[...new Set(headerCells.filter(c=>c.value.includes('ПОДНЯТИЕ ФЛАГА')||c.value.includes('РАЗГОВОРЫ О ВАЖНОМ')).map(c=>c.value))];
    const sourceModified=files['docProps/core.xml']?first(xml(files['docProps/core.xml']),'modified'):'';
    const result={schema:1,source:SOURCE,sheet:sheetName,title,sourceModified,fetchedAt,groups,mondayNotes,lessonCount};
    if(!validate(result))fail('В таблице есть неподдерживаемые данные.');return result;
  }
  const api={parse,validate,MAX_FILE_BYTES};root.SpkParser=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window==='undefined'?globalThis:window);
