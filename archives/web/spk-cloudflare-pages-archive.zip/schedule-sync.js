'use strict';
(function(root){
  const MIN_INTERVAL=60000, PERIOD=5*60000;
  function create(options){
    let pending=null,lastAttempt=-Infinity;
    const clock=options.now||Date.now,fetcher=options.fetch||root.fetch.bind(root);
    async function run(force){
      lastAttempt=clock();options.status({loading:true});
      const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),25000);
      try{
        const current=options.getData(),headers={Accept:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};
        if(current&&/^"[a-f0-9]{64}"$/.test(current.sourceETag||''))headers['If-None-Match']=current.sourceETag;
        const response=await fetcher('api/schedule'+(force?'?refresh=1':''),{headers,cache:'no-store',credentials:'same-origin',redirect:'follow',signal:controller.signal});
        if(response.redirected||response.status===401||response.status===403){const e=new Error('Для обновления нужно снова войти на сайт приложения.');e.auth=true;throw e;}
        if(response.status!==304&&!response.ok)throw new Error('Сайт колледжа сейчас недоступен. Обновление повторится автоматически.');
        const checkedAt=clock();let data,changed=false;
        if(response.status===304){
          if(!current||!options.validate(current))throw new Error('Не удалось проверить сохранённое расписание.');
          data={...current,checkedAt};
        }else{
          if(!/application\/(vnd\.openxmlformats-officedocument\.spreadsheetml\.sheet|octet-stream)/i.test(response.headers.get('content-type')||''))throw new Error('Вместо расписания пришёл другой файл. Попробуем позже.');
          if(Number(response.headers.get('content-length'))>8*1024*1024)throw new Error('Файл расписания слишком большой.');
          const bytes=await response.arrayBuffer();
          if(bytes.byteLength>8*1024*1024)throw new Error('Файл расписания слишком большой.');
          data=options.parse(bytes,checkedAt);if(!options.validate(data))throw new Error('Формат расписания изменился.');
          data.checkedAt=checkedAt;data.sourceETag=response.headers.get('etag')||'';data.automatic=true;changed=true;
        }
        await options.save(data);options.apply(data);
        options.status({loading:false,ok:true,changed,manual:force});
        return {ok:true,changed};
      }catch(e){
        const message=e.name==='AbortError'?'Сайт колледжа долго не отвечает. Попробуем позже.':e instanceof TypeError?'Нет соединения с сервером. Обновление повторится автоматически.':e.message;
        options.status({loading:false,error:message,auth:!!e.auth});return {ok:false,error:message};
      }finally{clearTimeout(timeout);}
    }
    return {check({force=false}={}){
      if(pending)return pending;
      if(!force&&clock()-lastAttempt<MIN_INTERVAL)return Promise.resolve({skipped:true});
      pending=run(force).finally(()=>{pending=null;});return pending;
    }};
  }
  const api={create,MIN_INTERVAL,PERIOD};root.SpkSync=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window==='undefined'?globalThis:window);
