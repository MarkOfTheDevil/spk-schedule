'use strict';
const webRuntime={offlineReady:false,offlineError:false,storageWarning:'',previousFocus:null,sync:null};
function offlineLabel(){return webRuntime.storageWarning|| (webRuntime.offlineReady?'Готово к работе без интернета':webRuntime.offlineError?'Офлайн-режим пока недоступен. Откройте приложение при подключённом интернете.':'Подготавливаем работу без интернета…');}
function installBanner(){return '<section class="settings-card install-card"><div class="install-mark">'+icon('screen')+'</div><div><h3>Приложение на iPhone</h3><p>Добавьте иконку на экран «Домой» через Safari.</p><button class="text-button" data-action="install">Как установить '+icon('arrow')+'</button></div></section>';}
function openWebDialog(id){webRuntime.previousFocus=document.activeElement;$(id).hidden=false;document.body.classList.add('modal-open');$(id).querySelector('button').focus();}
function closeWebDialogs(){if($('installModal').hidden)return false;$('installModal').hidden=true;document.body.classList.remove('modal-open');webRuntime.previousFocus?.focus({preventScroll:true});return true;}
function checkSchedule(force=false){return webRuntime.sync?.check({force});}
function setupWebControls(){
  document.addEventListener('click',e=>{
    if(e.target.closest('[data-web-close]'))closeWebDialogs();
    if(e.target.closest('[data-action="install"]'))openWebDialog('installModal');
  });
  document.addEventListener('keydown',e=>{
    const dialog=$('installModal');if(dialog.hidden)return;
    if(e.key==='Escape'){closeWebDialogs();e.preventDefault();}
    if(e.key==='Tab'){
      const controls=dialog.querySelectorAll('button:not([disabled]),a[href]'),a=controls[0],z=controls[controls.length-1];
      if(e.shiftKey&&document.activeElement===a){z.focus();e.preventDefault();}else if(!e.shiftKey&&document.activeElement===z){a.focus();e.preventDefault();}
    }
  });
  window.addEventListener('pageshow',()=>window.onAppResume());
  window.addEventListener('online',()=>checkSchedule(true));
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)window.onAppResume();});
  setInterval(()=>{if(!document.hidden)checkSchedule();},SpkSync.PERIOD);
}
async function prepareOffline(){
  if(!('serviceWorker' in navigator)||!window.isSecureContext){webRuntime.offlineError=true;render();return;}
  try{
    let controlled=!!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange',()=>{if(controlled)location.reload();controlled=true;});
    await navigator.serviceWorker.register('sw.js',{scope:'./',updateViaCache:'none'});
    await navigator.serviceWorker.ready;webRuntime.offlineReady=true;render();
  }catch(_){webRuntime.offlineError=true;render();}
}
async function bootWebApp(){
  setupWebControls();
  try{
    let data=await SpkStore.load();
    if(!data){
      const response=await fetch('schedule.json');if(!response.ok)throw new Error('Сохранённой копии пока нет.');
      data=await response.json();if(!SpkParser.validate(data))throw new Error('Сохранённая копия недоступна.');
      try{await SpkStore.save(data);}catch(e){webRuntime.storageWarning=e.message;}
    }
    window.onScheduleData(data);
  }catch(e){state.error=e.message;setStatus();}
  webRuntime.sync=SpkSync.create({
    getData:()=>state.data,parse:SpkParser.parse,validate:SpkParser.validate,save:SpkStore.save,
    apply(data){webRuntime.storageWarning='';window.onScheduleData(data);},
    status(result){
      state.loading=result.loading;state.error=result.error||'';
      if(result.error&&state.data)state.error+=' Показываем сохранённое расписание.';
      setStatus();
      if(result.ok&&result.manual)toast(result.changed?'Расписание обновлено':'У вас актуальное расписание');
    }
  });
  checkSchedule();
  prepareOffline();
}
