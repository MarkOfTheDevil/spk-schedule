const SOURCE='http://www.spospk.ru/rasp.xlsx';
const MAX_BYTES=8*1024*1024;
const MIME='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const BASE_HEADERS={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};

async function boundedBytes(response){
  if(Number(response.headers.get('content-length'))>MAX_BYTES)throw new Error('too_large');
  if(!response.body)throw new Error('empty_body');
  const reader=response.body.getReader(),chunks=[];let length=0;
  try{
    while(true){const {done,value}=await reader.read();if(done)break;length+=value.byteLength;if(length>MAX_BYTES){await reader.cancel();throw new Error('too_large');}chunks.push(value);}
  }finally{reader.releaseLock();}
  const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  if(bytes.length<22||bytes[0]!==80||bytes[1]!==75||bytes[2]!==3||bytes[3]!==4)throw new Error('not_xlsx');
  return bytes;
}

function deliver(response,request){
  const headers=new Headers(response.headers);for(const [k,v] of Object.entries(BASE_HEADERS))headers.set(k,v);
  if(request.headers.get('if-none-match')===headers.get('etag')){
    headers.delete('content-length');headers.delete('content-type');
    return new Response(null,{status:304,headers});
  }
  return new Response(response.body,{headers});
}

async function getSchedule(request,options={}){
  if(request.method!=='GET')return new Response(null,{status:405,headers:{...BASE_HEADERS,Allow:'GET'}});
  const fetcher=options.fetch||globalThis.fetch;
  const cache=options.cache===undefined?globalThis.caches?.default:options.cache;
  const now=options.now||Date.now;
  const cacheKey=new Request(new URL('/__spk_schedule_source_v1',request.url));
  const force=new URL(request.url).searchParams.get('refresh')==='1';
  if(!force&&cache){try{const found=await cache.match(cacheKey);if(found)return deliver(found,request);}catch(_){}}
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),options.timeoutMs||18000);
  try{
    const upstream=await fetcher(SOURCE,{signal:controller.signal,redirect:'error',cache:'no-store',headers:{Accept:MIME+', application/octet-stream;q=0.9'}});
    if(!upstream.ok)throw new Error('upstream_'+upstream.status);
    const bytes=await boundedBytes(upstream);
    const digest=await crypto.subtle.digest('SHA-256',bytes);
    const etag='"'+Array.from(new Uint8Array(digest),v=>v.toString(16).padStart(2,'0')).join('')+'"';
    const headers={'Content-Type':MIME,'Cache-Control':'public, max-age=60',ETag:etag,'X-Schedule-Checked-At':String(now()),'X-Content-Type-Options':'nosniff'};
    const modified=upstream.headers.get('last-modified');if(modified)headers['Last-Modified']=modified;
    const response=new Response(bytes,{headers});
    if(cache){try{await cache.put(cacheKey,response.clone());}catch(_){}}
    return deliver(response,request);
  }catch(_){
    return Response.json({error:'Расписание с сайта колледжа сейчас недоступно. Попробуем обновить его позже.'},{status:502,headers:BASE_HEADERS});
  }finally{clearTimeout(timer);}
}

export default {
  async fetch(request, env) {
    const pathname=new URL(request.url).pathname;
    if(pathname==='/api/schedule')return getSchedule(request);
    if(pathname.startsWith('/api/'))return new Response('Not found',{status:404,headers:{'Cache-Control':'no-store'}});
    return env.ASSETS.fetch(request);
  }
};
