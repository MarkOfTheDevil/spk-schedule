'use strict';
const CACHE='spk-iphone-2f74a691dea1326b';
const FILES=['./','index.html','app.js','app.css','teachers.js','palettes.js','palettes.css','web.js','schedule-sync.js','store.js','parser.js','vendor/fflate.js','schedule.json','manifest.webmanifest','icons/apple-touch-icon.png','icons/icon-192.png','icons/icon-512.png'];
const URLS=FILES.map(p=>new URL(p,self.registration.scope).href);
self.addEventListener('install',event=>event.waitUntil((async()=>{
  const cache=await caches.open(CACHE);
  try{await Promise.all(URLS.map(async url=>{
    const response=await fetch(new Request(url,{cache:'reload',credentials:'same-origin'}));
    if(!response.ok||response.redirected)throw new Error('App asset unavailable');
    await cache.put(url,response);
  }));await self.skipWaiting();}catch(e){await caches.delete(CACHE);throw e;}
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
  for(const name of await caches.keys())if(name.startsWith('spk-iphone-')&&name!==CACHE)await caches.delete(name);
  await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
  const request=event.request,url=new URL(request.url);
  if(request.method!=='GET'||url.origin!==self.location.origin)return;
  const navigation=request.mode==='navigate'&&(url.pathname===new URL('./',self.registration.scope).pathname||url.pathname===new URL('index.html',self.registration.scope).pathname);
  const asset=URLS.includes(url.href);if(!asset&&!navigation)return;
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE),cached=await cache.match(navigation?new URL('./',self.registration.scope).href:request);
    return cached||fetch(request);
  })());
});
