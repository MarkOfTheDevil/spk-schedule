package ru.spk.schedule;

/** One refresh attempt must finish before either a fresh or cached reminder is sent. */
public final class ReminderDelivery {
    public interface Update { void run() throws Exception; }
    public interface Sender { boolean send(boolean refreshed) throws Exception; }
    public interface Active { boolean get(); }
    public static final class Result {
        public final boolean refreshed,delivered;
        Result(boolean fresh,boolean sent){refreshed=fresh;delivered=sent;}
    }
    public static Result run(Update update,Sender sender,Active active) throws Exception {
        if(!active.get()||Thread.currentThread().isInterrupted())return new Result(false,false);
        boolean fresh=false;
        try{update.run();fresh=true;}catch(Exception ignored){}
        if(!active.get()||Thread.currentThread().isInterrupted())return new Result(fresh,false);
        return new Result(fresh,sender.send(fresh));
    }
}
