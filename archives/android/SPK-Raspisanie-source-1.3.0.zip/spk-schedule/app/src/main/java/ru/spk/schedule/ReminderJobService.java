package ru.spk.schedule;

import android.app.job.*;
import android.content.*;
import android.os.*;

/** Download first, then notify; the OS owns the job while the UI is closed. */
public final class ReminderJobService extends JobService {
    public static final int JOB_ID=2003;
    private static final class Run {volatile boolean stopped;Thread thread;}
    private Run active;
    public static boolean enqueue(Context c,String target){
        PersistableBundle extras=new PersistableBundle();extras.putString("targetDate",target);
        ComponentName component=new ComponentName(c,ReminderJobService.class);
        JobScheduler jobs=c.getSystemService(JobScheduler.class);
        if(Build.VERSION.SDK_INT>=31){
            try{JobInfo fast=new JobInfo.Builder(JOB_ID,component).setExtras(extras).setExpedited(true).build();if(jobs.schedule(fast)==JobScheduler.RESULT_SUCCESS)return true;}catch(RuntimeException ignored){}
        }
        try{return jobs.schedule(new JobInfo.Builder(JOB_ID,component).setExtras(extras).setOverrideDeadline(0).build())==JobScheduler.RESULT_SUCCESS;}catch(RuntimeException e){return false;}
    }
    @Override public boolean onStartJob(final JobParameters params){
        if(!ReminderScheduler.prefs(this).getBoolean("enabled",false)||!ReminderScheduler.allowed(this))return false;
        final Run run=new Run();active=run;final Context c=getApplicationContext();
        run.thread=new Thread(new Runnable(){public void run(){
            try{
                ReminderDelivery.run(
                    new ReminderDelivery.Update(){public void run() throws Exception{ScheduleRepository.refresh(c);}},
                    new ReminderDelivery.Sender(){public boolean send(boolean fresh) throws Exception{return ReminderScheduler.deliver(c,params.getExtras().getString("targetDate"),false,fresh);}},
                    new ReminderDelivery.Active(){public boolean get(){return !run.stopped&&ReminderScheduler.prefs(c).getBoolean("enabled",false)&&ReminderScheduler.allowed(c);}}
                );
            }catch(Exception e){android.util.Log.w("SPKReminder","Unable to prepare reminder",e);}
            finally{if(!run.stopped)jobFinished(params,false);}
        }},"spk-reminder-update");run.thread.start();return true;
    }
    @Override public boolean onStopJob(JobParameters params){
        Run run=active;if(run!=null){run.stopped=true;run.thread.interrupt();}
        return ReminderScheduler.prefs(this).getBoolean("enabled",false)&&ReminderScheduler.allowed(this);
    }
}
