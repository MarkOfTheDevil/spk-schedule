package ru.spk.schedule;

import android.app.Activity;
import android.os.*;
import android.content.*;
import android.content.res.Configuration;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.*;

public class MainActivity extends Activity {
    private static final String ORIGIN="https://schedule.local/";
    private WebView web;
    private volatile String snapshot="";
    private volatile boolean destroyed=false;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AtomicBoolean loading=new AtomicBoolean(false);
    private final AtomicBoolean testingReminder=new AtomicBoolean(false);
    private volatile boolean systemDark;
    private volatile String reminderOpen="";
    private boolean notificationPermissionPending;
    private static final int NOTIFICATION_PERMISSION=210;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        systemDark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
        notificationPermissionPending=state!=null&&state.getBoolean("notificationPermissionPending",false);
        rememberReminderIntent(getIntent());
        ReminderScheduler.channel(this);
        getWindow().setStatusBarColor(Color.rgb(246,248,250));
        getWindow().setNavigationBarColor(Color.rgb(246,248,250));
        if(Build.VERSION.SDK_INT>=23) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        try {snapshot=ScheduleRepository.cached(this);}catch(Exception ignored){}
        web=new WebView(this); web.setBackgroundColor(Color.rgb(246,248,250)); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false); s.setSupportZoom(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if(Build.VERSION.SDK_INT>=33)s.setAlgorithmicDarkeningAllowed(false);
        else if(Build.VERSION.SDK_INT>=29)s.setForceDark(WebSettings.FORCE_DARK_OFF);
        web.addJavascriptInterface(new Bridge(),"College");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v,String url) { return !url.equals(ORIGIN+"index.html"); }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest request) {
                Uri uri=request.getUrl(); String path=uri.getPath();
                if(!"https".equals(uri.getScheme()) || !"schedule.local".equals(uri.getHost())) return blocked();
                if(path==null) return blocked();
                String name=path.substring(1);
                if(!name.equals("index.html")&&!name.equals("app.js")&&!name.equals("teachers.js")&&!name.equals("palettes.js")&&!name.equals("app.css")&&!name.equals("palettes.css")&&!name.equals("schedule.json")) return blocked();
                try { return new WebResourceResponse(name.endsWith(".html")?"text/html":name.endsWith(".css")?"text/css":name.endsWith(".js")?"application/javascript":"application/json","UTF-8",getAssets().open(name)); } catch(Exception e) {return blocked();}
            }
            private WebResourceResponse blocked() { return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0])); }
        });
        web.loadUrl(ORIGIN+"index.html");
    }
    private void emit(final String method,final String json) { runOnUiThread(new Runnable() {public void run() {if(!destroyed&&web!=null)web.evaluateJavascript("typeof window."+method+"==='function'&&window."+method+"("+json+")",null);}}); }
    private void refresh() {
        if(!loading.compareAndSet(false,true)||destroyed) return;
        emit("onScheduleStatus","{\"loading\":true}");
        worker.execute(new Runnable() {public void run() {
            String result=null, error=null;
            try {
                String parsed=ScheduleRepository.refresh(MainActivity.this);
                snapshot=parsed;result=parsed;
            } catch(Exception e) {error=e instanceof SocketTimeoutException?"Сайт не ответил вовремя.":e instanceof UnknownHostException?"Нет соединения с сайтом колледжа.":e.getMessage();if(error==null)error="Не удалось обновить расписание.";}
            finally {loading.set(false);}
            if(result!=null) {emit("onScheduleData",result);emit("onScheduleStatus","{\"loading\":false,\"ok\":true}");}
            else emit("onScheduleStatus","{\"loading\":false,\"error\":"+ScheduleParser.Json.stringify(error)+"}");
        }});
    }
    public final class Bridge {
        @JavascriptInterface public String getSnapshot() {return snapshot;}
        @JavascriptInterface public boolean isSystemDark(){return systemDark;}
        @JavascriptInterface public String getReminderState(){return ReminderScheduler.state(MainActivity.this);}
        @JavascriptInterface public synchronized String consumeReminderOpen(){String s=reminderOpen;reminderOpen="";return s;}
        @JavascriptInterface public void saveReminderConfig(final String json){runOnUiThread(new Runnable(){public void run(){
            try{ReminderScheduler.saveConfig(MainActivity.this,json);emitReminderState(null);}catch(Exception e){emitReminderState("Не удалось сохранить настройки уведомлений.");}
        }});}
        @JavascriptInterface public void setRemindersEnabled(final boolean enabled){runOnUiThread(new Runnable(){public void run(){enableReminders(enabled);}});}
        @JavascriptInterface public void openNotificationSettings(){runOnUiThread(new Runnable(){public void run(){
            try{startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));}catch(ActivityNotFoundException e){emitReminderState("Откройте уведомления приложения в настройках Android.");}
        }});}
        @JavascriptInterface public void requestExactReminderTime(){runOnUiThread(new Runnable(){public void run(){
            if(Build.VERSION.SDK_INT>=31)try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(ActivityNotFoundException e){emitReminderState("Разрешение «Будильники и напоминания» доступно в настройках Android.");}
        }});}
        @JavascriptInterface public void testReminder(){
            if(!testingReminder.compareAndSet(false,true))return;
            worker.execute(new Runnable(){public void run(){
                try{
                    if(!ReminderScheduler.prefs(MainActivity.this).getBoolean("enabled",false)||!ReminderScheduler.allowed(MainActivity.this)){emit("onReminderTest",ScheduleParser.Json.stringify("Сначала включите уведомления и разрешите их в Android."));return;}
                    ReminderDelivery.Result result=ReminderDelivery.run(
                        new ReminderDelivery.Update(){public void run() throws Exception{String parsed=ScheduleRepository.refresh(MainActivity.this);snapshot=parsed;emit("onScheduleData",parsed);}},
                        new ReminderDelivery.Sender(){public boolean send(boolean fresh) throws Exception{return ReminderScheduler.deliver(MainActivity.this,null,true,fresh);}},
                        new ReminderDelivery.Active(){public boolean get(){return !destroyed&&ReminderScheduler.prefs(MainActivity.this).getBoolean("enabled",false)&&ReminderScheduler.allowed(MainActivity.this);}}
                    );
                    emit("onReminderTest",ScheduleParser.Json.stringify(result.delivered?(result.refreshed?"Расписание обновлено. Проверочное уведомление отправлено.":"Не удалось обновить. Уведомление отправлено по сохранённому расписанию."):"Уведомления выключены или запрещены в Android."));
                }catch(Exception e){emit("onReminderTest",ScheduleParser.Json.stringify("Не удалось подготовить уведомление. Обновите расписание и попробуйте снова."));}
                finally{testingReminder.set(false);}
            }});
        }
        @JavascriptInterface public void refreshSchedule() {refresh();}
        @JavascriptInterface public void theme(final boolean dark) {applySystemColors(dark,dark?"#10191f":"#f6f8fa");}
        @JavascriptInterface public void themeColors(final boolean dark,final String background) {applySystemColors(dark,background);}
        @JavascriptInterface public void openSource() {runOnUiThread(new Runnable(){public void run(){try {startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(ScheduleParser.SOURCE)));}catch(ActivityNotFoundException ignored){}}});}
    }
    private void applySystemColors(final boolean dark,final String background){runOnUiThread(new Runnable(){public void run(){
        if(destroyed||web==null)return;
        String valid=background!=null&&background.matches("#[0-9a-fA-F]{6}")?background:dark?"#10191f":"#f6f8fa";
        int color=Color.parseColor(valid);getWindow().setStatusBarColor(color);getWindow().setNavigationBarColor(color);
        int flags=0;if(!dark&&Build.VERSION.SDK_INT>=23)flags|=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;if(!dark&&Build.VERSION.SDK_INT>=26)flags|=View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);web.setBackgroundColor(color);
    }});}
    private void emitReminderState(String message){
        try{JSONObject s=new JSONObject(ReminderScheduler.state(this));if(message!=null)s.put("message",message);emit("onReminderState",s.toString());}catch(JSONException ignored){}
    }
    private void enableReminders(boolean enabled){
        if(!enabled){notificationPermissionPending=false;ReminderScheduler.enabled(this,false);emitReminderState(null);return;}
        if(ReminderScheduler.prefs(this).getString("group","").isEmpty()){emitReminderState("Сначала выберите группу для уведомлений.");return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            if(!notificationPermissionPending){notificationPermissionPending=true;requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION);}return;
        }
        if(ReminderScheduler.allowed(this)){ReminderScheduler.enabled(this,true);emitReminderState(null);}
        else emitReminderState("Уведомления приложения запрещены в Android. Разрешите их в системных настройках.");
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==NOTIFICATION_PERMISSION){boolean requested=notificationPermissionPending;notificationPermissionPending=false;
            boolean granted=grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED&&ReminderScheduler.allowed(this);
            ReminderScheduler.enabled(this,requested&&granted);
            emitReminderState(granted?null:"Уведомления не разрешены. Их можно включить в настройках Android.");
        }
    }
    private void rememberReminderIntent(Intent intent){
        if(intent==null||!intent.hasExtra("reminderDate"))return;
        try{JSONObject s=new JSONObject();s.put("date",intent.getStringExtra("reminderDate"));s.put("group",intent.getStringExtra("reminderGroup"));s.put("subgroup",intent.getIntExtra("reminderSubgroup",0));reminderOpen=s.toString();}catch(JSONException ignored){}
        intent.removeExtra("reminderDate");intent.removeExtra("reminderGroup");intent.removeExtra("reminderSubgroup");
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);rememberReminderIntent(intent);reloadSnapshot();emit("onNotificationOpen","null");}
    @Override public void onConfigurationChanged(Configuration configuration){
        super.onConfigurationChanged(configuration);systemDark=(configuration.uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;emit("onSystemThemeChanged",String.valueOf(systemDark));
    }
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putBoolean("notificationPermissionPending",notificationPermissionPending);}
    @Override public void onBackPressed() {if(web!=null)web.evaluateJavascript("window.handleBack ? window.handleBack() : false",new ValueCallback<String>(){public void onReceiveValue(String handled){if(!"true".equals(handled))MainActivity.this.finish();}});else super.onBackPressed();}
    private void reloadSnapshot(){try{String latest=ScheduleRepository.cached(this);if(!latest.equals(snapshot)){snapshot=latest;emit("onScheduleData",latest);}}catch(Exception ignored){}}
    @Override protected void onResume() {super.onResume();systemDark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
        ReminderScheduler.schedule(this,false);
        if(web!=null){reloadSnapshot();emit("onSystemThemeChanged",String.valueOf(systemDark));emitReminderState(null);emit("onAppResume","null");}
    }
    @Override protected void onDestroy() {destroyed=true;worker.shutdownNow();if(web!=null){web.removeJavascriptInterface("College");web.destroy();web=null;}super.onDestroy();}
}
