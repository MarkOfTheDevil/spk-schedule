package ru.spk.schedule;

import org.json.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.*;
import java.util.*;

/** Calendar and notification text rules, independent of Android lifecycle. */
public final class ReminderContent {
    public static final LocalDate DEFAULT_ANCHOR=LocalDate.of(2026,10,19);
    private static final Locale RU=new Locale("ru");
    public static boolean isEven(LocalDate date,LocalDate anchor,boolean anchorEven) {
        LocalDate week=date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate base=anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        return ChronoUnit.WEEKS.between(base,week)%2==0?anchorEven:!anchorEven;
    }
    public static ZonedDateTime nextTime(ZonedDateTime now,int hour,int minute) {
        LocalDate date=now.toLocalDate();
        ZonedDateTime next=date.atTime(hour,minute).atZone(now.getZone());
        if(!next.isAfter(now)) next=date.plusDays(1).atTime(hour,minute).atZone(now.getZone());
        return next;
    }
    public static LocalDate anchor(String date) {
        try{return LocalDate.parse(date);}catch(Exception e){return DEFAULT_ANCHOR;}
    }
    public static final class Summary {
        public String title,text,detail,week;
        public int count;
        public boolean groupFound;
    }
    public static Summary create(String json,String groupId,int subgroup,LocalDate target,LocalDate today,LocalDate anchor,boolean anchorEven,ZoneId zone) throws JSONException {
        Summary out=new Summary();
        boolean even=isEven(target,anchor,anchorEven);
        out.week=even?"Чётная неделя":"Нечётная неделя";
        String relative=target.equals(today.plusDays(1))?"Завтра":target.equals(today)?"Сегодня":target.format(DateTimeFormatter.ofPattern("d MMMM",RU));
        out.title=relative+" · "+groupId;
        JSONObject data=new JSONObject(json),group=null;JSONArray groups=data.getJSONArray("groups");
        for(int i=0;i<groups.length();i++) if(groupId.equals(groups.getJSONObject(i).optString("id"))) {group=groups.getJSONObject(i);break;}
        out.groupFound=group!=null;
        if(group==null){out.text="Группа не найдена в сохранённом расписании";out.detail="Откройте приложение и выберите группу для уведомлений.";return out;}
        JSONObject days=group.getJSONObject("weeks").getJSONObject(even?"even":"odd");
        JSONArray pairs=days.optJSONArray(String.valueOf(target.getDayOfWeek().getValue()-1));
        StringBuilder detail=new StringBuilder(target.format(DateTimeFormatter.ofPattern("EEEE, d MMMM",RU))).append(" · ").append(out.week.toLowerCase(RU));
        detail.append(subgroup==0?"\nВсе подгруппы":"\n"+subgroup+" подгруппа");
        String start="",end="";
        if(pairs!=null)for(int i=0;i<pairs.length();i++) {
            JSONObject pair=pairs.getJSONObject(i);JSONArray variants=pair.getJSONArray("variants");List<JSONObject> chosen=new ArrayList<JSONObject>();
            for(int j=0;j<variants.length();j++){JSONObject v=variants.getJSONObject(j);int sg=v.optInt("subgroup",0);if(subgroup==0||sg==0||sg==subgroup)chosen.add(v);}
            if(chosen.isEmpty())continue;
            out.count++;if(start.isEmpty())start=pair.getString("start");end=pair.getString("end");
            detail.append("\n\n").append(pair.getInt("number")).append(" пара · ").append(pair.getString("start")).append("–").append(end);
            for(JSONObject v:chosen){
                detail.append("\n").append(v.getString("subject"));
                String room=v.optString("room","");if(!room.isEmpty())detail.append(" · ").append(room.equalsIgnoreCase("онлайн")?"онлайн":"ауд. "+room);
                int sg=v.optInt("subgroup",0);if(subgroup==0&&sg!=0)detail.append(" · ").append(sg).append(" подгр.");
            }
        }
        if(out.count==0){out.text="Занятий нет";detail.append("\n\nВ основном расписании занятий на этот день не указано.");}
        else {int n=out.count;String suffix=n%10==1&&n%100!=11?" пара":n%10>=2&&n%10<=4&&(n%100<12||n%100>14)?" пары":" пар";out.text=n+suffix+" · "+start+"–"+end;}
        long fetched=data.optLong("fetchedAt",0);
        if(fetched>0)detail.append("\n\nСохранённое расписание от ").append(Instant.ofEpochMilli(fetched).atZone(zone).format(DateTimeFormatter.ofPattern("dd.MM, HH:mm",RU)));
        out.detail=detail.toString();return out;
    }
}
