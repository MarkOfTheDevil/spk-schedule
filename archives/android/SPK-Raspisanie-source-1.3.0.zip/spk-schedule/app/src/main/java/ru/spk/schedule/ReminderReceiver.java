package ru.spk.schedule;

import android.content.*;

public final class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,final Intent intent){
        final Context c=context.getApplicationContext();
        if(ReminderScheduler.ACTION.equals(intent.getAction())){
            if(!ReminderScheduler.prefs(c).getBoolean("enabled",false))return;
            if(ReminderJobService.enqueue(c,intent.getStringExtra("targetDate"))){ReminderScheduler.schedule(c,true);return;}
            final PendingResult pending=goAsync();
            new Thread(new Runnable(){public void run(){
                try{ReminderScheduler.deliver(c,intent.getStringExtra("targetDate"),false,false);}catch(Exception e){android.util.Log.w("SPKReminder","Unable to show reminder",e);}
                finally{try{ReminderScheduler.schedule(c,true);}finally{pending.finish();}}
            }},"spk-reminder").start();
        }else if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())||Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())||Intent.ACTION_TIME_CHANGED.equals(intent.getAction())||Intent.ACTION_TIMEZONE_CHANGED.equals(intent.getAction())||"android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED".equals(intent.getAction())){
            ReminderScheduler.channel(c);ReminderScheduler.schedule(c,true);
        }
    }
}
