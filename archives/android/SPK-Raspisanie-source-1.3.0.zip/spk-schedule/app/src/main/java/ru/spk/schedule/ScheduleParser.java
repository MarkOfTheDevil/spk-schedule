package ru.spk.schedule;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

/** Reader for the college's two-week OOXML timetable. No network or Android dependencies. */
public final class ScheduleParser {
    public static final String SOURCE = "http://www.spospk.ru/rasp.xlsx";
    private static final String[] DAYS = {"ПОНЕДЕЛЬНИК", "ВТОРНИК", "СРЕДА", "ЧЕТВЕРГ", "ПЯТНИЦА", "СУББОТА", "ВОСКРЕСЕНЬЕ"};
    private static final Pattern TIME = Pattern.compile("(\\d{1,2})[.:](\\d{2})\\s*[-–—]\\s*(\\d{1,2})[.:](\\d{2})");
    private static final int MAX_XML = 32 * 1024 * 1024;
    private final Map<String, byte[]> files = new HashMap<String, byte[]>();
    private final Map<Long, Cell> cells = new HashMap<Long, Cell>();
    private final Map<Long, Cell> merged = new HashMap<Long, Cell>();
    private final List<Merge> merges = new ArrayList<Merge>();
    private final List<String> strings = new ArrayList<String>();
    private int maxRow;

    private static final class Cell {
        int row, col; String value;
        Cell(int r, int c, String v) { row=r; col=c; value=v; }
    }
    private static final class Merge { int r1,c1,r2,c2; }
    private static long key(int r,int c) { return ((long)r << 16) | c; }
    private Cell at(int r,int c) { Cell m=merged.get(key(r,c)); return m!=null ? m : cells.get(key(r,c)); }
    private String value(int r,int c) { Cell x=at(r,c); return x==null ? "" : x.value; }
    private static String clean(String s) { return s==null ? "" : s.replace('\u00a0',' ').replaceAll("\\s+"," ").trim(); }
    private static String normalizedGroup(String s) { return s.replace(" ","").toUpperCase(new Locale("ru")).replaceAll("(^|/)[ДD]","$1"); }
    private static int[] address(String s) {
        int c=0,r=0;
        for(char ch:s.toCharArray()) { if(ch>='A'&&ch<='Z') c=c*26+ch-'A'+1; else if(ch>='0'&&ch<='9') r=r*10+ch-'0'; }
        return new int[]{r,c};
    }
    private static Map<String,Object> map(Object... values) {
        Map<String,Object> m=new LinkedHashMap<String,Object>();
        for(int i=0;i<values.length;i+=2) m.put((String)values[i],values[i+1]);
        return m;
    }
    private static Document xml(byte[] bytes) throws Exception {
        if(bytes==null) throw new IOException("В файле отсутствует часть таблицы.");
        String text=new String(bytes,StandardCharsets.UTF_8);
        if(text.toUpperCase(Locale.ROOT).contains("<!DOCTYPE") || text.toUpperCase(Locale.ROOT).contains("<!ENTITY"))
            throw new IOException("Неподдерживаемая структура XML.");
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true); f.setExpandEntityReferences(false);
        try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true); } catch(Exception ignored) { }
        DocumentBuilder builder=f.newDocumentBuilder();
        builder.setEntityResolver(new org.xml.sax.EntityResolver() {
            public org.xml.sax.InputSource resolveEntity(String publicId,String systemId) throws org.xml.sax.SAXException {
                throw new org.xml.sax.SAXException("Внешние XML-ресурсы не поддерживаются.");
            }
        });
        return builder.parse(new ByteArrayInputStream(bytes));
    }
    private static NodeList nodes(Node n,String tag) {
        return n instanceof Document ? ((Document)n).getElementsByTagNameNS("*",tag) : ((Element)n).getElementsByTagNameNS("*",tag);
    }
    private static String first(Node n,String tag) { NodeList list=nodes(n,tag); return list.getLength()>0 ? list.item(0).getTextContent() : ""; }
    private void unzip(InputStream input) throws Exception {
        ZipInputStream z=new ZipInputStream(input); byte[] buf=new byte[16384]; int total=0,count=0;
        try {
            ZipEntry entry;
            while((entry=z.getNextEntry())!=null) {
                if(++count>4000) throw new IOException("Слишком много частей в файле.");
                String n=entry.getName();
                boolean wanted=n.equals("xl/sharedStrings.xml") || n.equals("xl/workbook.xml") || n.equals("xl/_rels/workbook.xml.rels") || n.startsWith("xl/worksheets/sheet")&&n.endsWith(".xml") || n.equals("docProps/core.xml");
                ByteArrayOutputStream out=wanted ? new ByteArrayOutputStream() : null;
                int size=0,read;
                while((read=z.read(buf))!=-1) {
                    size+=read; total+=read;
                    if(size>MAX_XML || total>64*1024*1024) throw new IOException("Слишком большой файл расписания.");
                    if(out!=null) out.write(buf,0,read);
                }
                if(out!=null) files.put(n,out.toByteArray());
            }
        } finally { z.close(); }
        if(!files.containsKey("xl/workbook.xml")) throw new IOException("Сайт вернул не файл XLSX.");
    }
    private void readSheet(String path) throws Exception {
        cells.clear(); merged.clear(); merges.clear(); maxRow=0;
        Document doc=xml(files.get(path)); NodeList list=nodes(doc,"c");
        if(list.getLength()>150000) throw new IOException("Таблица слишком велика.");
        for(int i=0;i<list.getLength();i++) {
            Element e=(Element)list.item(i); int[] p=address(e.getAttribute("r"));
            if(p[0]>5000 || p[1]>1000) throw new IOException("Размеры таблицы не поддерживаются.");
            String t=e.getAttribute("t"), v=first(e,"v");
            if(t.equals("s")&&!v.isEmpty()) { int idx=Integer.parseInt(v); if(idx<0||idx>=strings.size()) throw new IOException("Повреждена таблица строк."); v=strings.get(idx); }
            else if(t.equals("inlineStr")) v=first(e,"is");
            v=clean(v);
            if(!v.isEmpty()) cells.put(key(p[0],p[1]),new Cell(p[0],p[1],v));
            maxRow=Math.max(maxRow,p[0]);
        }
        NodeList ms=nodes(doc,"mergeCell"); long covered=0;
        for(int i=0;i<ms.getLength();i++) {
            String[] parts=((Element)ms.item(i)).getAttribute("ref").split(":");
            if(parts.length!=2) continue;
            int[] a=address(parts[0]),b=address(parts[1]); Merge m=new Merge(); m.r1=a[0];m.c1=a[1];m.r2=b[0];m.c2=b[1];
            covered+=(long)(m.r2-m.r1+1)*(m.c2-m.c1+1);
            if(covered>500000 || m.r2>5000 || m.c2>1000) throw new IOException("Слишком много объединённых ячеек.");
            merges.add(m); Cell c=cells.get(key(m.r1,m.c1));
            if(c!=null) for(int r=m.r1;r<=m.r2;r++) for(int col=m.c1;col<=m.c2;col++) merged.put(key(r,col),c);
        }
    }
    private List<Integer> headers() {
        List<Integer> h=new ArrayList<Integer>();
        for(int r=1;r<=maxRow;r++) if(value(r,4).equalsIgnoreCase("Группа:")) h.add(r);
        return h;
    }
    private String parityBefore(int header,int lower) {
        for(int r=header;r>lower;r--) for(int c=1;c<=20;c++) {
            String s=value(r,c).toUpperCase(new Locale("ru")).replace('Ё','Е');
            if(s.contains("НЕЧЕТНАЯ НЕДЕЛЯ")) return "odd";
            if(s.contains("ЧЕТНАЯ НЕДЕЛЯ")) return "even";
        }
        return "";
    }
    public static String parse(InputStream in,long fetchedAt) throws Exception { return new ScheduleParser().load(in,fetchedAt); }
    @SuppressWarnings("unchecked")
    private String load(InputStream in,long fetchedAt) throws Exception {
        unzip(in);
        if(files.containsKey("xl/sharedStrings.xml")) {
            NodeList list=nodes(xml(files.get("xl/sharedStrings.xml")),"si");
            for(int i=0;i<list.getLength();i++) {
                NodeList ts=nodes(list.item(i),"t"); StringBuilder s=new StringBuilder();
                for(int j=0;j<ts.getLength();j++) s.append(ts.item(j).getTextContent());
                strings.add(s.toString());
            }
        }
        Document workbook=xml(files.get("xl/workbook.xml"));
        Map<String,String> paths=new HashMap<String,String>();
        NodeList rels=nodes(xml(files.get("xl/_rels/workbook.xml.rels")),"Relationship");
        for(int i=0;i<rels.getLength();i++) { Element r=(Element)rels.item(i); String target=r.getAttribute("Target"); paths.put(r.getAttribute("Id"),target.startsWith("/")?target.substring(1):"xl/"+target); }
        NodeList sheets=nodes(workbook,"sheet"); List<Integer> hs=null; String sheetName="";
        for(int i=0;i<sheets.getLength();i++) {
            Element s=(Element)sheets.item(i); String id=s.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id");
            String path=paths.get(id); if(path==null||!files.containsKey(path)) continue;
            readSheet(path); hs=headers(); if(hs.size()>=2) { sheetName=s.getAttribute("name"); break; }
        }
        if(hs==null||hs.size()!=2) throw new IOException("Формат расписания изменился: не найдены два блока недель. Сохранённая версия оставлена.");
        String[] parity={parityBefore(hs.get(0),0),parityBefore(hs.get(1),hs.get(0))};
        if(parity[0].isEmpty()&&!parity[1].isEmpty()) parity[0]=parity[1].equals("even")?"odd":"even";
        if(parity[1].isEmpty()&&!parity[0].isEmpty()) parity[1]=parity[0].equals("even")?"odd":"even";
        if(parity[0].isEmpty()||parity[1].isEmpty()||parity[0].equals(parity[1])) throw new IOException("Не удалось определить чётность блоков расписания.");
        int evenHeader=hs.get(parity[0].equals("even")?0:1);
        List<Merge> groupRanges=new ArrayList<Merge>();
        for(Merge m:merges) if(m.r1==hs.get(0)&&m.r2==m.r1&&m.c1>=6&&m.c2-m.c1==3&&!value(m.r1,m.c1).isEmpty()) groupRanges.add(m);
        Collections.sort(groupRanges,new Comparator<Merge>() { public int compare(Merge a,Merge b) {return a.c1-b.c1;} });
        if(groupRanges.isEmpty()) throw new IOException("Не найдены группы в таблице.");
        List<Object> groups=new ArrayList<Object>(); Set<String> groupIds=new HashSet<String>(); int totalLessons=0;
        for(Merge gr:groupRanges) {
            String oddName=value(hs.get(0),gr.c1), evenName=value(evenHeader,gr.c1);
            if(evenName.isEmpty()) throw new IOException("Не совпадают столбцы групп между неделями.");
            if(!normalizedGroup(oddName).equals(normalizedGroup(evenName))) throw new IOException("Группы расположены по-разному в блоках недель.");
            if(!groupIds.add(evenName)) throw new IOException("В заголовке повторяется группа: "+evenName);
            // Pair columns by their 4-cell merged header; names may contain a source typo.
            boolean matching=false;
            for(Merge m:merges) if(m.r1==hs.get(1)&&m.r2==m.r1&&m.c1==gr.c1&&m.c2==gr.c2) { matching=true;break; }
            if(!matching) throw new IOException("Изменилась структура столбцов групп.");
            List<String> aliases=new ArrayList<String>(); aliases.add(evenName); if(!evenName.equals(oddName)) aliases.add(oddName);
            Map<String,Object> weeks=new LinkedHashMap<String,Object>();
            for(int block=0;block<2;block++) {
                Map<String,Object> days=new LinkedHashMap<String,Object>(); for(int d=0;d<7;d++) days.put(String.valueOf(d),new ArrayList<Object>());
                int day=-1, seenDays=0, end=block+1<hs.size()?hs.get(block+1):maxRow+1;
                for(int r=hs.get(block)+1;r<end;r++) {
                    Cell dayCell=cells.get(key(r,1));
                    if(dayCell!=null) for(int d=0;d<DAYS.length;d++) if(dayCell.value.equalsIgnoreCase(DAYS[d])) {day=d;seenDays++;}
                    Cell num=cells.get(key(r,2));
                    if(day<0||num==null||!num.value.matches("[1-9]")) continue;
                    Matcher time=TIME.matcher(value(r,4));
                    if(!time.matches()) throw new IOException("Не удалось прочитать время пары в строке "+r+".");
                    String start=String.format(Locale.ROOT,"%02d:%s",Integer.parseInt(time.group(1)),time.group(2));
                    String finish=String.format(Locale.ROOT,"%02d:%s",Integer.parseInt(time.group(3)),time.group(4));
                    List<Object> variants=new ArrayList<Object>(); Cell previous=null;
                    for(int sg=1;sg<=2;sg++) {
                        int c=gr.c1+(sg-1)*2; Cell subject=at(r,c);
                        if(subject==null||subject.value.isEmpty()) continue;
                        if(previous==subject) { ((Map<String,Object>)variants.get(variants.size()-1)).put("subgroup",0); continue; }
                        Cell room=at(r,c+1);
                        if(room==subject) room=at(r,gr.c2);
                        if(room==subject) room=null;
                        String teacher=value(r+1,c);
                        variants.add(map("subject",subject.value,"teacher",teacher,"room",room==null?"":room.value,"subgroup",sg));
                        previous=subject;
                    }
                    if(!variants.isEmpty()) {
                        ((List<Object>)days.get(String.valueOf(day))).add(map("number",Integer.parseInt(num.value),"start",start,"end",finish,"variants",variants,"sourceRow",r)); totalLessons++;
                    }
                }
                if(seenDays!=6) throw new IOException("В расписании не найдены все шесть учебных дней.");
                weeks.put(parity[block],days);
            }
            groups.add(map("id",evenName,"name",evenName,"aliases",aliases,"weeks",weeks));
        }
        if(totalLessons<10) throw new IOException("В загруженном файле слишком мало занятий.");
        String title=""; for(Cell c:cells.values()) if(c.row<hs.get(0)&&c.value.contains("учебных занятий")) {title=c.value;break;}
        String modified="";
        if(files.containsKey("docProps/core.xml")) modified=first(xml(files.get("docProps/core.xml")),"modified");
        List<String> mondayNotes=new ArrayList<String>();
        for(int r=1;r<hs.get(0);r++) for(int c=1;c<=1000;c++) {
            Cell note=cells.get(key(r,c));
            if(note!=null && (note.value.contains("ПОДНЯТИЕ ФЛАГА") || note.value.contains("РАЗГОВОРЫ О ВАЖНОМ")) && !mondayNotes.contains(note.value)) mondayNotes.add(note.value);
        }
        return Json.stringify(map("schema",1,"source",SOURCE,"sheet",sheetName,"title",title,"sourceModified",modified,"fetchedAt",fetchedAt,"groups",groups,"mondayNotes",mondayNotes,"lessonCount",totalLessons));
    }
    public static final class Json {
        public static String stringify(Object v) {
            if(v==null) return "null";
            if(v instanceof String) {
                StringBuilder s=new StringBuilder("\"");
                for(char c:((String)v).toCharArray()) {
                    if(c=='"'||c=='\\') s.append('\\').append(c);
                    else if(c<32 || c=='\u2028' || c=='\u2029') s.append(String.format(Locale.ROOT,"\\u%04x",(int)c));
                    else s.append(c);
                }
                return s.append('"').toString();
            }
            if(v instanceof Map) { StringBuilder s=new StringBuilder("{"); boolean first=true; for(Object item:((Map<?,?>)v).entrySet()) { Map.Entry<?,?> e=(Map.Entry<?,?>)item; if(!first)s.append(',');first=false;s.append(stringify(e.getKey().toString())).append(':').append(stringify(e.getValue())); } return s.append('}').toString(); }
            if(v instanceof Iterable) { StringBuilder s=new StringBuilder("["); boolean first=true; for(Object item:(Iterable<?>)v) {if(!first)s.append(',');first=false;s.append(stringify(item));} return s.append(']').toString(); }
            return v.toString();
        }
    }
}
