package ru.spk.schedule;

import android.content.Context;
import android.util.AtomicFile;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** Shared by the visible app and background reminder jobs. */
public final class ScheduleRepository {
    private static final Object REFRESH_LOCK=new Object(),CACHE_LOCK=new Object();
    private static AtomicFile cache(Context c){return new AtomicFile(new File(c.getFilesDir(),"schedule.json"));}
    public static String cached(Context c) throws IOException {
        synchronized(CACHE_LOCK){try{return new String(cache(c).readFully(),StandardCharsets.UTF_8);}catch(IOException ignored){}}
        InputStream in=c.getAssets().open("schedule.json");try{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);return new String(out.toByteArray(),StandardCharsets.UTF_8);}finally{in.close();}
    }
    public static String refresh(Context c) throws Exception {
        synchronized(REFRESH_LOCK){
            byte[] bytes=download();if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();
            String parsed=ScheduleParser.parse(new ByteArrayInputStream(bytes),System.currentTimeMillis());
            synchronized(CACHE_LOCK){AtomicFile af=cache(c);FileOutputStream out=null;
                try{out=af.startWrite();out.write(parsed.getBytes(StandardCharsets.UTF_8));af.finishWrite(out);}catch(Exception e){af.failWrite(out);throw e;}
            }
            return parsed;
        }
    }
    private static byte[] download() throws IOException {
        long deadline=System.nanoTime()+25_000_000_000L;
        URL url=new URL(ScheduleParser.SOURCE);
        for(int redirects=0;redirects<5;redirects++){
            if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();
            String host=url.getHost();if(!host.equals("www.spospk.ru")&&!host.equals("spospk.ru"))throw new IOException("Сайт перенаправил запрос на неизвестный адрес.");
            if(!url.getProtocol().equals("http")&&!url.getProtocol().equals("https"))throw new IOException("Неподдерживаемый адрес.");
            long remaining=(deadline-System.nanoTime())/1_000_000L;if(remaining<=0)throw new SocketTimeoutException();
            HttpURLConnection c=(HttpURLConnection)url.openConnection();int timeout=(int)Math.max(1,Math.min(8000,remaining));
            c.setConnectTimeout(timeout);c.setReadTimeout(timeout);c.setInstanceFollowRedirects(false);c.setUseCaches(false);
            c.setRequestProperty("User-Agent","SPK-Schedule/1.2 (Android)");c.setRequestProperty("Cache-Control","no-cache");
            try{
                int code=c.getResponseCode();
                if(code>=300&&code<400){String location=c.getHeaderField("Location");if(location==null)throw new IOException("Пустое перенаправление.");url=new URL(url,location);continue;}
                if(code!=200)throw new IOException("Сайт ответил с кодом "+code+".");
                if(c.getContentLength()>8*1024*1024)throw new IOException("Файл расписания слишком большой.");
                InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[16384];int n;
                try{while((n=in.read(b))!=-1){
                    if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();
                    if(System.nanoTime()>deadline)throw new SocketTimeoutException();
                    if(out.size()+n>8*1024*1024)throw new IOException("Файл расписания слишком большой.");out.write(b,0,n);
                }}finally{in.close();}
                return out.toByteArray();
            }finally{c.disconnect();}
        }
        throw new IOException("Слишком много перенаправлений.");
    }
}
