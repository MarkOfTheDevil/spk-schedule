package ru.spk.schedule;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import org.json.*;
import java.time.*;

public final class ReminderScheduler {
    public static final String ACTION="ru.spk.schedule.DAILY_REMINDER";
    public static final String CHANNEL="tomorrow_classes_v1";
    private static final int ALARM_ID=2000,NOTIFICATION_ID=2001,TEST_ID=2002;
    public static SharedPreferences prefs(Context c){return c.getSharedPreferences("spk_reminders_v1",Context.MODE_PRIVATE);}
    public static void channel(Context c){
        NotificationChannel ch=new NotificationChannel(CHANNEL,"Пары на завтра",NotificationManager.IMPORTANCE_DEFAULT);
        ch.setDescription("Вечернее расписание выбранной группы на следующий день");
        c.getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }
    public static boolean allowed(Context c){
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return false;
        NotificationManager nm=c.getSystemService(NotificationManager.class);NotificationChannel ch=nm.getNotificationChannel(CHANNEL);
        return nm.areNotificationsEnabled()&&(ch==null||ch.getImportance()!=NotificationManager.IMPORTANCE_NONE);
    }
    public static boolean exact(Context c){return Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager.class).canScheduleExactAlarms();}
    public static String state(Context c){
        SharedPreferences p=prefs(c);JSONObject s=new JSONObject();
        try{s.put("enabled",p.getBoolean("enabled",false));s.put("hour",p.getInt("hour",20));s.put("minute",p.getInt("minute",0));s.put("group",p.getString("group",""));s.put("subgroup",p.getInt("subgroup",0));s.put("allowed",allowed(c));s.put("exact",exact(c));s.put("nextAt",p.getLong("nextAt",0));}catch(JSONException ignored){}
        return s.toString();
    }
    public static void saveConfig(Context c,String json) throws JSONException {
        JSONObject s=new JSONObject(json);SharedPreferences p=prefs(c);
        int h=s.optInt("hour",20),m=s.optInt("minute",0),sg=s.optInt("subgroup",0);String group=s.optString("group","");
        if(h<0||h>23||m<0||m>59||sg<0||sg>2||group.length()>200)throw new JSONException("Некорректные настройки уведомления.");
        String anchor=ReminderContent.anchor(s.optString("anchorDate","")).toString();boolean ae=s.optBoolean("anchorEven",true);
        boolean changed=h!=p.getInt("hour",20)||m!=p.getInt("minute",0)||sg!=p.getInt("subgroup",0)||!group.equals(p.getString("group",""))||!anchor.equals(p.getString("anchorDate","2026-10-19"))||ae!=p.getBoolean("anchorEven",true);
        p.edit().putInt("hour",h).putInt("minute",m).putInt("subgroup",sg).putString("group",group).putString("anchorDate",anchor).putBoolean("anchorEven",ae).commit();
        if(changed)schedule(c,true);
    }
    public static void enabled(Context c,boolean enabled){
        prefs(c).edit().putBoolean("enabled",enabled).commit();
        if(enabled)schedule(c,true);else{
            c.getSystemService(android.app.job.JobScheduler.class).cancel(ReminderJobService.JOB_ID);
            cancel(c);c.getSystemService(NotificationManager.class).cancel(NOTIFICATION_ID);c.getSystemService(NotificationManager.class).cancel(TEST_ID);
        }
    }
    private static PendingIntent alarm(Context c,String target,int flags){
        Intent i=new Intent(c,ReminderReceiver.class).setAction(ACTION);if(target!=null)i.putExtra("targetDate",target);
        return PendingIntent.getBroadcast(c,ALARM_ID,i,flags|PendingIntent.FLAG_IMMUTABLE);
    }
    private static void cancel(Context c){
        PendingIntent pi=alarm(c,null,PendingIntent.FLAG_NO_CREATE);if(pi!=null){c.getSystemService(AlarmManager.class).cancel(pi);pi.cancel();}
        prefs(c).edit().remove("nextAt").remove("targetDate").commit();
    }
    public static void schedule(Context c,boolean reset){
        SharedPreferences p=prefs(c);if(!p.getBoolean("enabled",false)||p.getString("group","").isEmpty()){cancel(c);return;}
        ZonedDateTime now=ZonedDateTime.now();long nowMs=now.toInstant().toEpochMilli();
        ZonedDateTime next=ReminderContent.nextTime(now,p.getInt("hour",20),p.getInt("minute",0));
        long at=next.toInstant().toEpochMilli();String target=next.toLocalDate().plusDays(1).toString();
        long stored=p.getLong("nextAt",0);String storedTarget=p.getString("targetDate","");
        // Opening the app just after an inexact alarm must not silently skip it.
        if(!reset&&stored>nowMs-6*60*60*1000L&&stored<at&&!storedTarget.isEmpty()&&!storedTarget.equals(p.getString("lastDelivered",""))){at=Math.max(nowMs+1000,stored);target=storedTarget;}
        PendingIntent pi=alarm(c,target,PendingIntent.FLAG_UPDATE_CURRENT);AlarmManager am=c.getSystemService(AlarmManager.class);
        try{if(exact(c))am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);}
        catch(SecurityException e){am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);}
        p.edit().putLong("nextAt",at).putString("targetDate",target).commit();
    }
    public static boolean deliver(Context c,String targetString,boolean test,boolean refreshed) throws Exception {
        SharedPreferences p=prefs(c);if(!p.getBoolean("enabled",false)||!allowed(c))return false;
        String group=p.getString("group","");if(group.isEmpty())return false;
        LocalDate today=LocalDate.now(),target=targetString==null?today.plusDays(1):LocalDate.parse(targetString);
        if(!test&&(target.isBefore(today)||target.toString().equals(p.getString("lastDelivered",""))))return false;
        int subgroup=p.getInt("subgroup",0);
        ReminderContent.Summary s=ReminderContent.create(ScheduleRepository.cached(c),group,subgroup,target,today,ReminderContent.anchor(p.getString("anchorDate","2026-10-19")),p.getBoolean("anchorEven",true),ZoneId.systemDefault());
        Intent open=new Intent(c,MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        open.putExtra("reminderDate",target.toString()).putExtra("reminderGroup",group).putExtra("reminderSubgroup",subgroup);
        PendingIntent tap=PendingIntent.getActivity(c,test?TEST_ID:NOTIFICATION_ID,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        int smallIcon=c.getResources().getIdentifier("ic_notification","drawable",c.getPackageName());
        String detail=(refreshed?"":"Не удалось обновить: показана сохранённая версия.\n\n")+s.detail;
        Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(smallIcon).setColor(Color.rgb(8,127,112)).setContentTitle((test?"Проверка · ":"")+s.title).setContentText((refreshed?"":"Сохранённая версия · ")+s.text).setSubText(s.week).setStyle(new Notification.BigTextStyle().bigText(detail)).setContentIntent(tap).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).setVisibility(Notification.VISIBILITY_PRIVATE).build();
        if(!p.getBoolean("enabled",false)||!allowed(c))return false;
        c.getSystemService(NotificationManager.class).notify(test?TEST_ID:NOTIFICATION_ID,n);
        if(!test)p.edit().putString("lastDelivered",target.toString()).commit();
        return true;
    }
}
