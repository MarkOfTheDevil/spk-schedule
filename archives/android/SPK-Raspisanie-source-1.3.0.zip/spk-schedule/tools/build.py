#!/usr/bin/env python3
"""Minimal, reproducible SDK build. JAVA_HOME/JDK javac or ECJ_JAR can compile Java."""
import os, pathlib, shutil, subprocess, zipfile, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
SDK = pathlib.Path(os.environ.get('ANDROID_SDK_ROOT', os.environ.get('ANDROID_HOME', '')))
BT = pathlib.Path(os.environ.get('ANDROID_BUILD_TOOLS', str(SDK / 'build-tools' / '35.0.0')))
PLATFORM = pathlib.Path(os.environ.get('ANDROID_PLATFORM_JAR', str(SDK / 'platforms' / 'android-35' / 'android.jar')))
BUILD = ROOT / 'build'
OUT = ROOT / 'output'

def run(*args):
    subprocess.run([str(x) for x in args], check=True, cwd=ROOT)

def main():
    if not PLATFORM.is_file():
        sys.exit('Set ANDROID_SDK_ROOT, or ANDROID_BUILD_TOOLS and ANDROID_PLATFORM_JAR.')
    for p in (BUILD / 'classes', BUILD / 'dex'):
        if p.exists():
            shutil.rmtree(p)
        p.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)
    java = sorted((ROOT / 'app/src/main/java').rglob('*.java'))
    if os.environ.get('ECJ_JAR'):
        run('java', '-jar', os.environ['ECJ_JAR'], '-8', '-nowarn', '-encoding', 'UTF-8', '-bootclasspath', PLATFORM, '-d', BUILD/'classes', *java)
    else:
        run('javac', '-source', '8', '-target', '8', '-encoding', 'UTF-8', '-bootclasspath', PLATFORM, '-d', BUILD/'classes', *java)
    run(BT/'aapt2', 'compile', '--dir', ROOT/'app/src/main/res', '-o', BUILD/'resources.zip')
    run(BT/'aapt2', 'link', '-o', BUILD/'resources.apk', '-I', PLATFORM, '--manifest', ROOT/'app/src/main/AndroidManifest.xml', '-A', ROOT/'app/src/main/assets', BUILD/'resources.zip')
    jar = BUILD/'classes.jar'
    with zipfile.ZipFile(jar, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted((BUILD/'classes').rglob('*.class')):
            z.write(f, str(f.relative_to(BUILD/'classes')))
    run(BT/'d8', '--min-api', '26', '--lib', PLATFORM, '--output', BUILD/'dex', jar)
    unsigned = BUILD/'unsigned.apk'
    shutil.copyfile(BUILD/'resources.apk', unsigned)
    with zipfile.ZipFile(unsigned, 'a', zipfile.ZIP_DEFLATED) as z:
        z.write(BUILD/'dex/classes.dex', 'classes.dex')
    run(BT/'zipalign', '-f', '-p', '4', unsigned, BUILD/'aligned.apk')
    keystore = pathlib.Path(os.environ.get('SPK_KEYSTORE', str(ROOT/'signing/personal-release.jks')))
    if not keystore.is_file():
        sys.exit('Set SPK_KEYSTORE to a signing key. See README.md.')
    if not os.environ.get('SPK_KEYSTORE_PASSWORD'):
        sys.exit('Set SPK_KEYSTORE_PASSWORD without printing it.')
    alias = os.environ.get('SPK_KEY_ALIAS', 'spk-personal')
    apk = OUT/'SPK-Raspisanie-1.3.0.apk'
    run(BT/'apksigner', 'sign', '--ks', keystore, '--ks-key-alias', alias, '--ks-pass', 'env:SPK_KEYSTORE_PASSWORD', '--key-pass', 'env:SPK_KEYSTORE_PASSWORD', '--out', apk, BUILD/'aligned.apk')
    run(BT/'apksigner', 'verify', '--verbose', apk)
    run(BT/'zipalign', '-c', '-p', '4', apk)
    print(apk)

if __name__ == '__main__':
    main()
