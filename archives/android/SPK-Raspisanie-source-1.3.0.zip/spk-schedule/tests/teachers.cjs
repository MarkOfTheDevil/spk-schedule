const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const index=require('../app/src/main/assets/teachers.js');
const data=JSON.parse(fs.readFileSync(path.join(__dirname,'../app/src/main/assets/schedule.json'),'utf8'));
const teachers=index.build(data);

test('all 84 teachers are found, similar surnames with different initials stay separate',()=>{
 assert.equal(teachers.length,84);
 assert.deepEqual(index.search(teachers,'Гончарова').map(t=>t.name),['Гончарова Л.Н.','Гончарова Н.В.']);
 assert.deepEqual(index.search(teachers,'Гончарова Н В').map(t=>t.name),['Гончарова Н.В.']);
});
test('search handles partial names, case, spacing, initials and е/ё',()=>{
 assert.equal(index.search(teachers,' полонСКАЯ а а ')[0].name,'Полонская А.А.');
 assert.equal(index.search(teachers,'полон')[0].name,'Полонская А.А.');
 assert.equal(index.search(teachers,'ерёмин м а')[0].name,'Е рёмин М.А.');
 assert.equal(index.search(teachers,'Несуществующий').length,0);
});
test('Polonskaya has six even Monday slots and five different odd Monday slots',()=>{
 const t=index.search(teachers,'Полонская А.А.')[0];
 assert.equal(t.weeks.even[0].length,6);assert.equal(t.weeks.odd[0].length,5);
 const first=t.weeks.even[0][0];
 assert.equal(first.start,'09:30');assert.equal(first.end,'11:05');
 assert.equal(first.variants[0].subject,'Проектирование и разработка ИС на платформе 1С');
 assert.equal(first.variants[0].room,'ЦРК');
 assert.deepEqual(first.variants[0].groups,[{id:'Д193/1',name:'Д193/1',subgroups:[1]}]);
 assert.deepEqual(t.weeks.odd[0][0].variants[0].groups[0].subgroups,[2]);
 assert.equal(t.weeks.even[0][5].start,'18:45');
 assert.equal(t.weeks.even[0][5].variants[0].groups[0].id,'Д194/Д195/2П');
 assert.deepEqual(t.weeks.even[6],[]);
});
test('every source teacher assignment survives indexing with exact group, time, room and subgroup',()=>{
 const expected=new Set(),actual=new Set();
 for(const g of data.groups)for(const w of ['even','odd'])for(let day=0;day<7;day++)for(const p of g.weeks[w][day])for(const v of p.variants){
  expected.add(JSON.stringify([index.key(v.teacher),w,day,p.number,p.start,p.end,v.subject,v.room,g.id,v.subgroup]));
 }
 for(const t of teachers)for(const w of ['even','odd'])for(let day=0;day<7;day++)for(const p of t.weeks[w][day])for(const v of p.variants)for(const g of v.groups)for(const sg of g.subgroups){
  actual.add(JSON.stringify([t.id,w,day,p.number,p.start,p.end,v.subject,v.room,g.id,sg]));
 }
 assert.deepEqual(actual,expected);
});
test('shared classes combine subgroups and groups without merging different rooms or subjects',()=>{
 const v=(teacher,subgroup,room='101',subject='Математика')=>({teacher,subgroup,room,subject});
 const pair=variants=>({number:1,start:'08:30',end:'10:05',variants});
 const group=(name,variants)=>({id:name,name,weeks:{even:{0:[pair(variants)]},odd:{}}});
 const d={groups:[group('А',[v('Петрова А.А.',1),v('Петрова А. А.',2)]),group('Б',[v('Петрова А.А.',0)]),group('В',[v('Петрова А.А.',0,'202')]),group('Г',[v('Петрова А.А.',0,'101','Физика')])]};
 const t=index.build(d)[0],p=t.weeks.even[0][0];
 assert.equal(p.variants.length,3);assert.equal(t.groupCount,4);
 const shared=p.variants.find(e=>e.subject==='Математика'&&e.room==='101');
 assert.deepEqual(shared.groups,[{id:'А',name:'А',subgroups:[1,2]},{id:'Б',name:'Б',subgroups:[0]}]);
});
test('a refreshed file replaces the teacher index; no stale teacher remains',()=>{
 const copy=JSON.parse(JSON.stringify(data));
 for(const g of copy.groups)for(const days of Object.values(g.weeks))for(const ps of Object.values(days))for(const p of ps)for(const v of p.variants)if(v.teacher==='Полонская А.А.')v.teacher='Новый преподаватель А.А.';
 const updated=index.build(copy);
 assert.equal(index.search(updated,'Полонская').length,0);
 assert.equal(index.search(updated,'Новый преподаватель')[0].weeks.even[0].length,6);
});
