"""Source-grounded regression cases, corruption checks and ZIP/XML validation."""
import json, pathlib, subprocess, tempfile, zipfile, unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
FIXTURE = ROOT / 'tests/fixtures/rasp-2026-10-23.xlsx'
CLASSPATH = ROOT / 'tests/build'

def parse(path):
    return subprocess.run(['java', '-cp', str(CLASSPATH), 'ru.spk.schedule.ParserCli', str(path), '1792780800000'], capture_output=True, text=True)

class ScheduleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        p = parse(FIXTURE)
        assert p.returncode == 0, p.stderr
        cls.data = json.loads(p.stdout)
        cls.groups = {g['name']: g for g in cls.data['groups']}

    def test_all_groups_and_days(self):
        self.assertEqual(len(self.groups), 53)
        self.assertEqual(self.data['lessonCount'], 2059)
        for g in self.groups.values():
            self.assertEqual(set(g['weeks']), {'even', 'odd'})
            for days in g['weeks'].values():
                self.assertEqual(set(days), set('0123456'))
                self.assertEqual(days['6'], [])

    def test_even_monday_and_shared_pairs(self):
        monday = self.groups['Д193/1']['weeks']['even']['0']
        self.assertEqual([p['number'] for p in monday], [1, 2, 3, 4])
        self.assertEqual((monday[0]['start'], monday[0]['end']), ('09:30', '11:05'))
        self.assertEqual(monday[0]['variants'], [{'subject': 'Проектирование и разработка ИС на платформе 1С', 'teacher': 'Полонская А.А.', 'room': 'ЦРК', 'subgroup': 1}])
        self.assertEqual(monday[1]['variants'][0]['subgroup'], 0)
        self.assertEqual(monday[1]['variants'][0]['room'], 'онлайн')
        self.assertEqual(monday[2]['variants'][0]['room'], '216')

    def test_odd_week_is_distinct(self):
        pair = self.groups['Д193/1']['weeks']['odd']['0'][0]
        self.assertEqual([v['subject'] for v in pair['variants']], ['Разработка кода ИС', 'Проектирование и разработка ИС на платформе 1С'])
        self.assertEqual([v['subgroup'] for v in pair['variants']], [1, 2])

    def test_tuesday_practice_switches_subgroups(self):
        pairs = self.groups['Д193/1']['weeks']['even']['1']
        self.assertEqual([p['variants'][0]['subgroup'] for p in pairs], [2, 2, 2, 1, 1, 1])
        self.assertEqual(pairs[0]['start'], '08:30')
        self.assertEqual(pairs[-1]['end'], '19:40')
        self.assertTrue(all(p['variants'][0]['subject'] == 'УП. 07' for p in pairs))

    def test_duplicate_separator_and_alias(self):
        self.assertEqual(sum(g['name'] == 'ДПП196/2' for g in self.data['groups']), 1)
        self.assertIn('193П/194/2П', self.groups['Д193П/Д194/2П']['aliases'])
        self.assertIn('Д193П/Д194/2П', self.groups['Д193П/Д194/2П']['aliases'])

    def test_source_header_notes(self):
        self.assertEqual(len(self.data['mondayNotes']), 3)
        self.assertTrue(any('8.35' in n for n in self.data['mondayNotes']))
        self.assertTrue(any('8.50' in n for n in self.data['mondayNotes']))

    def test_no_lesson_loses_teacher_or_room(self):
        for g in self.data['groups']:
            for days in g['weeks'].values():
                for pairs in days.values():
                    for pair in pairs:
                        self.assertLess(pair['start'], pair['end'])
                        for v in pair['variants']:
                            self.assertTrue(v['subject'])
                            self.assertTrue(v['teacher'])
                            self.assertTrue(v['room'])
                            self.assertIn(v['subgroup'], [0, 1, 2])

    def modified_fixture(self, member, transform):
        tmp = tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False)
        tmp.close()
        with zipfile.ZipFile(FIXTURE) as source, zipfile.ZipFile(tmp.name, 'w') as target:
            for name in source.namelist():
                data = source.read(name)
                if name == member:
                    data = transform(data)
                target.writestr(name, data)
        return pathlib.Path(tmp.name)

    def test_missing_parity_marker_is_rejected(self):
        p = self.modified_fixture('xl/sharedStrings.xml', lambda b: b.replace('ЧЕТНАЯ НЕДЕЛЯ'.encode(), 'УДАЛЕНА МЕТКА'.encode()))
        try:
            result = parse(p)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('чётность', result.stderr)
        finally:
            p.unlink()

    def test_dtd_is_rejected(self):
        p = self.modified_fixture('xl/workbook.xml', lambda b: b.replace(b'?>', b'?><!DOCTYPE workbook [<!ENTITY test SYSTEM "file:///no-such-file">]>', 1))
        try:
            result = parse(p)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('XML', result.stderr)
        finally:
            p.unlink()

    def test_html_response_is_rejected(self):
        with tempfile.NamedTemporaryFile(suffix='.xlsx') as f:
            f.write(b'<html>Service unavailable</html>'); f.flush()
            result = parse(f.name)
            self.assertNotEqual(result.returncode, 0)

if __name__ == '__main__':
    unittest.main(verbosity=2)
