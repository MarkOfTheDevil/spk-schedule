package ru.spk.schedule;

import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;
import java.io.IOException;

/** Run on the JVM with org.json; no mocked Android runtime. */
public final class ReminderTests {
    private static int checks;
    private static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);checks++;}
    public static void main(String[] args) throws Exception {
        String json=new String(Files.readAllBytes(Paths.get(args[0])),StandardCharsets.UTF_8);
        LocalDate anchor=ReminderContent.DEFAULT_ANCHOR;
        ZoneId zone=ZoneId.of("Asia/Krasnoyarsk");
        check(ReminderContent.isEven(LocalDate.parse("2026-10-25"),anchor,true),"Sunday still even");
        check(!ReminderContent.isEven(LocalDate.parse("2026-10-26"),anchor,true),"Monday becomes odd");
        check(ReminderContent.isEven(LocalDate.parse("2026-11-02"),anchor,true),"Following Monday even");
        check(!ReminderContent.isEven(LocalDate.parse("2026-10-12"),anchor,true),"Before anchor");
        check(ReminderContent.isEven(LocalDate.parse("2026-10-26"),anchor,false),"User parity correction");
        ReminderContent.Summary odd=ReminderContent.create(json,"Д193/1",2,LocalDate.parse("2026-10-26"),LocalDate.parse("2026-10-25"),anchor,true,zone);
        check(odd.title.equals("Завтра · Д193/1")&&odd.week.equals("Нечётная неделя"),"Sunday notification uses tomorrow's parity");
        check(odd.count==4&&odd.text.equals("4 пары · 09:30–16:50"),"Monday times and slot count");
        check(odd.detail.indexOf("Проектирование")<odd.detail.indexOf("Разработка кода"),"Correct second subgroup order");
        check(odd.detail.contains("Экология")&&!odd.detail.contains("Правовое обеспечение"),"Correct week content");
        ReminderContent.Summary even=ReminderContent.create(json,"Д193/1",2,LocalDate.parse("2026-11-02"),LocalDate.parse("2026-11-01"),anchor,true,zone);
        check(even.count==3&&even.text.equals("3 пары · 11:25–16:50"),"Subgroup without first lesson");
        check(even.detail.contains("Экономика")&&even.detail.contains("ауд. 216")&&!even.detail.contains("Проектирование"),"Common lessons and rooms retained");
        ReminderContent.Summary all=ReminderContent.create(json,"Д193/1",0,LocalDate.parse("2026-10-26"),LocalDate.parse("2026-10-26"),anchor,true,zone);
        check(all.count==4&&all.detail.contains("1 подгр.")&&all.detail.contains("2 подгр."),"Variants do not double-count lessons");
        check(all.title.equals("Сегодня · Д193/1"),"Delivery delayed past midnight");
        ReminderContent.Summary sunday=ReminderContent.create(json,"Д193/1",0,LocalDate.parse("2026-10-25"),LocalDate.parse("2026-10-24"),anchor,true,zone);
        check(sunday.groupFound&&sunday.count==0&&sunday.text.equals("Занятий нет"),"Empty Sunday");
        ReminderContent.Summary missing=ReminderContent.create(json,"MISSING",0,LocalDate.parse("2026-10-26"),LocalDate.parse("2026-10-25"),anchor,true,zone);
        check(!missing.groupFound&&missing.text.contains("не найдена"),"Missing group is not mistaken for no classes");
        check(odd.detail.contains("Сохранённое расписание от"),"Source timestamp");
        ZonedDateTime before=LocalDate.parse("2026-10-25").atTime(19,59).atZone(zone);
        check(ReminderContent.nextTime(before,20,0).equals(before.withHour(20).withMinute(0)),"Before scheduled time");
        check(ReminderContent.nextTime(before.withHour(20).withMinute(0),20,0).toLocalDate().equals(LocalDate.parse("2026-10-26")),"Next day after trigger");
        ZonedDateTime winter=ZonedDateTime.of(2026,10,24,21,0,0,0,ZoneId.of("Europe/Berlin"));
        ZonedDateTime next=ReminderContent.nextTime(winter,20,0);
        check(next.getHour()==20&&next.getOffset().equals(ZoneOffset.ofHours(1)),"Clock change retains local wall time");
        check(ReminderContent.anchor("bad").equals(anchor),"Invalid anchor fallback");

        final List<String> events=new ArrayList<String>();
        ReminderDelivery.Active active=()->true;
        ReminderDelivery.Result fresh=ReminderDelivery.run(()->events.add("download-parse-save"),ok->{events.add(ok?"notify-fresh":"notify-cache");return true;},active);
        check(events.equals(Arrays.asList("download-parse-save","notify-fresh"))&&fresh.refreshed&&fresh.delivered,"Successful refresh completes before notifying");
        events.clear();
        ReminderDelivery.Result offline=ReminderDelivery.run(()->{events.add("download-failed");throw new IOException("offline");},ok->{events.add(ok?"notify-fresh":"notify-cache");return true;},active);
        check(events.equals(Arrays.asList("download-failed","notify-cache"))&&!offline.refreshed&&offline.delivered,"Network failure sends explicitly cached notification");
        events.clear();final boolean[] enabled={true};
        ReminderDelivery.Result cancelled=ReminderDelivery.run(()->{events.add("update");enabled[0]=false;},ok->{events.add("notify");return true;},()->enabled[0]);
        check(events.equals(Arrays.asList("update"))&&!cancelled.delivered,"Disable while loading suppresses notification");
        events.clear();
        ReminderDelivery.run(()->events.add("update"),ok->{events.add("notify");return true;},()->false);
        check(events.isEmpty(),"Disabled task does nothing");
        ReminderDelivery.Result interrupted=ReminderDelivery.run(()->Thread.currentThread().interrupt(),ok->{events.add("notify");return true;},active);
        check(!interrupted.delivered&&events.isEmpty(),"Stopped job cannot notify");Thread.interrupted();
        System.out.println("PASS: "+checks+" reminder calendar, content, refresh-before-send, offline and cancellation checks.");
    }
}
