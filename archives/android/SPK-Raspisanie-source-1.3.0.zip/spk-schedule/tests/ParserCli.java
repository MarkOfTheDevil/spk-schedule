package ru.spk.schedule;
import java.io.*;
public final class ParserCli {public static void main(String[] args) throws Exception {System.out.print(ScheduleParser.parse(new FileInputStream(args[0]),args.length>1?Long.parseLong(args[1]):System.currentTimeMillis()));}}
