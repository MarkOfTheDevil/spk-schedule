const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright-core');
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert/strict');
const assets=path.resolve(__dirname,'../app/src/main/assets');
const output=process.env.SPK_QA_DIR||path.join(__dirname,'qa');fs.mkdirSync(output,{recursive:true});
const snapshot=JSON.parse(fs.readFileSync(path.join(assets,'schedule.json'),'utf8'));
const server=http.createServer((req,res)=>{
 const name=req.url==='/'?'index.html':req.url.slice(1);
 if(!['index.html','app.js','teachers.js','palettes.js','app.css','palettes.css','schedule.json'].includes(name)){res.writeHead(404);res.end();return;}
 res.setHeader('Content-Type',name.endsWith('.html')?'text/html; charset=utf-8':name.endsWith('.js')?'application/javascript':name.endsWith('.css')?'text/css':'application/json');res.end(fs.readFileSync(path.join(assets,name)));
});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.CHROME_BIN,headless:true,args:['--no-sandbox']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},locale:'ru-RU',timezoneId:'Asia/Krasnoyarsk',colorScheme:'light'});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.clock.install({time:new Date('2026-10-25T19:00:00+07:00')});
  await page.addInitScript(data=>{
   window.mockDark=true;window.nativeTheme=null;window.openReminder='';window.testCalls=0;
   window.mockReminder=JSON.parse(localStorage.getItem('qa.nativeReminder')||'null')||{enabled:false,group:'',subgroup:0,hour:20,minute:0,allowed:false,exact:false};
   const emit=message=>{localStorage.setItem('qa.nativeReminder',JSON.stringify(window.mockReminder));queueMicrotask(()=>window.onReminderState({...window.mockReminder,message}));};
   window.College={getSnapshot:()=>JSON.stringify({...data,fetchedAt:Date.now()}),isSystemDark:()=>window.mockDark,theme:d=>{window.nativeTheme=d;},
    getReminderState:()=>JSON.stringify(window.mockReminder),saveReminderConfig:s=>{Object.assign(window.mockReminder,JSON.parse(s));emit();},
    setRemindersEnabled:value=>{window.mockReminder.enabled=value&&window.mockReminder.allowed;emit(value&&!window.mockReminder.allowed?'Уведомления не разрешены.':undefined);},
    openNotificationSettings:()=>{window.settingsOpened=true;},requestExactReminderTime:()=>{window.exactOpened=true;},
    testReminder:()=>{window.testCalls++;},consumeReminderOpen:()=>{const value=window.openReminder;window.openReminder='';return value;},
    refreshSchedule:()=>queueMicrotask(()=>{window.onScheduleData({...data,fetchedAt:Date.now()});window.onScheduleStatus({loading:false,ok:true});}),openSource:()=>{}};
  },snapshot);
  await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForSelector('.welcome');
  assert.equal(await page.locator('html').getAttribute('data-theme'),'dark');
  assert.equal(await page.evaluate(()=>matchMedia('(prefers-color-scheme: dark)').matches),false);
  await page.click('[data-page="settings"]');
  assert.equal(await page.locator('#reminderToggle').getAttribute('aria-checked'),'false');
  assert.equal(await page.locator('#reminderToggle').isDisabled(),true);
  assert.equal(await page.locator('#reminderTime').inputValue(),'20:00');
  await page.click('[data-theme-choice="light"]');assert.equal(await page.locator('html').getAttribute('data-theme'),'light');
  await page.click('[data-theme-choice="auto"]');assert.equal(await page.locator('html').getAttribute('data-theme'),'dark');
  await page.evaluate(()=>{window.mockDark=false;window.onSystemThemeChanged(false);});assert.equal(await page.locator('html').getAttribute('data-theme'),'light');
  await page.click('[data-theme-choice="dark"]');
  await page.evaluate(()=>window.onSystemThemeChanged(false));assert.equal(await page.locator('html').getAttribute('data-theme'),'dark');
  await page.click('[data-theme-choice="auto"]');assert.equal(await page.locator('html').getAttribute('data-theme'),'light');
  await page.evaluate(()=>{window.mockDark=true;window.onAppResume();});assert.equal(await page.locator('html').getAttribute('data-theme'),'dark');
  await page.emulateMedia({colorScheme:'dark'});await page.emulateMedia({colorScheme:'light'});
  assert.equal(await page.locator('html').getAttribute('data-theme'),'dark');

  await page.click('[data-action="reminder-group"]');await page.fill('#groupSearch','Д193/1');await page.click('#groupList [data-group="Д193/1"]');
  assert.equal(await page.evaluate(()=>state.group),'');
  await page.click('[data-reminder-subgroup="2"]');
  await page.fill('#reminderTime','20:15');await page.locator('#reminderTime').dispatchEvent('change');
  assert.deepEqual(await page.evaluate(()=>[mockReminder.group,mockReminder.subgroup,mockReminder.hour,mockReminder.minute]),['Д193/1',2,20,15]);
  await page.click('#reminderToggle');assert.equal(await page.locator('#reminderToggle').getAttribute('aria-checked'),'false');
  assert.match(await page.locator('.reminder-message').innerText(),/не разрешены/);
  await page.click('[data-action="notification-settings"]');assert.equal(await page.evaluate(()=>window.settingsOpened),true);
  await page.evaluate(()=>{window.mockReminder.allowed=true;window.onReminderState(window.mockReminder);});
  await page.click('#reminderToggle');assert.equal(await page.locator('#reminderToggle').getAttribute('aria-checked'),'true');
  await page.click('[data-action="reminder-exact"]');assert.equal(await page.evaluate(()=>window.exactOpened),true);
  await page.evaluate(()=>{window.mockReminder.exact=true;window.onAppResume();});
  assert.equal(await page.locator('[data-action="reminder-exact"]').count(),0);
  await page.click('[data-action="reminder-test"]');assert.equal(await page.evaluate(()=>window.testCalls),1);
  assert.equal(await page.locator('[data-action="reminder-test"]').isDisabled(),true);
  await page.evaluate(()=>window.onReminderTest('Не удалось обновить. Уведомление отправлено по сохранённому расписанию.'));
  assert.equal(await page.locator('[data-action="reminder-test"]').isDisabled(),false);
  assert.match(await page.locator('#toast').innerText(),/сохранённому/);
  await page.clock.runFor(4000);await page.locator('#toast').evaluate(el=>el.classList.remove('show'));await page.evaluate(()=>window.scrollTo(0,0));await page.screenshot({path:path.join(output,'reminders-dark.png'),fullPage:true});
  await page.click('[data-theme-choice="light"]');await page.screenshot({path:path.join(output,'reminders-light.png'),fullPage:true});
  await page.locator('#refreshTop').screenshot({path:path.join(output,'refresh-icon.png'),scale:'css'});
  await page.setViewportSize({width:320,height:640});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  await page.screenshot({path:path.join(output,'reminders-narrow.png'),fullPage:true});
  await page.click('[data-page="schedule"]');await page.click('[data-action="choose"]');await page.fill('#groupSearch','Д114');await page.click('#groupList [data-group="Д114"]');
  assert.equal(await page.evaluate(()=>state.reminder.group),'Д193/1');
  await page.reload();await page.waitForSelector('.hero');await page.click('[data-page="settings"]');
  assert.equal(await page.locator('#reminderToggle').getAttribute('aria-checked'),'true');
  assert.equal(await page.locator('#reminderTime').inputValue(),'20:15');
  assert.equal(await page.locator('.reminder-time-control span').innerText(),'20:15');
  assert.equal(await page.evaluate(()=>state.reminder.subgroup),2);
  await page.evaluate(()=>{window.openReminder=JSON.stringify({date:'2026-10-26',group:'Д193/1',subgroup:2});window.onNotificationOpen();});
  assert.deepEqual(await page.evaluate(()=>[state.group,state.day,parity(),subgroup()]),['Д193/1',0,'odd',2]);
  assert.match(await page.locator('.subject').first().innerText(),/Проектирование/);
  await page.evaluate(()=>{window.openReminder=JSON.stringify({date:'invalid',group:'Д114'});window.onNotificationOpen();});
  assert.equal(await page.evaluate(()=>state.group),'Д193/1');
  await page.click('[data-page="settings"]');await page.click('#reminderToggle');
  assert.equal(await page.locator('#reminderToggle').getAttribute('aria-checked'),'false');
  assert.equal(await page.locator('[data-action="reminder-test"]').isDisabled(),true);
  assert.deepEqual(errors,[]);
  console.log('PASS: native system theme overrides WebView media, live changes and resume; opt-in, time, pinned group/subgroup, denied/granted permissions, test feedback, exact alarm settings, persistence, notification tap/parity, disable, 320px layout; no JS errors.');
 }finally{await browser.close();server.close();}
})().catch(e=>{console.error(e);server.close();process.exitCode=1;});
