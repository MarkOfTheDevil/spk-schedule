'use strict';
let plannerIndex=[],searchLimit=80,searchKind='all',searchCampus='all',plannerMonth=null,shareRange='day',shareBusy=false,shareSnapshot=null,sharePages=[],sharePage=0,sharePreviewToken=0,sharePreviewTimer=null;
let shareDesign=readShareDesign(),searchFilterDraft=null;
function selectedDate(){return SpkPlanner.add(SpkPlanner.date(state.weekDate)||monday(),state.day);}
function setSelectedDate(d,motion='day',automatic=true){if(!d||!SpkPlanner.date(dateKey(d)))return false;state.weekDate=dateKey(monday(d));state.day=(d.getDay()+6)%7;if(automatic)state.mode='auto';render(motion);return true;}
function plannerTarget(){if(state.page==='explore')return state.explore;if(state.page==='teachers'){const t=currentTeacher();return t&&!state.teacherSelecting?{kind:'teacher',value:SpkPlanner.key(t.name),label:t.name,campus:state.campus}:null;}const g=currentGroup();return g?{kind:'group',value:g.id,label:g.name,campus:g.source||'spk'}:null;}
function plannerLessons(d){const t=plannerTarget();return t?SpkPlanner.lessons(state.data,t,currentEven(d)?'even':'odd',(d.getDay()+6)%7,t.kind==='group'?subgroup():0):[];}
function plannerToolbar(){return '<div class="planner-toolbar"><button data-action="calendar" aria-haspopup="dialog">'+icon('calendar')+'<span>'+esc(selectedDate().toLocaleDateString('ru-RU',{month:'long',year:'numeric'}))+'</span>'+icon('chevron')+'</button><button data-action="share" aria-haspopup="dialog">'+icon('share')+'<span>Поделиться</span></button></div>';}
function openSmartSearch(kind='all',purpose='group'){
 if(!state.data)return;state.chooserPurpose=purpose;searchKind=purpose==='reminder'?'group':kind;searchCampus='all';searchLimit=80;state.onlyFavorites=false;
 $('chooserTitle').textContent=purpose==='reminder'?'Группа для уведомлений':'Умный поиск';$('groupSearch').value='';$('groupSearch').placeholder=purpose==='reminder'?'Группа СПК или ЦРК':'Группа, преподаватель, предмет, кабинет';$('groupSearch').setAttribute('aria-label','Единый поиск');$('searchKindLabel').hidden=purpose==='reminder';setSearchFiltersOpen(false,false);SpkMotion.showModal($('modal'));document.body.classList.add('modal-open');renderSmartSearch();$('groupSearch').focus({preventScroll:true});
}
function renderSmartSearch(){
 if(!state.data)return;const input=$('groupSearch').value,link=SpkPlanner.parseLink(input);syncSearchFilters();if(searchFilterDraft)renderSearchFilters();
 if(link&&state.chooserPurpose!=='reminder'){$('groupCount').textContent='Ссылка на расписание';$('groupList').innerHTML='<button class="search-result" data-action="open-shared">'+icon('external')+'<span><strong>Открыть полученное расписание</strong><small>'+esc(link.date.toLocaleDateString('ru-RU'))+' · '+(link.range==='week'?'Неделя':'День')+'</small></span>'+icon('arrow')+'</button>';return;}
 const kind=!input.trim()&&searchKind==='all'?'group':searchKind,results=SpkPlanner.search(plannerIndex,input,kind,searchCampus,state.onlyFavorites?state.favorites:null),shown=results.slice(0,searchLimit);$('groupCount').textContent='Найдено: '+results.length;
 const labels={group:'Группы',teacher:'Преподаватели',subject:'Предметы',room:'Кабинеты'},icons={group:'user',teacher:'user',subject:'book',room:'room'};
 $('groupList').innerHTML=(!input.trim()&&searchKind==='all'?'<p class="search-hint">Введите название или номер. Ищем сразу в СПК и ЦРК.</p>':'')+['group','teacher','subject','room'].map(type=>{const items=shown.filter(e=>e.kind===type);if(!items.length)return '';return '<div class="search-category">'+labels[type]+'</div>'+items.map(e=>'<div class="group-row"><button class="search-result '+(type==='group'?'group-pick':type==='teacher'?'teacher-pick':'')+'" '+(type==='group'?'data-group="'+esc(e.value)+'"':'data-search-id="'+esc(e.id)+'"')+'>'+icon(icons[type])+'<span><strong>'+esc(type==='room'?'Ауд. '+e.label:e.label)+'</strong><small>'+(e.campus==='crk'?'ЦРК':'СПК')+' · '+(type==='group'?'Расписание группы':type==='teacher'?'Все группы преподавателя':type==='room'?'Занятия в кабинете':'Все занятия по предмету')+'</small></span>'+icon('arrow')+'</button>'+(type==='group'?'<button class="icon-button '+(state.favorites.includes(e.value)?'favorited':'')+'" data-favorite="'+esc(e.value)+'" aria-label="Избранное: '+esc(e.label)+'" aria-pressed="'+state.favorites.includes(e.value)+'">'+icon('star')+'</button>':'')+'</div>').join('');}).join('')+(results.length>shown.length?'<button class="text-button search-more" data-action="search-more">Показать ещё ('+(results.length-shown.length)+')</button>':'')+(!results.length?'<div class="empty"><h3>Ничего не найдено</h3><p>Попробуйте часть фамилии, название группы, предмета или номер кабинета. Можно сменить фильтр.</p></div>':'');
}
function setSearchFiltersOpen(open,focus=true){if(open)openSearchFilters();else closeSearchFilters(focus);}
function openSearchFilters(){
 if(searchFilterDraft)return;searchFilterDraft={kind:searchKind,campus:searchCampus,favorites:state.onlyFavorites};$('groupSearch').blur();$('searchKindLabel').hidden=state.chooserPurpose==='reminder';renderSearchFilters();$('searchFilterPanel').hidden=false;$('searchFilterToggle').setAttribute('aria-expanded','true');if(state.animations&&!SpkMotion.reduced())$('searchFilterPanel').animate([{opacity:0},{opacity:1}],{duration:180});
}
function closeSearchFilters(focus=true){searchFilterDraft=null;$('searchFilterPanel').hidden=true;$('searchFilterToggle').setAttribute('aria-expanded','false');if(focus&&!$('modal').hidden)$('searchFilterToggle').focus({preventScroll:true});}
function syncSearchFilters(){
 const reminder=state.chooserPurpose==='reminder';if(reminder)searchKind='group';
 const labels={group:'Группы',teacher:'Преподаватели',subject:'Предметы',room:'Кабинеты'},parts=[];
 if(searchKind!=='all'&&!reminder)parts.push(labels[searchKind]);if(searchCampus!=='all')parts.push(searchCampus==='crk'?'ЦРК':'СПК');if(state.onlyFavorites)parts.push('Избранные');
 $('searchFilterBadge').textContent=parts.length;$('searchFilterBadge').hidden=!parts.length;$('searchFilterSummary').hidden=!parts.length;$('searchFilterSummary').textContent=parts.join(' · ');$('searchFilterToggle').setAttribute('aria-label','Фильтры'+(parts.length?': '+parts.join(', '):' поиска'));
}
function renderSearchFilters(){
 const d=searchFilterDraft;if(!d)return;if(state.chooserPurpose==='reminder')d.kind='group';$('searchKind').value=d.kind;document.querySelectorAll('[data-filter-campus]').forEach(b=>{const active=b.dataset.filterCampus===d.campus;b.setAttribute('aria-pressed',String(active));b.classList.toggle('active',active);});$('searchFavorites').checked=d.favorites;
 const query=$('groupSearch').value,kind=!query.trim()&&d.kind==='all'?'group':d.kind,count=SpkPlanner.search(plannerIndex,query,kind,d.campus,d.favorites?state.favorites:null).length;$('searchFilterDone').textContent='Применить · '+count;$('searchFilterReset').disabled=d.kind===(state.chooserPurpose==='reminder'?'group':'all')&&d.campus==='all'&&!d.favorites;
}
function changeSearchFilter(id,value){
 const d=searchFilterDraft;if(!d)return;if(id==='searchKind'){d.kind=value;if(!['all','group'].includes(value))d.favorites=false;}if(id==='searchCampus')d.campus=value;if(id==='searchFavorites'){d.favorites=!!value;if(value)d.kind='group';}renderSearchFilters();
}
function applySearchFilters(){if(!searchFilterDraft)return;searchKind=searchFilterDraft.kind;searchCampus=searchFilterDraft.campus;state.onlyFavorites=searchFilterDraft.favorites;searchLimit=80;renderSmartSearch();closeSearchFilters();}
function activateSearchCampus(campus){if(state.campus!==campus){state.campusGroups[state.campus]=state.group;state.group=state.campusGroups[campus]||'';state.campus=campus;}indexCampus();}
function chooseSearchResult(id){const item=plannerIndex.find(e=>e.id===id);if(!item)return;activateSearchCampus(item.campus);closeChooser();if(item.kind==='teacher')chooseTeacher(TeacherIndex.key(item.label));else{state.explore=item;state.page='explore';persist();render('page');}}
function renderExplore(){const t=state.explore;if(!t)return welcome();const lessons=SpkPlanner.lessons(state.data,t,parity(),state.day),controls='<section class="hero"><div class="eyebrow">'+(t.kind==='room'?'КАБИНЕТ':'ПРЕДМЕТ')+' · '+campusName()+'</div><button class="group-title-button explore-title" data-action="search"><h1>'+esc(t.kind==='room'?'Ауд. '+t.label:t.label)+'</h1>'+icon('search')+'</button><p class="explore-note">Занятия во всех группах</p></section>'+renderDayControls();
 let results=renderDayHeading(lessons.length)+renderNowNext(lessons)+renderCards(lessons,v=>'<div class="variant"><h3 class="subject">'+esc(v.subject)+'</h3>'+(v.teacher?'<div class="teacher">'+icon('user')+'<span>'+esc(v.teacher)+'</span></div>':'')+'<div class="lesson-tags">'+roomTag(v.room)+'</div><div class="teacher-groups">'+v.groups.map(g=>'<button class="teacher-group-button" data-group="'+esc(g.id)+'" data-view-subgroup="'+(g.subgroups[0]||0)+'"><span>'+esc(g.name)+'</span><small>'+(g.subgroups[0]?g.subgroups[0]+' подгр.':'Вся группа')+'</small>'+icon('arrow')+'</button>').join('')+'</div></div>');
 if(!lessons.length)results+=emptyDay('На выбранную дату занятий по этому запросу нет. Другую дату можно выбрать в календаре.');return timetableView('explore:'+t.id,controls,results+sourceFooter());
}
function syncModalBody(){document.body.classList.toggle('modal-open',[...document.querySelectorAll('.modal')].some(m=>!m.hidden));}
function showPlanner(title,html){$('plannerTitle').textContent=title;$('plannerContent').innerHTML=html;$('plannerContent').scrollTop=0;SpkMotion.showModal($('plannerModal'));syncModalBody();$('closePlanner').focus({preventScroll:true});}
function closePlanner(){SpkMotion.hideModal($('plannerModal'),()=>{syncModalBody();if(!document.body.classList.contains('modal-open'))document.querySelector('[data-action="calendar"]')?.focus({preventScroll:true});});}
function openCalendar(){if(!plannerTarget())return;const d=selectedDate();plannerMonth=new Date(d.getFullYear(),d.getMonth(),1,12);showPlanner('Календарь',calendarHtml());}
function calendarHtml(){const chosen=dateKey(selectedDate()),today=dateKey(new Date()),target=plannerTarget();return '<div class="calendar-nav"><button class="icon-button" data-calendar-step="-1" aria-label="Предыдущий месяц">'+icon('left')+'</button><strong aria-live="polite">'+esc(plannerMonth.toLocaleDateString('ru-RU',{month:'long',year:'numeric'}))+'</strong><button class="icon-button" data-calendar-step="1" aria-label="Следующий месяц">'+icon('arrow')+'</button></div><p class="calendar-target">'+esc(target.label)+' · '+campusName()+'</p><div class="calendar-grid" role="group" aria-label="Дни месяца">'+SHORT.map(d=>'<span class="calendar-weekday">'+d+'</span>').join('')+SpkPlanner.month(plannerMonth).map(d=>{const iso=dateKey(d),count=plannerLessons(d).length;return '<button '+(!SpkPlanner.date(iso)?'disabled ':'')+'data-calendar-date="'+iso+'" class="calendar-day '+(d.getMonth()!==plannerMonth.getMonth()?'outside ':'')+(chosen===iso?'selected ':'')+(today===iso?'today':'')+'" aria-pressed="'+(chosen===iso)+'" aria-label="'+esc(d.toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'}))+', '+lessonCount(count)+', '+(currentEven(d)?'чётная':'нечётная')+' неделя"'+(today===iso?' aria-current="date"':'')+'><span>'+d.getDate()+'</span><i class="calendar-mark '+(count?'has-lessons':'')+'" aria-hidden="true"></i></button>';}).join('')+'</div><div class="calendar-legend"><span><i></i>Есть занятия</span><button class="text-button" data-action="calendar-today">Сегодня</button></div><label class="calendar-jump" for="calendarJump">Перейти к дате<input type="date" id="calendarJump" min="1000-01-01" max="9999-12-31" value="'+chosen+'"></label><button class="button-primary calendar-week" data-action="week-overview">Обзор выбранной недели</button><p class="planner-note">Чётность определяется по дате. Показываем текущую таблицу колледжа: будущие замены и праздничные дни могут ещё не учитываться.</p>';}
function currentSnapshot(range){const target=plannerTarget();if(!target)return null;const snapshot=JSON.parse(JSON.stringify(SpkPlanner.snapshot(state.data,target,selectedDate(),range,subgroup(),state.mode,state.anchorDate,state.anchorEven)));if(!state.subgroupsEnabled){for(const day of snapshot.days)for(const lesson of day.lessons)for(const v of lesson.variants){v.subgroup=0;for(const g of v.groups||[])g.subgroups=[0];}}return snapshot;}
function dayPreview(d){return '<section class="share-day"><h3>'+esc(d.title)+'</h3><p class="share-week">'+(d.week==='even'?'Чётная':'Нечётная')+' неделя</p>'+(d.lessons.length?d.lessons.map(l=>'<div class="share-slot"><strong>'+l.number+' пара · '+esc(l.start)+'–'+esc(l.end)+'</strong>'+l.variants.map(v=>'<p>'+SpkPlanner.variantLines(v).map(esc).join('<br>')+'</p>').join('')+'</div>').join(''):'<p class="share-empty">Занятий нет</p>')+'</section>';}
function openWeekOverview(){const s=currentSnapshot('week');if(s)showPlanner('Неделя · '+s.target.label,'<p class="planner-note">'+(s.manual?'Чётность выбрана вручную. ':'')+'По текущей таблице колледжа.</p>'+s.days.map(d=>dayPreview(d)+'<button class="text-button overview-open" data-calendar-date="'+d.date+'">Открыть этот день '+icon('arrow')+'</button>').join(''));}
function readShareDesign(){try{return SpkShareImage.normalize(JSON.parse(localStorage.getItem('spk.share-design.v1')||'null'));}catch(_){return {...SpkShareImage.defaults};}}
function saveShareDesign(){try{localStorage.setItem('spk.share-design.v1',JSON.stringify(shareDesign));}catch(_){toast('Не удалось сохранить оформление.');}}
function syncShareDesign(){
 const fields={sharePreset:'preset',shareAccent:'accent',shareBackground:'background',sharePattern:'pattern',shareLayout:'layout',shareSize:'size',shareDensity:'density'};
 for(const [id,key] of Object.entries(fields))$(id).value=shareDesign[key];$('shareTeachers').checked=shareDesign.teachers;$('shareRooms').checked=shareDesign.rooms;
}
function changeShareDesign(id,value){
 if(shareBusy)return;
 if(id==='sharePreset'&&SpkShareImage.presets[value])shareDesign={...shareDesign,...SpkShareImage.presets[value],preset:value};
 else{const key={shareAccent:'accent',shareBackground:'background',sharePattern:'pattern',shareLayout:'layout',shareSize:'size',shareDensity:'density',shareTeachers:'teachers',shareRooms:'rooms'}[id];if(!key)return;shareDesign={...shareDesign,[key]:value,preset:'custom'};}
 shareDesign=SpkShareImage.normalize(shareDesign);saveShareDesign();syncShareDesign();queueSharePreview();
}
function openShare(){if(!plannerTarget())return;shareRange='day';shareBusy=false;sharePage=0;$('shareDesigner').open=false;syncShareDesign();SpkMotion.showModal($('shareModal'));syncModalBody();renderShare();$('closeShare').focus({preventScroll:true});}
function closeShare(){if(shareBusy)return;sharePreviewToken++;clearTimeout(sharePreviewTimer);SpkMotion.hideModal($('shareModal'),()=>{syncModalBody();sharePages=[];$('sharePreview').innerHTML='';if(!document.body.classList.contains('modal-open'))document.querySelector('[data-action="share"]')?.focus({preventScroll:true});});}
function renderShare(){shareSnapshot=currentSnapshot(shareRange);if(!shareSnapshot)return;sharePage=0;document.querySelectorAll('[data-share-range]').forEach(b=>{b.classList.toggle('active',b.dataset.shareRange===shareRange);b.setAttribute('aria-pressed',String(b.dataset.shareRange===shareRange));});$('shareDescription').textContent=shareSnapshot.title+(shareSnapshot.subgroup?' · '+shareSnapshot.subgroup+' подгруппа':'');queueSharePreview();}
function shareReadyStatus(){return shareRange==='week'?'Каждый день — отдельная картинка. Все изображения отправятся вместе.':'Длинный день разделится на страницы. Все пары сохранятся.';}
function displaySharePage(){
 document.querySelector('[data-share-format="images"]').disabled=shareBusy||!sharePages.length;sharePage=Math.max(0,Math.min(sharePage,sharePages.length-1));const p=sharePages[sharePage];
 if(p){$('sharePreview').innerHTML='<img class="share-image" src="'+p.image+'" alt="'+esc(p.title+(p.total>1?', страница '+p.part+' из '+p.total:''))+'">';$('sharePageLabel').textContent=(sharePage+1)+' / '+sharePages.length+' · '+p.title.split(',')[0]+(p.total>1?' · стр. '+p.part:'');}
 $('sharePrevious').disabled=shareBusy||!p||sharePage===0;$('shareNext').disabled=shareBusy||!p||sharePage===sharePages.length-1;
}
function queueSharePreview(){
 const token=++sharePreviewToken;clearTimeout(sharePreviewTimer);sharePages=[];document.querySelector('[data-share-format="images"]').disabled=true;$('sharePreview').setAttribute('aria-busy','true');$('sharePageLabel').textContent='Предпросмотр…';$('sharePrevious').disabled=true;$('shareNext').disabled=true;
 if(!$('sharePreview').firstChild)$('sharePreview').textContent='Готовим картинку…';$('shareStatus').textContent=shareReadyStatus();
 const snapshot=shareSnapshot,design={...shareDesign};
 sharePreviewTimer=setTimeout(async()=>{try{const pages=await SpkShareImage.renderPages(snapshot,design,()=>token===sharePreviewToken);if(token!==sharePreviewToken||$('shareModal').hidden)return;sharePages=pages.map((p,i)=>({...p,file:shareFile(p.image,i)}));displaySharePage();}catch(_){if(token===sharePreviewToken){$('sharePreview').textContent='Предпросмотр недоступен. Попробуйте другой размер текста.';}}finally{if(token===sharePreviewToken)$('sharePreview').setAttribute('aria-busy','false');}},140);
}
function shareLock(busy){shareBusy=busy;document.querySelectorAll('#shareModal button,#shareModal input,#shareModal select').forEach(b=>b.disabled=busy);$('shareStatus').setAttribute('aria-busy',String(busy));displaySharePage();}
function shareFile(image,index){const raw=atob(image.split(',')[1]),bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));return new File([bytes],'spk-schedule-'+String(index+1).padStart(2,'0')+'.png',{type:'image/png'});}
function downloadBlob(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}
async function sendShare(format){if(shareBusy||!shareSnapshot)return;if(format==='images'&&!sharePages.length){$('shareStatus').textContent='Дождитесь подготовки картинок.';return;}shareLock(true);
 try{
  const s=shareSnapshot,title='Расписание · '+s.title;
  if(format==='images'){
   const files=sharePages.map((p,i)=>p.file||shareFile(p.image,i));
   if(navigator.share&&navigator.canShare?.({files}))await navigator.share({title,files});
   else{const entries={};for(const f of files)entries[f.name]=new Uint8Array(await f.arrayBuffer());downloadBlob(new Blob([fflate.zipSync(entries,{level:0})],{type:'application/zip'}),'spk-schedule-images.zip');}
  }else{
   const payload=format==='link'?{title,url:s.link}:{title,text:SpkPlanner.text(s)};
   if(navigator.share)await navigator.share(payload);
   else if(format==='link'&&navigator.clipboard){await navigator.clipboard.writeText(s.link);$('shareStatus').textContent='Ссылка скопирована.';return;}
   else downloadBlob(new Blob([payload.text||s.link],{type:'text/plain;charset=utf-8'}),'spk-schedule.txt');
  }
  $('shareStatus').textContent='Расписание передано в меню отправки или сохранения.';
 }catch(e){$('shareStatus').textContent=e.name==='AbortError'?'Отправка отменена.':'Не удалось открыть отправку. Попробуйте ещё раз или выберите текст.';}
 finally{shareLock(false);}
}
function closeNavigationDialogs(){SpkAppearance.close();closeSearchFilters(false);shareLock(false);closeShare();closeChooser();closePlanner();closePaletteChooser();closeAbout();}
function openScheduleLink(raw){const p=SpkPlanner.parseLink(raw);if(!p){toast('Не удалось прочитать ссылку на расписание.');return false;}const item=plannerIndex.find(e=>e.kind===p.target.kind&&e.value===p.target.value&&e.campus===p.target.campus);if(!item){toast('Это расписание не найдено. Обновите таблицу и откройте ссылку снова.');return false;}
 closeNavigationDialogs();state.chooserPurpose='group';activateSearchCampus(item.campus);if(item.kind==='group'){state.group=item.value;state.campusGroups[item.campus]=item.value;state.subgroups[item.value]=p.subgroup;state.page='schedule';}else if(item.kind==='teacher'){state.teacher=TeacherIndex.key(item.label);state.teacherSelecting=false;state.page='teachers';}else{state.explore=item;state.page='explore';}state.mode=p.mode;setSelectedDate(p.date,'page',false);persist();window.scrollTo(0,0);if(p.range==='week')openWeekOverview();return true;
}
window.onScheduleLink=()=>{if(!state.data||!native()||typeof College.consumeScheduleLink!=='function')return;const raw=College.consumeScheduleLink();if(raw)openScheduleLink(raw);};
function initPlanner(){
 $('searchFilterIcon').innerHTML=icon('settings');$('searchFilterPanelIcon').innerHTML=icon('settings');$('searchFilterResetIcon').innerHTML=icon('refresh');$('searchFilterToggle').onclick=()=>{if(searchFilterDraft)closeSearchFilters();else openSearchFilters();};$('searchFilterDone').onclick=applySearchFilters;$('searchFilterReset').onclick=()=>{searchFilterDraft={kind:state.chooserPurpose==='reminder'?'group':'all',campus:'all',favorites:false};renderSearchFilters();};
 for(const id of ['searchKind','searchFavorites'])$(id).onchange=e=>changeSearchFilter(id,id==='searchFavorites'?e.target.checked:e.target.value);
 document.querySelectorAll('[data-filter-campus]').forEach(b=>b.onclick=()=>changeSearchFilter('searchCampus',b.dataset.filterCampus));
 $('sharePrevious').innerHTML=icon('left');$('shareNext').innerHTML=icon('arrow');$('sharePrevious').onclick=()=>{sharePage--;displaySharePage();};$('shareNext').onclick=()=>{sharePage++;displaySharePage();};
 for(const id of ['sharePreset','shareAccent','shareBackground','sharePattern','shareLayout','shareSize','shareDensity','shareTeachers','shareRooms'])$(id).addEventListener(id==='shareAccent'||id==='shareBackground'?'input':'change',e=>changeShareDesign(id,e.target.type==='checkbox'?e.target.checked:e.target.value));
 $('shareDesignDone').onclick=()=>{$('shareDesigner').open=false;document.querySelector('.share-scroll').scrollTop=0;$('shareDesigner').querySelector('summary').focus({preventScroll:true});};$('shareDesignReset').onclick=()=>{shareDesign={...SpkShareImage.defaults};saveShareDesign();syncShareDesign();queueSharePreview();};

 $('globalSearch').innerHTML=icon('search')+'<span>Группа, преподаватель, предмет, кабинет</span>';$('closePlanner').innerHTML=icon('close');$('closePlanner').onclick=closePlanner;$('plannerScrim').onclick=closePlanner;$('closeShare').innerHTML=icon('close');$('closeShare').onclick=closeShare;$('shareScrim').onclick=closeShare;
 document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||b.disabled)return;const a=b.dataset.action;
  if(a==='search')openSmartSearch();else if(a==='calendar')openCalendar();else if(a==='share')openShare();else if(a==='week-overview')openWeekOverview();else if(a==='calendar-today'){closePlanner();setSelectedDate(new Date());}else if(a==='search-more'){searchLimit+=80;renderSmartSearch();}else if(a==='open-shared')openScheduleLink($('groupSearch').value);
  else if(b.dataset.searchId)chooseSearchResult(b.dataset.searchId);
  else if(b.dataset.calendarStep){const next=new Date(plannerMonth.getFullYear(),plannerMonth.getMonth()+Number(b.dataset.calendarStep),1,12);if(next.getFullYear()<1000||next.getFullYear()>9999)return;plannerMonth=next;$('plannerContent').innerHTML=calendarHtml();}
  else if(b.dataset.calendarDate){const d=SpkPlanner.date(b.dataset.calendarDate);if(d){const manual=!$('calendarJump');closePlanner();setSelectedDate(d,'day',!manual);}}else if(b.dataset.shareRange&&!shareBusy){shareRange=b.dataset.shareRange;renderShare();}else if(b.dataset.shareFormat)sendShare(b.dataset.shareFormat);
 });
 document.addEventListener('change',e=>{if(e.target.id==='calendarJump'){const d=SpkPlanner.date(e.target.value);if(d){closePlanner();setSelectedDate(d);}else toast('Проверьте выбранную дату.');}});
}
