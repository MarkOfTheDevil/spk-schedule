'use strict';
(function(root){
  const BACKUP='spk.schedule.web.v1';
  function open(){return new Promise((resolve,reject)=>{
    const r=indexedDB.open('spk-offline-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('schedule');
    r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.onblocked=()=>reject(new Error('Хранилище занято.'));
  });}
  async function load(){
    let idb=null,backup=null;
    try{const db=await open();try{idb=await new Promise((resolve,reject)=>{const r=db.transaction('schedule').objectStore('schedule').get('active');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}finally{db.close();}}catch(_){}
    try{backup=JSON.parse(localStorage.getItem(BACKUP)||'null');}catch(_){}
    const valid=[idb,backup].filter(x=>root.SpkParser.validate(x));valid.sort((a,b)=>b.fetchedAt-a.fetchedAt);return valid[0]||null;
  }
  async function save(data){
    if(!root.SpkParser.validate(data))throw new Error('Не удалось проверить расписание.');
    try{const db=await open();try{await new Promise((resolve,reject)=>{const tx=db.transaction('schedule','readwrite');tx.objectStore('schedule').put(data,'active');tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Запись прервана.'));});}finally{db.close();}
      try{localStorage.removeItem(BACKUP);}catch(_){}return;
    }catch(_){}
    try{localStorage.setItem(BACKUP,JSON.stringify(data));}catch(_){throw new Error('Не удалось сохранить файл на устройстве. Освободите место и попробуйте снова.');}
  }
  root.SpkStore={load,save};
})(typeof window==='undefined'?globalThis:window);
