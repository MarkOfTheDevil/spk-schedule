'use strict';
window.SpkShareImage=(()=>{
 const W=540,M=24,BOTTOM=1870;
 const presets={
  paper:{accent:'#94c900',background:'#f5f6ef',pattern:'plain'},
  graphite:{accent:'#c8f275',background:'#171c20',pattern:'plain'},
  lavender:{accent:'#8165d6',background:'#f2edf9',pattern:'gradient'},
  ocean:{accent:'#35b8db',background:'#102c3c',pattern:'gradient'},
  peach:{accent:'#d87752',background:'#fff0e7',pattern:'plain'},
  neon:{accent:'#56efd5',background:'#111628',pattern:'gradient'}
 };
 const defaults={preset:'paper',...presets.paper,layout:'cards',size:'normal',density:'comfortable',teachers:true,rooms:true};
 const hex=(v,f)=>/^#[\da-f]{6}$/i.test(v||'')?v.toLowerCase():f;
 function normalize(value){const v=value&&typeof value==='object'?value:{};return {preset:presets[v.preset]||v.preset==='custom'?v.preset:'paper',accent:hex(v.accent,defaults.accent),background:hex(v.background,defaults.background),pattern:['plain','gradient','dots'].includes(v.pattern)?v.pattern:'plain',layout:v.layout==='list'?'list':'cards',size:['normal','large','xl'].includes(v.size)?v.size:'normal',density:v.density==='compact'?'compact':'comfortable',teachers:v.teachers!==false,rooms:v.rooms!==false};}
 function rgb(hex){return [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));}
 function mix(a,b,amount){return '#'+rgb(a).map((v,i)=>Math.round(v+(rgb(b)[i]-v)*amount).toString(16).padStart(2,'0')).join('');}
 function luminance(color){const c=rgb(color).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;});return c[0]*.2126+c[1]*.7152+c[2]*.0722;}
 function contrast(a,b){const x=luminance(a),y=luminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
 function contrastInk(bg){return contrast('#18221f',bg)>=4.5?'#18221f':luminance(bg)>.179?'#000000':'#ffffff';}
 function readableMix(ink,bg){let amount=.18;while(amount>0&&contrast(mix(ink,bg,amount),bg)<4.5)amount=Math.max(0,amount-.01);return mix(ink,bg,amount);}
 function safeTint(bg,accent,amount,ink){while(amount>0&&contrast(ink,mix(bg,accent,amount))<4.5)amount=Math.max(0,amount-.01);return mix(bg,accent,amount);}
 function lines(ctx,text,width){const out=[];let line='';for(const word of String(text||'').split(/\s+/)){if(!word)continue;if(ctx.measureText(line+(line?' ':'')+word).width<=width){line+=(line?' ':'')+word;continue;}if(line){out.push(line);line='';}if(ctx.measureText(word).width<=width){line=word;continue;}for(const ch of word){if(ctx.measureText(line+ch).width>width&&line){out.push(line);line='';}line+=ch;}}if(line)out.push(line);return out;}
 function rounded(c,x,y,w,h,r){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();}
 async function renderPages(s,value,isCurrent=()=>true){
  const style=normalize(typeof value==='string'?{...defaults,accent:value}:value),scale={normal:1,large:1.15,xl:1.3}[style.size],gap=style.density==='compact'?9:16;
  const ink=contrastInk(style.background),dark=ink==='#ffffff',card=mix(style.background,'#ffffff',dark?.065:.7),cardInk=contrastInk(card),muted=readableMix(ink,style.background),cardMuted=readableMix(cardInk,card),rule=mix(style.background,ink,.18);
  const measure=document.createElement('canvas').getContext('2d'),result=[];
  function measured(text,size,bold,color,kind='text'){size=Math.round(size*scale);measure.font=(bold?'700 ':'400 ')+size+'px sans-serif';return {lines:lines(measure,text,W-2*M-32),size,bold,color,kind};}
  for(const d of s.days){
   if(!isCurrent())return [];
   const titleSize=s.title.length>55?23:28;measure.font='700 '+titleSize+'px sans-serif';const titleLines=lines(measure,s.title,W-2*M);measure.font='700 20px sans-serif';const dayLines=lines(measure,d.title,W-2*M);
   const headerHeight=76+titleLines.length*(titleSize+7)+dayLines.length*27+(s.subgroup?24:0),pages=[];let items=[],y=headerHeight;
   const units=d.lessons.map(l=>{const unit=[measured(l.number+' ПАРА   ·   '+l.start+'–'+l.end,13,true,cardMuted,'slot')];for(const v of l.variants){unit.push(measured(v.subject,19,true,cardInk));if(style.teachers&&v.teacher)unit.push(measured(v.teacher,14,false,cardMuted));if(style.rooms&&v.room)unit.push(measured('Ауд. '+v.room,14,false,cardMuted));const group=v.groups?v.groups.map(g=>g.name+(g.subgroups.includes(0)?'':' · '+g.subgroups.join(', ')+' подгр.')).join('; '):v.subgroup?v.subgroup+' подгруппа':'Вся группа';unit.push(measured(group,12,false,cardMuted,'group'));}return unit;});
   if(!units.length)units.push([measured('Занятий нет',20,true,cardInk),measured('Свободный день',14,false,cardMuted)]);
   function nextPage(){if(items.length)pages.push({items,height:Math.max(470,y+103)});items=[];y=headerHeight+24;}
   let unitId=0;
   for(const unit of units){unitId++;const height=unit.reduce((n,b)=>n+b.lines.length*(Math.ceil(b.size*1.4))+6,0)+24;
    if(y+height>BOTTOM&&items.length&&height<BOTTOM-headerHeight-24)nextPage();
    y+=12;
    for(const b of unit){const lh=Math.ceil(b.size*1.4);for(const line of b.lines){if(y+lh>BOTTOM&&items.length){nextPage();y+=12;}items.push({...b,text:line,y,unitId});y+=lh;}y+=6;}
    y+=12+gap;
   }
   if(items.length)pages.push({items,height:Math.max(470,y+103)});
   if(result.length+pages.length>20)throw new Error('Too many image pages');
   for(let part=0;part<pages.length;part++){
    if(!isCurrent())return [];
    const p=pages[part],canvas=document.createElement('canvas');canvas.width=W*2;canvas.height=Math.min(4096,Math.ceil(p.height)*2);const c=canvas.getContext('2d');c.scale(2,2);c.textBaseline='top';c.fillStyle=style.background;c.fillRect(0,0,W,p.height);
    if(style.pattern==='gradient'){const grad=c.createLinearGradient(0,0,W,p.height);grad.addColorStop(0,safeTint(style.background,style.accent,.12,muted));grad.addColorStop(.5,style.background);grad.addColorStop(1,safeTint(style.background,style.accent,.07,muted));c.fillStyle=grad;c.fillRect(0,0,W,p.height);}
    if(style.pattern==='dots'){c.fillStyle=safeTint(style.background,ink,.09,muted);for(let x=12;x<W;x+=18)for(let yy=12;yy<p.height;yy+=18){c.beginPath();c.arc(x,yy,.8,0,Math.PI*2);c.fill();}}
    c.fillStyle=style.accent;rounded(c,M,24,30,5,2);c.fill();c.fillStyle=muted;c.font='700 11px sans-serif';c.fillText('РАСПИСАНИЕ  /  '+(s.target.campus==='crk'?'ЦРК':'СПК')+' · СЕВЕРСК',M+42,21);
    c.fillStyle=ink;c.font='700 '+titleSize+'px sans-serif';titleLines.forEach((line,i)=>c.fillText(line,M,50+i*(titleSize+7)));
    let hy=57+titleLines.length*(titleSize+7);if(s.subgroup){c.font='400 13px sans-serif';c.fillStyle=muted;c.fillText(s.subgroup+' подгруппа',M,hy);hy+=24;}
    c.font='700 20px sans-serif';c.fillStyle=ink;dayLines.forEach((line,i)=>c.fillText(line,M,hy+i*27));hy+=dayLines.length*27;c.font='400 12px sans-serif';c.fillStyle=muted;c.fillText((d.week==='even'?'Чётная':'Нечётная')+' неделя'+(s.manual?' · выбрана вручную':''),M,hy+3);
    if(part){c.font='700 12px sans-serif';c.fillText('Продолжение · '+(part+1)+' из '+pages.length,M,headerHeight-2);}
    const grouped=[];for(const item of p.items){let group=grouped[grouped.length-1];if(!group||group[0].unitId!==item.unitId){group=[];grouped.push(group);}group.push(item);}
    for(const group of grouped){const first=group[0],last=group[group.length-1],top=first.y-10,height=last.y+Math.ceil(last.size*1.4)+12-top;
     if(style.layout==='cards'){c.fillStyle=card;rounded(c,M,top,W-2*M,height,14);c.fill();c.strokeStyle=rule;c.lineWidth=.7;c.stroke();c.fillStyle=style.accent;rounded(c,M,top+13,3,Math.max(12,height-26),1);c.fill();}
     else{c.strokeStyle=rule;c.beginPath();c.moveTo(M,top);c.lineTo(W-M,top);c.stroke();}
     for(const item of group){c.fillStyle=style.layout==='list'?(item.bold?ink:muted):item.color;c.font=(item.bold?'700 ':'400 ')+item.size+'px sans-serif';c.fillText(item.text,M+16,item.y);}
    }
    c.fillStyle=muted;c.font='400 10px sans-serif';c.fillText('По текущей таблице колледжа · spospk.ru',M,p.height-65);
    if(s.fetchedAt)c.fillText('Сохранено '+new Date(s.fetchedAt).toLocaleString('ru-RU'),M,p.height-49);
    if(s.stale)c.fillText('Источник недоступен · сохранённая версия',M,p.height-33);
    c.textAlign='right';c.fillText((s.days.length>1?String(s.days.indexOf(d)+1).padStart(2,'0')+' / '+String(s.days.length).padStart(2,'0'):'')+(pages.length>1?' · стр. '+(part+1)+'/'+pages.length:''),W-M,p.height-20);
    result.push({image:canvas.toDataURL('image/png'),date:d.date,title:d.title,part:part+1,total:pages.length});canvas.width=1;canvas.height=1;await new Promise(r=>setTimeout(r,0));
   }
  }
  return result;
 }
 async function render(s,style){return (await renderPages(s,style)).map(p=>p.image);}
 return {render,renderPages,lines,presets,defaults,normalize,contrastInk,luminance,contrast,readableMix};
})();
