'use strict';
window.SpkMotion=(()=>{
 const root=document.documentElement,media=window.matchMedia('(prefers-reduced-motion: reduce)');
 const running=new Set(),closing=new Map(),contentJobs=new Map(),resultsJobs=new Map(),sliders=new Map(),epoch=Date.now();
 const ease='cubic-bezier(.4,0,.2,1)';
 let preference=true,systemAllowed=true,nativeVisible=true;
 const reduced=()=>!systemAllowed||media.matches;
 const enabled=()=>preference&&!reduced();
 const active=()=>enabled()&&nativeVisible&&!document.hidden;
 function cancelEntry(entry){
  entry.animation.onfinish=null;entry.animation.oncancel=null;entry.animation.cancel();
  running.delete(entry);entry.element.classList.remove('motion-layer');
 }
 function cancelElement(element){for(const entry of [...running])if(entry.element===element)cancelEntry(entry);}
 function cancelWithin(parent){for(const entry of [...running])if(!entry.element.isConnected||parent&&parent.contains(entry.element))cancelEntry(entry);}
 function play(element,frames,options,done){
  if(!active()||!element||typeof element.animate!=='function')return null;
  cancelElement(element);element.classList.add('motion-layer');
  const animation=element.animate(frames,Object.assign({duration:440,easing:ease,fill:'both'},options));
  const entry={element,animation};running.add(entry);
  animation.onfinish=()=>{cancelEntry(entry);if(done)done();};
  animation.oncancel=()=>{running.delete(entry);element.classList.remove('motion-layer');};
  return animation;
 }
 function update(){
  root.dataset.motion=enabled()?'on':'off';
  root.dataset.motionPaused=nativeVisible&&!document.hidden?'false':'true';
  if(!active()){
   for(const job of [...contentJobs.values()])job.finish();
   for(const job of [...resultsJobs.values()])job.finish();
   for(const job of [...closing.values()])job.finish();
   for(const entry of [...running])cancelEntry(entry);
  }
  document.dispatchEvent(new CustomEvent('spkmotionchange'));
 }
 // Keep the actual buttons and moving highlight alive across filter changes.
 function patchControls(oldNode,newNode){
  if(oldNode.nodeType!==newNode.nodeType||oldNode.nodeName!==newNode.nodeName){oldNode.replaceWith(newNode.cloneNode(true));return;}
  if(oldNode.nodeType!==1){if(oldNode.nodeValue!==newNode.nodeValue)oldNode.nodeValue=newNode.nodeValue;return;}
  for(const attr of [...oldNode.attributes])if(attr.name!=='data-slider-ready'&&!newNode.hasAttribute(attr.name))oldNode.removeAttribute(attr.name);
  for(const attr of [...newNode.attributes])if(oldNode.getAttribute(attr.name)!==attr.value)oldNode.setAttribute(attr.name,attr.value);
  const oldChildren=[...oldNode.childNodes].filter(n=>!(n.nodeType===1&&n.hasAttribute('data-motion-owned'))),fresh=[...newNode.childNodes];
  fresh.forEach((node,i)=>{if(oldChildren[i])patchControls(oldChildren[i],node);else oldNode.appendChild(node.cloneNode(true));});
  for(let i=fresh.length;i<oldChildren.length;i++)oldChildren[i].remove();
 }
 const resizeObserver=typeof ResizeObserver==='function'?new ResizeObserver(entries=>entries.forEach(e=>positionSlider(e.target,false))):null;
 function positionSlider(group,animate){
  if(!group.isConnected)return;
  const button=group.querySelector('button.active');if(!button)return;
  let item=sliders.get(group);
  if(!item){
   const marker=document.createElement('span');marker.className='selection-glider';marker.setAttribute('data-motion-owned','');marker.setAttribute('aria-hidden','true');
   group.prepend(marker);group.dataset.sliderReady='true';item={marker,geometry:null};sliders.set(group,item);
   if(resizeObserver)resizeObserver.observe(group);
  }
  const target={x:button.offsetLeft,y:button.offsetTop,width:button.offsetWidth,height:button.offsetHeight};
  if(!target.width||!target.height)return;
  if(item.geometry&&Object.keys(target).every(k=>target[k]===item.geometry[k]))return;
  const marker=item.marker,rect=marker.getBoundingClientRect(),parent=group.getBoundingClientRect();
  const from={x:rect.left-parent.left-group.clientLeft,y:rect.top-parent.top-group.clientTop,width:rect.width,height:rect.height};
  const wasReady=!!item.geometry;item.geometry=target;
  cancelElement(marker);
  marker.style.width=target.width+'px';marker.style.height=target.height+'px';marker.style.borderRadius=getComputedStyle(button).borderRadius;
  const end='translate3d('+target.x+'px,'+target.y+'px,0)';marker.style.transform=end;
  if(animate&&wasReady&&active())play(marker,[
   {transform:'translate3d('+from.x+'px,'+from.y+'px,0) scale('+from.width/target.width+','+from.height/target.height+')'},
   {transform:end+' scale(1,1)'}
  ],{duration:460});
 }
 function syncSliders(container,animate){
  for(const [group,item] of sliders)if(!group.isConnected){cancelElement(item.marker);if(resizeObserver)resizeObserver.unobserve(group);sliders.delete(group);}
  container.querySelectorAll('[data-slider]').forEach(group=>positionSlider(group,animate));
 }
 window.addEventListener('resize',()=>syncSliders(document,false));
 if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>syncSliders(document,false));
 function applyResults(container,html){cancelWithin(container);if(container.innerHTML!==html)container.innerHTML=html;document.dispatchEvent(new CustomEvent('spkresultschange'));}
 function revealLessons(container,done){
  const heading=container.querySelector('.day-heading');
  play(heading,[{opacity:0,transform:'translate3d(-16px,0,0)'},{opacity:1,transform:'translate3d(0,0,0)'}],{duration:360});
  play(container.querySelector('.now-next'),[{opacity:0},{opacity:1}],{duration:360});
  const rows=[...container.querySelectorAll('.lesson,.empty')];
  rows.forEach((row,i)=>play(row,[{opacity:0,transform:'translate3d(-42px,0,0)'},{opacity:1,transform:'translate3d(0,0,0)'}],{duration:500,delay:90+i*75},i===rows.length-1?done:null));
  container.querySelectorAll('.monday-events,.footer-note').forEach(el=>play(el,[{opacity:0},{opacity:1}],{duration:360,delay:90}));
  return rows.length?590+(rows.length-1)*75:360;
 }
 function replaceResults(container,html,animate,initial=false,direction=0){
  const viewport=container.closest('.timetable-viewport');
  let job=resultsJobs.get(container);
  if(!active()||typeof container.animate!=='function'){
   if(job){job.pending=html;job.finish();}else applyResults(container,html);return;
  }
  if(job){job.pending=html;if(animate)job.direction=direction;if(!animate||job.phase==='out')return;clearTimeout(job.timer);}
  else{
   if(!animate){applyResults(container,html);return;}
   job={pending:html,timer:null,phase:'',direction,finish:()=>{
    if(resultsJobs.get(container)!==job)return;
    resultsJobs.delete(container);clearTimeout(job.timer);cancelWithin(container);delete container.dataset.resultsPhase;
    if(viewport)delete viewport.dataset.swipeMotion;
    const latest=job.pending;job.pending=null;if(latest!==null)applyResults(container,latest);
   }};
   resultsJobs.set(container,job);
  }
  const enter=()=>{
   if(resultsJobs.get(container)!==job)return;
   clearTimeout(job.timer);const latest=job.pending;job.pending=null;applyResults(container,latest);
   job.phase='in';container.dataset.resultsPhase='in';
   if(viewport){if(job.direction)viewport.dataset.swipeMotion='';else delete viewport.dataset.swipeMotion;}
   if(job.direction){
    play(container,[{opacity:0,transform:'translate3d('+(job.direction*20)+'px,0,0)'},{opacity:1,transform:'translate3d(0,0,0)'}],{duration:420},job.finish);
    job.timer=setTimeout(job.finish,540);
   }else{const duration=revealLessons(container,job.finish);job.timer=setTimeout(job.finish,duration+120);}
  };
  if(initial){enter();return;}
  // The stationary viewport clips the list with soft side edges during swipes.
  // Short travel keeps cards away from the screen edges; selectors stay still.
  const style=getComputedStyle(container);job.phase='out';container.dataset.resultsPhase='out';
  if(viewport){if(direction)viewport.dataset.swipeMotion='';else delete viewport.dataset.swipeMotion;}
  play(container,[{opacity:style.opacity,transform:style.transform},{opacity:0,transform:'translate3d('+(-direction*20)+'px,0,0)'}],{duration:direction?170:120},enter);
  job.timer=setTimeout(enter,direction?270:220);
 }
 function replaceTimetable(container,html,kind,after){
  const template=document.createElement('template');template.innerHTML=html;
  const fresh=template.content.querySelector('.timetable-view');
  if(!fresh){for(const job of [...resultsJobs.values()])job.finish();return false;}
  const pageJob=contentJobs.get(container);if(pageJob)pageJob.finish();
  const previous=container.querySelector('.timetable-view');
  if(previous&&previous.dataset.timetableKey===fresh.dataset.timetableKey&&kind!=='page'){
   patchControls(previous.querySelector('.timetable-controls'),fresh.querySelector('.timetable-controls'));
   syncSliders(previous,!!kind);
   replaceResults(previous.querySelector('.timetable-results'),fresh.querySelector('.timetable-results').innerHTML,!!kind,false,kind==='swipe-next'?1:kind==='swipe-previous'?-1:0);
  }else{
   for(const job of [...resultsJobs.values()])job.finish();
   applyContent(container,{html,resetScroll:kind==='page'});syncSliders(container,false);
   const result=container.querySelector('.timetable-results');replaceResults(result,result.innerHTML,!!kind,true);
  }
  if(after)after();return true;
 }
 function applyContent(container,pending){
  cancelWithin(container);
  root.style.setProperty('--motion-flow-delay',(-(Date.now()-epoch)%36000)+'ms');
  if(container.innerHTML!==pending.html)container.innerHTML=pending.html;
  if(pending.resetScroll)window.scrollTo(0,0);
  syncSliders(container,false);
  if(pending.after)pending.after();
 }
 // Fade the actual old DOM before replacing it. One parent carries every
 // label, time and card, without stagger or per-card layout measurements.
 function replaceContent(container,html,kind='',after){
  if(replaceTimetable(container,html,kind,after))return;
  const pending={html,resetScroll:kind==='page',after};
  let job=contentJobs.get(container);
  if(!active()||typeof container.animate!=='function'){
   if(job){job.pending=pending;job.finish();}else applyContent(container,pending);
   return;
  }
  if(job){
   pending.resetScroll=pending.resetScroll||!!(job.pending&&job.pending.resetScroll);
   job.pending=pending;
   // Refreshes wait; repeated choices during fade-out change the destination
   // without restarting its clock or adding another animation.
   if(!kind||job.phase==='out')return;
   clearTimeout(job.timer);
  }else{
   if(!kind||container.innerHTML===html){applyContent(container,pending);return;}
   job={pending,timer:null,phase:'',finish:()=>{
    if(contentJobs.get(container)!==job)return;
    contentJobs.delete(container);clearTimeout(job.timer);cancelElement(container);
    delete container.dataset.motionPhase;
    const latest=job.pending;job.pending=null;if(latest)applyContent(container,latest);
   }};
   contentJobs.set(container,job);
  }
  const style=getComputedStyle(container),from={opacity:style.opacity,transform:style.transform};
  const enter=()=>{
   if(contentJobs.get(container)!==job||job.phase!=='out')return;
   clearTimeout(job.timer);
   const latest=job.pending;job.pending=null;applyContent(container,latest);
   job.phase='in';container.dataset.motionPhase='in';
   play(container,[{opacity:0,transform:'translate3d(18px,0,0)'},{opacity:1,transform:'translate3d(0,0,0)'}],{duration:460},job.finish);
   job.timer=setTimeout(job.finish,560);
  };
  job.phase='out';container.dataset.motionPhase='out';
  play(container,[from,{opacity:0,transform:'translate3d(0,-8px,0)'}],{duration:180},enter);
  job.timer=setTimeout(enter,280);
 }
 function showModal(modal){
  const job=closing.get(modal),wasVisible=!modal.hidden;
  const sheet=modal.querySelector('.sheet'),scrim=modal.querySelector('.scrim');
  const current=wasVisible?{opacity:getComputedStyle(sheet).opacity,transform:getComputedStyle(sheet).transform}:{opacity:0,transform:'translate3d(0,40px,0)'};
  const scrimOpacity=wasVisible?getComputedStyle(scrim).opacity:0;
  if(job){closing.delete(modal);clearTimeout(job.timer);}
  cancelWithin(modal);modal.classList.remove('is-closing');modal.hidden=false;
  play(scrim,[{opacity:scrimOpacity},{opacity:1}],{duration:360});
  play(sheet,[current,{opacity:1,transform:'translate3d(0,0,0)'}],{duration:440});
 }
 function hideModal(modal,onHidden){
  if(closing.has(modal))return;
  if(modal.hidden||!active()||typeof modal.animate!=='function'){cancelWithin(modal);modal.hidden=true;modal.classList.remove('is-closing');onHidden();return;}
  const sheet=modal.querySelector('.sheet'),scrim=modal.querySelector('.scrim');
  const current={opacity:getComputedStyle(sheet).opacity,transform:getComputedStyle(sheet).transform},scrimOpacity=getComputedStyle(scrim).opacity;
  cancelWithin(modal);modal.classList.add('is-closing');
  const job={timer:null,finish:()=>{
   if(closing.get(modal)!==job)return;
   closing.delete(modal);clearTimeout(job.timer);cancelWithin(modal);
   modal.hidden=true;modal.classList.remove('is-closing');onHidden();
  }};
  closing.set(modal,job);
  play(sheet,[current,{opacity:0,transform:'translate3d(0,30px,0)'}],{duration:300},job.finish);
  play(scrim,[{opacity:scrimOpacity},{opacity:0}],{duration:300});
  job.timer=setTimeout(job.finish,400);
 }
 function pulse(element){play(element,[{transform:'scale(1)'},{transform:'scale(1.18)',offset:.45},{transform:'scale(1)'}],{duration:360});}
 document.addEventListener('visibilitychange',update);
 if(media.addEventListener)media.addEventListener('change',update);else if(media.addListener)media.addListener(update);
 return Object.freeze({enabled,reduced,replaceContent,showModal,hideModal,pulse,
  setEnabled:value=>{preference=!!value;update();},
  setSystemAllowed:value=>{systemAllowed=!!value;update();},
  setNativeVisible:value=>{nativeVisible=!!value;update();}
 });
})();
