(function(root,factory){
  'use strict';
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.TeacherIndex=api;
})(typeof window!=='undefined'?window:this,function(){
  'use strict';
  // Spacing, initials punctuation and е/ё vary in the college's workbook.
  function key(name){return String(name||'').toLocaleUpperCase('ru-RU').replace(/Ё/g,'Е').replace(/[\s.\-–—]/g,'');}
  function build(data){
    const teachers=new Map();
    for(const group of data.groups||[]){
      for(const week of ['even','odd']){
        for(let day=0;day<7;day++){
          for(const pair of group.weeks[week][String(day)]||[]){
            for(const variant of pair.variants||[]){
              const name=String(variant.teacher||'').trim();const id=key(name);
              if(!id)continue;
              let teacher=teachers.get(id);
              if(!teacher){teacher={id,name,aliases:new Set(),groupIds:new Set(),weeks:{even:{},odd:{}}};teachers.set(id,teacher);}
              teacher.aliases.add(name);teacher.groupIds.add(group.id);
              const slots=teacher.weeks[week][day]||(teacher.weeks[week][day]=new Map());
              const slotId=JSON.stringify([pair.number,pair.start,pair.end]);
              let slot=slots.get(slotId);
              if(!slot){slot={number:pair.number,start:pair.start,end:pair.end,entries:new Map()};slots.set(slotId,slot);}
              const entryId=JSON.stringify([variant.subject,variant.room]);
              let entry=slot.entries.get(entryId);
              if(!entry){entry={subject:variant.subject,room:variant.room,groups:new Map()};slot.entries.set(entryId,entry);}
              let groupEntry=entry.groups.get(group.id);
              if(!groupEntry){groupEntry={id:group.id,name:group.name,subgroups:new Set()};entry.groups.set(group.id,groupEntry);}
              groupEntry.subgroups.add(variant.subgroup);
            }
          }
        }
      }
    }
    const all=Array.from(teachers.values());
    for(const teacher of all){
      teacher.aliases=Array.from(teacher.aliases);teacher.groupCount=teacher.groupIds.size;delete teacher.groupIds;
      for(const week of ['even','odd'])for(let day=0;day<7;day++){
        const slots=teacher.weeks[week][day];
        teacher.weeks[week][day]=slots?Array.from(slots.values()).map(slot=>({number:slot.number,start:slot.start,end:slot.end,variants:Array.from(slot.entries.values()).map(entry=>({subject:entry.subject,room:entry.room,groups:Array.from(entry.groups.values()).map(g=>({id:g.id,name:g.name,subgroups:Array.from(g.subgroups).sort()})).sort((a,b)=>a.name.localeCompare(b.name,'ru',{numeric:true}))}))})).sort((a,b)=>a.start.localeCompare(b.start)||a.number-b.number||a.end.localeCompare(b.end)):[];
      }
    }
    return all.sort((a,b)=>a.name.localeCompare(b.name,'ru'));
  }
  function search(list,query){const q=key(query);return list.filter(t=>t.aliases.some(alias=>key(alias).includes(q)));}
  return {key,build,search};
});
