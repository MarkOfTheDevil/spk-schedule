'use strict';
// Web Push is opt-in and needs an actual server. iOS does not run JS timers in the background.
const PwaPush=(()=>{
 let config=null,reason='';
 const standalone=()=>matchMedia('(display-mode: standalone)').matches||navigator.standalone===true;
 const supported=()=>window.isSecureContext&&'serviceWorker' in navigator&&'PushManager' in window&&'Notification' in window;
 const ensure=(v,message)=>{if(!v)throw Error(message);};
 const b64=s=>Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4)),c=>c.charCodeAt(0));
 async function api(name,method='GET',payload){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
  try{const res=await fetch('api/push/'+name,{method,headers:payload?{'Content-Type':'application/json'}:undefined,body:payload?JSON.stringify(payload):undefined,signal:controller.signal,cache:'no-store'});const data=await res.json().catch(()=>({}));if(!res.ok)throw Error(data.error||'Push-сервер недоступен.');return data;}
  finally{clearTimeout(timer);}
 }
 async function init(){
  if(!supported()){reason='Устройство не поддерживает Web Push.';return false;}
  if(!standalone()){reason='Откройте приложение с иконки на экране «Домой».';return false;}
  try{config=await api('config');ensure(config.enabled&&config.publicKey,'Сервер отправки не настроен.');const registration=await navigator.serviceWorker.ready;return !!(await registration.pushManager.getSubscription())&&Notification.permission==='granted';}
  catch(e){reason=e.message;return false;}
 }
 function status(){
  if(!supported())return 'Web Push не поддерживается этой версией браузера.';
  if(!standalone())return 'Web Push работает только после установки сайта на экран «Домой» и запуска с иконки.';
  if(Notification.permission==='denied')return 'Уведомления запрещены в настройках iPhone.';
  if(config?.enabled)return 'Push-сервер подключён. Доставка зависит от сети и настроек уведомлений iOS.';
  return reason||'Для Web Push нужно подключить отдельный сервер.';
 }
 async function toggle(opts){
  ensure(supported(),'Web Push не поддерживается на этом устройстве.');ensure(standalone(),'Сначала добавьте приложение на экран «Домой».');
  if(!opts.enabled){const reg=await navigator.serviceWorker.ready,sub=await reg.pushManager.getSubscription();if(sub){await api('unsubscribe','POST',{endpoint:sub.endpoint});await sub.unsubscribe();}return false;}
  ensure(config?.enabled&&config.publicKey,'Сервер Web Push ещё не настроен. Используйте напоминание в Календаре.');
  // Must originate from a user gesture, before waiting for service worker or fetch.
  const permission=Notification.permission==='default'?await Notification.requestPermission():Notification.permission;
  ensure(permission==='granted','Вы не разрешили уведомления для приложения.');
  const reg=await navigator.serviceWorker.ready;let sub=await reg.pushManager.getSubscription();
  if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64(config.publicKey)});
  try{await api('subscribe','POST',{subscription:sub.toJSON(),group:opts.group,subgroup:opts.subgroup,hour:opts.hour,minute:opts.minute,anchorDate:opts.anchorDate,anchorEven:opts.anchorEven,timezone:Intl.DateTimeFormat().resolvedOptions().timeZone});}
  catch(e){await sub.unsubscribe();throw e;}
  return true;
 }
 async function updateIfEnabled(r,anchorDate,anchorEven){
  if(!r.enabled||!config?.enabled)return;
  const reg=await navigator.serviceWorker.ready,sub=await reg.pushManager.getSubscription();if(!sub)return;
  await api('subscribe','POST',{subscription:sub.toJSON(),group:r.group,subgroup:r.subgroup,hour:r.hour,minute:r.minute,anchorDate,anchorEven,timezone:Intl.DateTimeFormat().resolvedOptions().timeZone});
 }
 async function test(){ensure(config?.enabled,'Push-сервер не настроен.');const reg=await navigator.serviceWorker.ready,sub=await reg.pushManager.getSubscription();ensure(sub,'Включите уведомления.');return api('test','POST',{endpoint:sub.endpoint});}
 function ical(v){return String(v).replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');}
 function fmt(d){return d.getFullYear()+String(d.getMonth()+1).padStart(2,'0')+String(d.getDate()).padStart(2,'0')+'T'+String(d.getHours()).padStart(2,'0')+String(d.getMinutes()).padStart(2,'0')+'00';}
 function downloadCalendar(r){
  const now=new Date(),date=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1,r.hour,r.minute),end=new Date(+date+10*60000);
  const rows=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//SPK//iPhone PWA//RU','CALSCALE:GREGORIAN','BEGIN:VEVENT','UID:spk-reminder-'+Date.now()+'@local','DTSTAMP:'+new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,''),'DTSTART:'+fmt(date),'DTEND:'+fmt(end),'RRULE:FREQ=DAILY','SUMMARY:'+ical('Расписание СПК — пары на завтра'),'DESCRIPTION:'+ical('Откройте приложение и проверьте актуальное расписание на завтра. Список пар не вложен.'),'BEGIN:VALARM','TRIGGER:PT0S','ACTION:DISPLAY','DESCRIPTION:Проверьте расписание СПК','END:VALARM','END:VEVENT','END:VCALENDAR',''];
  const url=URL.createObjectURL(new Blob([rows.join('\r\n')],{type:'text/calendar;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='spk-reminder.ics';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
 }
 function renderSettings(state,esc,icon){
  const r=state.reminder,group=state.data?.groups.find(g=>g.id===r.group),time=String(r.hour).padStart(2,'0')+':'+String(r.minute).padStart(2,'0');
  return '<section class="settings-card reminder-card"><div class="reminder-title"><h3>Пары на завтра</h3><button class="reminder-switch '+(r.enabled?'on':'')+'" data-action="reminder-toggle" role="switch" aria-label="Web Push уведомления" aria-checked="'+r.enabled+'" '+(state.reminderPending?'disabled':'')+'><span></span></button></div><p>Можно добавить напоминание в Календарь. Автоматическая отправка списка пар при закрытом приложении доступна, если подключён сервер Push.</p>'+
   '<div class="reminder-field"><label for="reminderTime">Время напоминания</label><div class="reminder-time-control"><span aria-hidden="true">'+time+'</span><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><input type="time" id="reminderTime" value="'+time+'" step="60" aria-label="Время уведомления"></div></div>'+
   '<button class="reminder-group" data-action="reminder-group"><span>Группа для уведомлений</span><strong>'+esc(group?.name||'Выбрать группу')+'</strong>'+icon('chevron')+'</button><div class="week-tabs reminder-subgroups">'+[0,1,2].map(n=>'<button data-reminder-subgroup="'+n+'" class="'+(r.subgroup===n?'active':'')+'" aria-pressed="'+(r.subgroup===n)+'">'+(n===0?'Все':n+' подгр.')+'</button>').join('')+'</div>'+
   '<p class="pwa-note pwa-notification-status" role="status">'+esc(status())+'</p>'+(state.reminderMessage?'<p class="reminder-message">'+esc(state.reminderMessage)+'</p>':'')+
   '<div class="pwa-reminder-buttons"><button class="text-button" data-action="reminder-test" '+(!r.enabled?'disabled':'')+'>Тест Push</button><button class="text-button" data-action="reminder-calendar">Напоминание в Календарь</button></div><p class="pwa-note">Файл .ics добавляет обычное повторяющееся напоминание без списка пар. Его нужно импортировать в Календарь iPhone.</p></section>';
 }
 return {init,status,renderSettings,toggle,test,updateIfEnabled,downloadCalendar};
})();
