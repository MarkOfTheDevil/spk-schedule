(function(root,factory){'use strict';const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.SpkPlanner=api;})(typeof window!=='undefined'?window:this,function(){
 'use strict';
 const weekdays=['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'];
 const key=s=>String(s||'').toLocaleUpperCase('ru-RU').replace(/Ё/g,'Е').replace(/[^\p{L}\p{N}]/gu,'');
 const dateKey=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
 function date(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(String(value)))return null;const d=new Date(value+'T12:00:00');return !isNaN(d)&&d.getFullYear()>=1000&&dateKey(d)===value?d:null;}
 function add(d,days){const next=new Date(d);next.setDate(next.getDate()+days);return next;}
 function monday(d){return add(d,-((d.getDay()+6)%7));}
 function even(d,anchor='2026-10-19',anchorEven=true){const a=date(anchor)||date('2026-10-19'),m=monday(d),am=monday(a);return Math.round((Date.UTC(m.getFullYear(),m.getMonth(),m.getDate())-Date.UTC(am.getFullYear(),am.getMonth(),am.getDate()))/604800000)%2===0?anchorEven:!anchorEven;}
 function month(d){const first=new Date(d.getFullYear(),d.getMonth(),1,12),start=monday(first);return Array.from({length:42},(_,i)=>add(start,i));}
 function build(data){
  const entries=new Map();
  function put(kind,label,campus,value,alias){const id=JSON.stringify([kind,campus,value]);let item=entries.get(id);if(!item){item={id,kind,label,campus,value,aliases:new Set()};entries.set(id,item);}item.aliases.add(alias||label);}
  for(const g of data.groups||[]){const campus=g.source||'spk';put('group',g.name,campus,g.id);for(const alias of g.aliases||[])put('group',g.name,campus,g.id,alias);
   for(const week of ['even','odd'])for(let day=0;day<7;day++)for(const l of g.weeks[week][day]||[])for(const v of l.variants||[]){for(const kind of ['teacher','subject','room'])if(v[kind])put(kind,v[kind],campus,key(v[kind]));}}
  return [...entries.values()].map(e=>({...e,aliases:[...e.aliases].map(key)}));
 }
 function search(index,query,kind='all',campus='all',favorites=null){
  const raw=String(query||'').trim(),q=key(raw),tokens=raw.split(/\s+/).map(key).filter(Boolean);
  return index.filter(e=>(kind==='all'||e.kind===kind)&&(campus==='all'||e.campus===campus)&&(!favorites||e.kind==='group'&&favorites.includes(e.value))).map(e=>{
   const rq=e.kind==='room'?key(raw.replace(/^(ауд(?:итория)?\.?|каб(?:инет)?\.?)\s*/i,'')):q;
   const exact=e.aliases.some(a=>a===q||a===rq),prefix=e.aliases.some(a=>a.startsWith(q)||rq&&a.startsWith(rq));
   return {e,score:exact?0:prefix?1:2,match:!q||e.aliases.some(a=>a.includes(q)||rq&&a.includes(rq)||tokens.every(t=>a.includes(t)))};
  }).filter(x=>x.match).sort((a,b)=>a.score-b.score||a.e.label.localeCompare(b.e.label,'ru',{numeric:true})||a.e.campus.localeCompare(b.e.campus)).map(x=>x.e);
 }
 function lessons(data,target,week,day,subgroup=0){
  if(target.kind==='group'){const g=data.groups.find(g=>g.id===target.value);return g?(g.weeks[week][day]||[]).map(l=>({...l,variants:l.variants.filter(v=>!subgroup||!v.subgroup||v.subgroup===subgroup)})).filter(l=>l.variants.length):[];}
  const slots=new Map();
  for(const g of data.groups||[]){if((g.source||'spk')!==target.campus)continue;for(const l of g.weeks[week][day]||[]){const variants=l.variants.filter(v=>key(v[target.kind])===target.value);if(!variants.length)continue;
   const id=JSON.stringify([l.number,l.start,l.end]);let slot=slots.get(id);if(!slot){slot={number:l.number,start:l.start,end:l.end,variants:[]};slots.set(id,slot);}for(const v of variants)slot.variants.push({...v,groups:[{id:g.id,name:g.name,subgroups:[v.subgroup||0]}]});}}
  return [...slots.values()].sort((a,b)=>String(a.start).localeCompare(String(b.start))||a.number-b.number);
 }
 function link(target,selected,range,subgroup,mode){const u=new URL('https://raspisanie-spk-seversk.pages.dev/');for(const [k,v] of Object.entries({kind:target.kind,value:target.value,campus:target.campus,date:dateKey(selected),range:range==='week'?'week':'day',subgroup:[1,2].includes(subgroup)?subgroup:0,week:['even','odd'].includes(mode)?mode:'auto'}))u.searchParams.set(k,v);return u.toString();}
 function parseLink(raw){try{
  if(typeof raw!=='string'||raw.length>4096)return null;const u=new URL(raw.trim());const appLink=u.protocol==='spk-schedule:'&&u.hostname==='timetable',webLink=u.protocol==='https:'&&u.hostname==='raspisanie-spk-seversk.pages.dev';if((!appLink&&!webLink)||u.username||u.password||u.port||u.pathname&&u.pathname!=='/'||u.hash)return null;
  const p=u.searchParams;for(const k of p.keys())if(p.getAll(k).length!==1||!['kind','value','campus','date','range','subgroup','week'].includes(k))return null;
  const kind=p.get('kind'),value=p.get('value'),campus=p.get('campus'),selected=date(p.get('date')),range=p.get('range'),subgroup=p.get('subgroup'),mode=p.get('week');
  if(!['group','teacher','subject','room'].includes(kind)||!value||value.length>600||/[\x00-\x1f]/.test(value)||!['spk','crk'].includes(campus)||!selected||!['day','week'].includes(range)||!['0','1','2'].includes(subgroup)||!['auto','even','odd'].includes(mode))return null;
  return {target:{kind,value,campus},date:selected,range,subgroup:Number(subgroup),mode};
 }catch(_){return null;}}
 function snapshot(data,target,selected,range,subgroup,mode,anchor,anchorEven){
  const first=range==='week'?monday(selected):selected,days=Array.from({length:range==='week'?7:1},(_,i)=>{const d=add(first,i),week=mode==='even'||mode==='odd'?mode:even(d,anchor,anchorEven)?'even':'odd';return {date:dateKey(d),title:weekdays[(d.getDay()+6)%7]+', '+d.toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'}),week,lessons:lessons(data,target,week,(d.getDay()+6)%7,subgroup)};}),meta=data.sources?.[target.campus]||data;
  return {title:(target.campus==='crk'?'ЦРК':'СПК')+' · '+target.label,target:{...target},range,subgroup:target.kind==='group'?subgroup:0,manual:mode!=='auto',fetchedAt:meta.fetchedAt||0,stale:!!meta.error,days,link:link(target,selected,range,subgroup,mode)};
 }
 function variantLines(v){return [v.subject,v.teacher,v.room?'Ауд. '+v.room:'',v.groups?v.groups.map(g=>g.name+(g.subgroups.includes(0)?'':' · '+g.subgroups.join(', ')+' подгр.')).join('; '):v.subgroup?v.subgroup+' подгруппа':'Вся группа'].filter(Boolean);}
 function text(s){return ['РАСПИСАНИЕ · '+s.title,s.subgroup?s.subgroup+' подгруппа':'',...s.days.flatMap(d=>['',d.title+' · '+(d.week==='even'?'чётная':'нечётная')+' неделя'+(s.manual?' (вручную)':''),...(!d.lessons.length?['Занятий нет']:d.lessons.flatMap(l=>[l.number+' пара · '+l.start+'–'+l.end,...l.variants.map(v=>variantLines(v).join(' · '))]))]),'','По текущей таблице колледжа · spospk.ru',s.fetchedAt?'Сохранено '+new Date(s.fetchedAt).toLocaleString('ru-RU'):'',s.stale?'Обновить источник не удалось; использована сохранённая версия.':''].join('\n').replace(/\n{3,}/g,'\n\n');}
 return {key,dateKey,date,add,monday,even,month,build,search,lessons,link,parseLink,snapshot,text,variantLines};
});
