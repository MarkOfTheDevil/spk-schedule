'use strict';
// Daily timing uses the phone's local clock, just like the date selector.
const SpkTimetable=(()=>{
 function minutes(value){
  if(typeof value!=='string'||!/^\d{1,2}:\d{2}$/.test(value))return null;
  const [h,m]=value.split(':').map(Number);return h<24&&m<60?h*60+m:null;
 }
 function clockMinutes(now){return now.getHours()*60+now.getMinutes()+now.getSeconds()/60+now.getMilliseconds()/60000;}
 function isLive(lesson,now){const start=minutes(lesson.start),end=minutes(lesson.end),time=clockMinutes(now);return start!==null&&end!==null&&end>start&&time>=start&&time<end;}
 function daily(lessons,now=new Date()){
  if(!lessons.length)return {kind:'empty',current:[],next:[]};
  const slots=lessons.map(lesson=>({lesson,start:minutes(lesson.start),end:minutes(lesson.end)})).sort((a,b)=>a.start-b.start||a.end-b.end);
  if(slots.some(s=>s.start===null||s.end===null||s.end<=s.start))return {kind:'unknown',current:[],next:[]};
  const time=clockMinutes(now),current=slots.filter(s=>s.start<=time&&time<s.end),future=slots.filter(s=>s.start>time);
  const next=future.length?future.filter(s=>s.start===future[0].start):[];
  if(current.length){
   const end=Math.min(...current.map(s=>s.end)),start=Math.min(...current.map(s=>s.start));
   return {kind:'live',current:current.map(s=>s.lesson),next:next.map(s=>s.lesson),remaining:Math.ceil(end-time),progress:Math.max(0,Math.min(100,Math.floor((time-start)/(end-start)*100)))};
  }
  if(next.length)return {kind:time<slots[0].start?'before':'break',current:[],next:next.map(s=>s.lesson),remaining:Math.ceil(next[0].start-time)};
  const last=slots.reduce((a,b)=>a.end>b.end?a:b);
  return {kind:'done',current:[],next:[],end:last.lesson.end};
 }
 function duration(value){const m=Math.max(1,Math.ceil(value)),h=Math.floor(m/60);return h?h+' ч'+(m%60?' '+m%60+' мин':''):m+' мин';}
 function step(day,direction){return Math.max(0,Math.min(6,day+direction));}
 function bindSwipes(element,{allowed,onStep,onTap,context=()=>''}){
  let gesture=null,suppressUntil=0;const pointers=new Set();
  const cancel=()=>{gesture=null;};
  document.addEventListener('pointerdown',event=>{
   suppressUntil=0;
   if(event.pointerType!=='touch'&&event.pointerType!=='pen')return;
   pointers.add(event.pointerId);if(pointers.size>1){cancel();return;}
   const target=event.target.closest('.timetable-view');
   if(!target||!element.contains(target)||!allowed()||!event.isPrimary||event.button!==0||
    event.clientX<24||event.clientX>window.innerWidth-24||
    event.target.closest('button:not([data-day]),a,input,textarea,select,summary,[contenteditable="true"]'))return;
   gesture={id:event.pointerId,x:event.clientX,y:event.clientY,time:event.timeStamp,target,button:event.target.closest('button[data-day]'),context:context(),locked:false};
  },{passive:true});
  document.addEventListener('pointermove',event=>{
   if(!gesture||event.pointerId!==gesture.id)return;
   const x=Math.abs(event.clientX-gesture.x),y=Math.abs(event.clientY-gesture.y);
   if(!gesture.locked&&Math.max(x,y)>12){if(x>y*1.4)gesture.locked=true;else if(y>x*1.1)cancel();}
  },{passive:true});
  document.addEventListener('pointerup',event=>{
   pointers.delete(event.pointerId);
   if(!gesture||event.pointerId!==gesture.id)return;
   const g=gesture;cancel();const dx=event.clientX-g.x,dy=event.clientY-g.y;
   // A short touch on the strip also works when a WebView omits the synthetic
   // click after a pan. A later click sees the already selected day and is inert.
   if(!g.locked&&g.button&&event.target.closest('button[data-day]')===g.button&&
    Math.max(Math.abs(dx),Math.abs(dy))<10&&event.timeStamp-g.time<550&&
    g.target.isConnected&&allowed()&&context()===g.context&&onTap){onTap(Number(g.button.dataset.day));return;}
   if(g.locked)suppressUntil=performance.now()+450;
   if(!g.locked||!g.target.isConnected||!allowed()||context()!==g.context||event.timeStamp-g.time>1800||
    Math.abs(dx)<Math.max(40,Math.min(68,g.target.clientWidth*.15))||Math.abs(dx)<Math.abs(dy)*1.4||
    String(window.getSelection()||'').length)return;
   onStep(dx<0?1:-1);
  },{passive:true});
  // Capture on window before the app's click/haptic listeners. A new tap and
  // keyboard activation remain available immediately after a completed swipe.
  window.addEventListener('click',event=>{
   if(event.detail>0&&performance.now()<suppressUntil&&element.contains(event.target)){
    suppressUntil=0;event.preventDefault();event.stopImmediatePropagation();
   }
  },true);
  document.addEventListener('pointercancel',event=>{pointers.delete(event.pointerId);if(gesture&&gesture.id===event.pointerId)cancel();},{passive:true});
  document.addEventListener('visibilitychange',()=>{pointers.clear();cancel();});
  window.addEventListener('blur',()=>{pointers.clear();cancel();});
  return cancel;
 }
 return Object.freeze({minutes,isLive,daily,duration,step,bindSwipes});
})();
if(typeof module!=='undefined'&&module.exports)module.exports=SpkTimetable;
