(function(root,factory){
 'use strict';const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;else root.SpkChanges=api;
})(typeof window!=='undefined'?window:this,function(){
 'use strict';
 const clean=value=>String(value==null?'':value).replace(/\s+/g,' ').trim();
 const compare=(a,b)=>{const x=JSON.stringify(a),y=JSON.stringify(b);return x<y?-1:x>y?1:0;};
 const same=(a,b)=>JSON.stringify(a?a.lessons:null)===JSON.stringify(b?b.lessons:null);
 function normalize(data){
  const slots={};
  for(const group of data.groups)for(const week of ['even','odd'])for(let day=0;day<7;day++){
   for(const pair of group.weeks[week][day]||[]){
    const number=Number(pair.number),key=JSON.stringify([group.id,week,day,number]);
    const variants=(pair.variants||[]).map(v=>({subject:clean(v.subject),teacher:clean(v.teacher),room:clean(v.room),subgroup:[1,2].includes(Number(v.subgroup))?Number(v.subgroup):0})).sort(compare);
    if(!variants.length)continue;
    if(!slots[key])slots[key]={key,group:group.id,groupName:group.name||group.id,week,day,number,lessons:[]};
    slots[key].lessons.push({number,start:clean(pair.start),end:clean(pair.end),variants});
   }
  }
  for(const slot of Object.values(slots))slot.lessons.sort(compare);
  return slots;
 }
 function entry(before,after,at){
  if(same(before,after))return null;const slot=after||before;
  return {key:slot.key,group:slot.group,groupName:slot.groupName,week:slot.week,day:slot.day,number:slot.number,before:before||null,after:after||null,at,kind:!before?'added':!after?'removed':'edited'};
 }
 function restore(raw){
  try{const value=typeof raw==='string'?JSON.parse(raw):raw;
   if(!value||value.version!==1||!value.baseline||typeof value.baseline!=='object'||Array.isArray(value.baseline)||!Array.isArray(value.entries))return null;
   const variant=v=>v&&['subject','teacher','room'].every(k=>typeof v[k]==='string')&&[0,1,2].includes(v.subgroup);
   const pair=p=>p&&Number.isInteger(p.number)&&typeof p.start==='string'&&typeof p.end==='string'&&Array.isArray(p.variants)&&p.variants.every(variant);
   const valid=s=>s&&typeof s.key==='string'&&typeof s.group==='string'&&['even','odd'].includes(s.week)&&Number.isInteger(s.day)&&s.day>=0&&s.day<7&&Array.isArray(s.lessons)&&s.lessons.every(pair);
   if(!Object.values(value.baseline).every(valid)||!value.entries.every(e=>e&&typeof e.key==='string'&&(!e.before||valid(e.before))&&(!e.after||valid(e.after))&&(e.before||e.after)))return null;
   return value;
  }catch(_){return null;}
 }
 function update(saved,data){
  const baseline=normalize(data),previous=restore(saved),at=Number(data.fetchedAt)||Date.now();
  if(!previous)return {version:1,baseline,entries:[],checkedAt:at};
  const pending=new Map(previous.entries.map(e=>[e.key,e]));
  for(const key of new Set([...Object.keys(previous.baseline),...Object.keys(baseline)])){
   const before=previous.baseline[key]||null,after=baseline[key]||null;if(same(before,after))continue;
   // Retain the first unseen value. Reverting it removes the marker, whereas
   // repeated downloads of the same data keep unacknowledged changes visible.
   const earlier=pending.get(key),change=entry(earlier?earlier.before:before,after,at);
   if(change)pending.set(key,change);else pending.delete(key);
  }
  return {version:1,baseline,entries:[...pending.values()].sort((a,b)=>a.group.localeCompare(b.group,'ru',{numeric:true})||a.week.localeCompare(b.week)||a.day-b.day||a.number-b.number),checkedAt:at};
 }
 function projectSlot(slot,predicate){
  if(!slot)return null;
  const lessons=slot.lessons.map(p=>({...p,variants:p.variants.filter(v=>predicate(v,slot))})).filter(p=>p.variants.length);
  return lessons.length?{...slot,lessons}:null;
 }
 function select(saved,predicate){return saved?saved.entries.map(e=>entry(projectSlot(e.before,predicate),projectSlot(e.after,predicate),e.at)).filter(Boolean):[];}
 function forGroup(saved,group,subgroup=0){return select(saved,(v,s)=>s.group===group&&(subgroup===0||v.subgroup===0||v.subgroup===subgroup));}
 function forTeacher(saved,teacher,key){return teacher?select(saved,v=>key(v.teacher)===teacher):[];}
 function acknowledge(saved,keys){const selected=new Set(keys);return saved?{...saved,entries:saved.entries.filter(e=>!selected.has(e.key))}:saved;}
 function forLesson(entries,lesson,teacher=false){
  return entries.filter(e=>e.after&&e.number===lesson.number&&e.after.lessons.some(p=>p.start===lesson.start&&p.end===lesson.end&&(!teacher||lesson.variants.some(v=>(v.groups||[]).some(g=>g.id===e.group)&&p.variants.some(n=>n.subject===clean(v.subject)&&n.room===clean(v.room))))));
 }
 function describeSlot(slot){
  if(!slot)return 'Пары нет';
  return slot.lessons.map(p=>p.start+'–'+p.end+' · '+p.variants.map(v=>[v.subject,v.teacher,v.room?(/онлайн/i.test(v.room)?v.room:'ауд. '+v.room):'',v.subgroup?v.subgroup+' подгр.':'Вся группа'].filter(Boolean).join(' · ')).join(' / ')).join('\n');
 }
 function details(change){
  if(!change.before||!change.after)return [];
  const before=change.before.lessons,after=change.after.lessons;
  if(before.length!==1||after.length!==1)return [{label:'Пара',before:describeSlot(change.before),after:describeSlot(change.after)}];
  const a=before[0],b=after[0],lines=[];
  if(a.start!==b.start||a.end!==b.end)lines.push({label:'Время',before:a.start+'–'+a.end,after:b.start+'–'+b.end});
  const byGroup=variants=>new Map(variants.map(v=>[v.subgroup,v]));const old=byGroup(a.variants),fresh=byGroup(b.variants);
  if(old.size!==a.variants.length||fresh.size!==b.variants.length){lines.push({label:'Занятия',before:describeSlot(change.before),after:describeSlot(change.after)});return lines;}
  for(const subgroup of new Set([...old.keys(),...fresh.keys()])){
   const x=old.get(subgroup),y=fresh.get(subgroup),suffix=subgroup?' · '+subgroup+' подгр.':'';
   if(!x||!y){const describe=v=>v?[v.subject,v.teacher,v.room].filter(Boolean).join(' · '):'Нет занятия';lines.push({label:'Занятие'+suffix,before:describe(x),after:describe(y)});continue;}
   for(const [field,label] of [['subject','Предмет'],['teacher','Преподаватель'],['room','Кабинет']])if(x[field]!==y[field])lines.push({label:label+suffix,before:x[field]||'Не указан',after:y[field]||'Не указан'});
  }
  return lines;
 }
 return Object.freeze({normalize,restore,update,forGroup,forTeacher,forLesson,acknowledge,details,describeSlot});
});
