'use strict';
const webRuntime={offlineReady:false,offlineError:false,storageWarning:'',previousFocus:null,sync:null};
function offlineLabel(){return webRuntime.storageWarning||(webRuntime.offlineReady?'Готово к работе без интернета':webRuntime.offlineError?'Офлайн-режим пока недоступен':'Подготавливаем работу без интернета…');}
function installBanner(){return '<section class="settings-card install-card"><div class="install-mark">'+icon('screen')+'</div><div><h3>Приложение на iPhone</h3><p>Открывайте расписание с иконки на экране «Домой».</p><button class="text-button" data-action="install">Как установить '+icon('arrow')+'</button><p class="pwa-offline" data-offline-status>'+esc(offlineLabel())+'</p></div></section>';}
function openWebDialog(id){webRuntime.previousFocus=document.activeElement;SpkMotion.showModal($(id));document.body.classList.add('modal-open');$(id).querySelector('button').focus();}
function closeWebDialogs(){if($('installModal').hidden)return false;SpkMotion.hideModal($('installModal'),()=>{syncModalBody();webRuntime.previousFocus?.focus({preventScroll:true});});return true;}
function updateOfflineLabel(){document.querySelectorAll('[data-offline-status]').forEach(n=>n.textContent=offlineLabel());}
function checkSchedule(force=false){return webRuntime.sync?.check({force});}
function setupWebControls(){
 document.addEventListener('click',e=>{if(e.target.closest('[data-web-close]'))closeWebDialogs();if(e.target.closest('[data-action="install"]'))openWebDialog('installModal');});
 window.addEventListener('online',()=>checkSchedule());window.addEventListener('pageshow',()=>window.onAppResume?.());
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)window.onAppResume?.();});
 setInterval(()=>{if(!document.hidden)checkSchedule();},SpkSync.PERIOD);
}
async function prepareOffline(){
 if(!('serviceWorker' in navigator)||!window.isSecureContext){webRuntime.offlineError=true;updateOfflineLabel();return;}
 try{
  let controlled=!!navigator.serviceWorker.controller,reloaded=false;
  navigator.serviceWorker.addEventListener('controllerchange',()=>{if(controlled&&!reloaded){reloaded=true;location.reload();}controlled=true;});
  const registration=await navigator.serviceWorker.register('sw.js',{scope:'./',updateViaCache:'none'});SpkUpdater.attach(registration);
  await navigator.serviceWorker.ready;webRuntime.offlineReady=true;updateOfflineLabel();
 }catch(_){webRuntime.offlineError=true;updateOfflineLabel();}
}
let pendingLink=location.href;
function handleWebLink(){
 if(!pendingLink||!state.data)return;const raw=pendingLink;pendingLink='';const url=new URL(raw),group=url.searchParams.get('group'),date=url.searchParams.get('date');
 if(url.searchParams.has('kind')){const normalized=new URL(raw);normalized.hostname='raspisanie-spk-seversk.pages.dev';normalized.protocol='https:';normalized.port='';normalized.pathname='/';openScheduleLink(normalized.href);}
 else if(group&&state.data.groups.some(g=>g.id===group)){chooseGroup(group);const d=SpkPlanner.date(date);if(d)setSelectedDate(d,'page',true);}
 if(url.search){history.replaceState(null,'',url.pathname);persist();}
}
async function bootWebApp(){
 setupWebControls();
 try{
  const cached=await SpkStore.load(),parts={spk:SpkSync.source(cached,'spk'),crk:SpkSync.source(cached,'crk')};
  await Promise.all(['spk','crk'].map(async id=>{if(parts[id])return;try{const res=await fetch(id==='spk'?'schedule.json':'schedule-crk.json');if(!res.ok)return;const data=await res.json();if(SpkParser.validate(data))parts[id]=data;}catch(_){}}));
  const data=SpkSync.combine(parts);if(!SpkParser.validate(data))throw Error('Нет сохранённой копии. Подключитесь к интернету и нажмите «Обновить».');
  window.onScheduleData(data);handleWebLink();try{await SpkStore.save(data);}catch(e){webRuntime.storageWarning=e.message;}
 }catch(e){state.error=e.message;setStatus();}
 webRuntime.sync=SpkSync.create({getData:()=>state.data,parse:(id,bytes,at)=>id==='crk'?SpkCrkParser.parse(bytes,at):SpkParser.parse(bytes,at),validate:SpkParser.validate,save:SpkStore.save,
  apply(data){window.onScheduleData(data);handleWebLink();},
  status(result){state.loading=!!result.loading;state.error=result.error||'';if(result.storageError){webRuntime.storageWarning=result.storageError;state.error=result.storageError;updateOfflineLabel();}setStatus();if(!result.loading&&result.manual){const n=SpkSourceStatus.notice(state.data,!!result.error);toast(result.storageError||n.text,result.storageError?5200:n.duration);}}
 });
 checkSchedule();prepareOffline();
 PwaPush.init().then(enabled=>{state.reminder.enabled=enabled;persist(false);const note=document.querySelector('.pwa-notification-status');if(note)note.textContent=PwaPush.status();}).catch(()=>{});
}
