'use strict';
const SpkUpdater=(()=>{
 let registration=null,checking=false,lastCheck=0;
 const version='3.0.0';
 function render(){const banner=document.getElementById('appUpdateBanner'),waiting=!!registration?.waiting;if(banner){banner.hidden=!waiting;if(waiting)banner.innerHTML='<div class="update-heading"><div><h3>Готова новая версия</h3><p>Перезапустите приложение, чтобы применить обновление.</p></div></div><div class="pwa-update-actions"><button class="button-primary" data-pwa-update="apply">Обновить приложение</button></div>';}
 const text=document.getElementById('pwaUpdateStatus');if(text)text.textContent=waiting?'Новая версия готова. Нажмите «Обновить приложение» вверху экрана.':checking?'Проверяем обновления…':'iPhone · версия '+version;
 }
 async function check(manual=false){if(checking)return;if(!registration){if(manual)toast('Подключитесь к интернету и откройте приложение ещё раз.',5200);return;}if(!manual&&Date.now()-lastCheck<15*60000)return;checking=true;render();try{await registration.update();lastCheck=Date.now();if(manual&&!registration.waiting&&!registration.installing)toast('Установлена актуальная версия');}catch(_){if(manual)toast('Нет соединения. Проверим обновление позже.',5200);}finally{checking=false;render();}}
 function attach(reg){registration=reg;render();reg.addEventListener('updatefound',()=>{const installing=reg.installing;installing?.addEventListener('statechange',render);});}
 document.addEventListener('click',e=>{const b=e.target.closest('[data-pwa-update]');if(!b)return;if(b.dataset.pwaUpdate==='check')check(true);else if(b.dataset.pwaUpdate==='apply'&&registration?.waiting)registration.waiting.postMessage({type:'SKIP_WAITING'});});
 return {attach,init:render,resume:()=>check(),aboutCard:()=>'<section class="settings-card"><h3>Обновления приложения</h3><p id="pwaUpdateStatus">iPhone · версия '+version+'</p><button class="text-button" data-pwa-update="check">Проверить обновления</button></section>'};
})();
