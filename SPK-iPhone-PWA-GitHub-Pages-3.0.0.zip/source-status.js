(function(root){'use strict';
 function notice(data,failed){
  if(failed)return {text:'Не удалось обновить расписание. Доступна сохранённая версия.',duration:5200};
  const sources=data?.sources||{},ids=['spk','crk'],names={spk:'СПК',crk:'ЦРК'};
  const unavailable=ids.filter(id=>!sources[id]||sources[id].error),review=ids.filter(id=>sources[id]?.warningCount>0);
  if(unavailable.length===2)return {text:'СПК и ЦРК недоступны. Показана сохранённая версия.',duration:5200};
  if(unavailable.length){const id=unavailable[0],other=ids.find(x=>x!==id);return {text:names[other]+(review.includes(other)?' — есть записи для проверки. ':' обновлено. ')+names[id]+' — сохранённая версия.',duration:5200};}
  if(review.length)return {text:'Расписание обновлено. Есть записи для проверки: '+review.map(id=>names[id]).join(' и ')+'. Подробности под расписанием.',duration:5200};
  return {text:'Расписание обновлено',duration:2400};
 }
 const api={notice};if(typeof module==='object'&&module.exports)module.exports=api;else root.SpkSourceStatus=api;
})(typeof window==='undefined'?globalThis:window);
