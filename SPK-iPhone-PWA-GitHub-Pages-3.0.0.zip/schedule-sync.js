'use strict';
(function(root){
 const MIN_INTERVAL=60000,PERIOD=5*60000,IDS=['spk','crk'];
 function source(data,id){if(!data)return null;const groups=data.groups.filter(g=>(g.source||'spk')===id);if(!groups.length)return null;const meta=data.sources?.[id]||data;return {...meta,schema:1,groups,mondayNotes:id==='spk'?data.mondayNotes||[]:[],unassignedEntries:id==='crk'?data.unassignedEntries||[]:[]};}
 function combine(parts){const main=parts.spk,crk=parts.crk,sources={};for(const id of IDS){const part=parts[id];sources[id]=part?Object.fromEntries(Object.entries(part).filter(([k])=>!['groups','mondayNotes','unassignedEntries','sources'].includes(k))):{error:'Нет сохранённой версии.'};}return {schema:1,source:main?.source||'',title:'Расписание СПК и ЦРК',fetchedAt:Math.max(...IDS.map(id=>parts[id]?.fetchedAt||0)),groups:IDS.flatMap(id=>(parts[id]?.groups||[]).map(g=>({...g,source:id}))),mondayNotes:main?.mondayNotes||[],unassignedEntries:crk?.unassignedEntries||[],sources};}
 async function readBounded(response){const MAX=8*1024*1024;if(Number(response.headers.get('content-length'))>MAX)throw Error('Файл расписания слишком большой.');const reader=response.body?.getReader();if(!reader){const b=await response.arrayBuffer();if(b.byteLength>MAX)throw Error('Файл расписания слишком большой.');return b;}let size=0;const chunks=[];try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX){await reader.cancel();throw Error('Файл расписания слишком большой.');}chunks.push(value);}}finally{reader.releaseLock();}const b=new Uint8Array(size);let at=0;for(const c of chunks){b.set(c,at);at+=c.length;}return b;}
 function create(options){
  let pending=null,lastAttempt=-Infinity;const clock=options.now||Date.now,fetcher=options.fetch||root.fetch.bind(root);
  async function download(id,current,force){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),40000);try{
   const headers={Accept:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};if(/^"[a-f0-9]{64}"$/.test(current?.sourceETag||''))headers['If-None-Match']=current.sourceETag;
   const res=await fetcher('api/'+(id==='crk'?'rasp_crk.xlsx':'schedule.xlsx')+(force?'?refresh=1':''),{headers,cache:'no-store',credentials:'same-origin',redirect:'error',signal:controller.signal});
   const checkedAt=clock();if(res.status===304){if(!current||!options.validate(current))throw Error('Нет сохранённой версии для проверки.');return {...current,error:'',checkedAt};}
   if(!res.ok)throw Error('Источник недоступен — сохранённая версия.');
   if(!/application\/(vnd\.openxmlformats-officedocument\.spreadsheetml\.sheet|octet-stream)/i.test(res.headers.get('content-type')||''))throw Error('Вместо таблицы получен другой файл.');
   const bytes=await readBounded(res),data=options.parse(id,bytes,checkedAt);if(!options.validate(data))throw Error('Формат таблицы изменился.');
   return {...data,checkedAt,error:'',sourceETag:res.headers.get('etag')||'',automatic:true};
  }finally{clearTimeout(timer);}}
  async function run(force){lastAttempt=clock();options.status({loading:true,manual:force});const old=options.getData(),parts={};let successes=0;await Promise.all(IDS.map(async id=>{const current=source(old,id);try{parts[id]=await download(id,current,force);successes++;}catch(e){parts[id]={...(current||{schema:1,groups:[],mondayNotes:[],fetchedAt:0}),error:e.name==='AbortError'?'Сайт колледжа долго не отвечает.':e instanceof TypeError?'Нет соединения. Показана сохранённая версия.':e.message};}}));
   const data=combine(parts);let storageError='';if(options.validate(data)){try{await options.save(data);}catch(e){storageError=e.message;}options.apply(data);}
   const result={loading:false,ok:successes>0,manual:force,storageError};if(!successes)result.error='СПК и ЦРК сейчас недоступны. Обновление повторится автоматически.';options.status(result);return result;
  }
  return {check({force=false}={}){if(pending)return pending;if(!force&&clock()-lastAttempt<MIN_INTERVAL)return Promise.resolve({skipped:true});pending=run(force).catch(e=>{options.status({loading:false,error:e.message,manual:force});return {ok:false,error:e.message};}).finally(()=>{pending=null;});return pending;}};
 }
 const api={create,source,combine,MIN_INTERVAL,PERIOD};root.SpkSync=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window==='undefined'?globalThis:window);
