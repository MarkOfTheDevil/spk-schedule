'use strict';
const CACHE='spk-iphone-v3-github-pages-3-0-0';
const FILES=["./", "404.html", "app.css", "app.js", "appearance.css", "appearance.js", "changes.js", "crk-parser.js", "dot-palettes.css", "dot.css", "icons/apple-touch-icon.png", "icons/icon-192.png", "icons/icon-512.png", "icons/icon.svg", "index.html", "manifest.webmanifest", "motion.css", "motion.js", "palettes.css", "palettes.js", "parser.js", "planner-ui.js", "planner.css", "planner.js", "refinement.css", "schedule-crk.json", "schedule-sync.js", "schedule.json", "share-image.js", "source-status.js", "store.js", "teachers.js", "timetable.js", "updates.js", "vendor/fflate.js", "web-push.js", "web.css", "web.js"];
const URLS=FILES.map(p=>new URL(p,self.registration.scope).href);
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 try{await Promise.all(URLS.map(async url=>{const r=await fetch(new Request(url,{cache:'reload',credentials:'same-origin'}));if(!r.ok||r.redirected)throw Error('Asset unavailable');await cache.put(url,r);}));
 // Legacy versions have no update prompt: activate once to migrate them to v3.
 const legacy=!(await caches.keys()).some(k=>k.startsWith('spk-iphone-v3-')&&k!==CACHE);
 if(!self.registration.active||legacy)await self.skipWaiting();
 }catch(e){await caches.delete(CACHE);throw e;}
})()));
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')event.waitUntil(self.skipWaiting());});
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const k of await caches.keys())if(k.startsWith('spk-iphone-')&&k!==CACHE)await caches.delete(k);await self.clients.claim();})()));
self.addEventListener('fetch',event=>{const request=event.request,u=new URL(request.url);if(request.method!=='GET'||u.origin!==self.location.origin)return;
 const navigation=request.mode==='navigate'&&(u.pathname===new URL('./',self.registration.scope).pathname||u.pathname===new URL('index.html',self.registration.scope).pathname);
 if(!navigation&&!URLS.includes(u.href))return;
 event.respondWith((async()=>{const cache=await caches.open(CACHE);return await cache.match(navigation?new URL('./',self.registration.scope).href:request)||fetch(request);})());
});
self.addEventListener('push',event=>{
 let data={};try{data=event.data?.json()||{};}catch(_){data={body:event.data?.text()||''};}
 const title=String(data.title||'Расписание СПК').slice(0,100);
 const body=String(data.body||'Откройте расписание на завтра.').slice(0,1200);
 const url=new URL('./',self.registration.scope);
 // Only same-origin root-level page; never open arbitrary push payload URLs.
 const params=new URLSearchParams();
 if(/^[a-zA-Zа-яА-Я0-9_:/-]{1,64}$/.test(data.group||''))params.set('group',data.group);
 if([0,1,2].includes(Number(data.subgroup)))params.set('subgroup',String(data.subgroup));
 if(/^\d{4}-\d{2}-\d{2}$/.test(data.date||''))params.set('date',data.date);
 url.search=params.toString();
 event.waitUntil(self.registration.showNotification(title,{
  body,icon:'icons/icon-192.png',badge:'icons/icon-192.png',tag:'spk-reminder',
  data:{url:url.href},renotify:false
 }));
});
self.addEventListener('notificationclick',event=>{
 event.notification.close();const url=event.notification.data?.url||new URL('./',self.registration.scope).href;
 event.waitUntil((async()=>{
  const list=await clients.matchAll({type:'window',includeUncontrolled:true});
  for(const client of list){if(new URL(client.url).origin===new URL(url).origin){await client.focus();client.navigate(url);return;}}
  await clients.openWindow(url);
 })());
});
