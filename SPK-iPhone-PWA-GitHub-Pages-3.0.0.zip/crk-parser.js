'use strict';
// The CRK workbook uses one room/time column pair and one sheet per week.
(function(root){
 const clean=s=>String(s||'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
 const nodes=(n,t)=>Array.from(n.getElementsByTagNameNS('*',t));
 const first=(n,t)=>nodes(n,t)[0]?.textContent||'';
 const fail=s=>{throw Error(s);},key=(r,c)=>r*65536+c;
 const DAYS=['ПОНЕДЕЛЬНИК','ВТОРНИК','СРЕДА','ЧЕТВЕРГ','ПЯТНИЦА','СУББОТА','ВОСКРЕСЕНЬЕ'];
 const TIME=/^(\d{1,2})[.:](\d{2})\s*[-–—]\s*(\d{1,2})[.:](\d{2})$/;
 function address(s){const m=/^([A-Z]+)([1-9]\d*)$/.exec(s);if(!m)fail('Повреждён адрес ячейки ЦРК.');let c=0;for(const ch of m[1])c=c*26+ch.charCodeAt(0)-64;const r=Number(m[2]);if(r>5000||c>1000)fail('Размер таблицы ЦРК не поддерживается.');return [r,c];}
 function xml(b){if(!b)fail('В файле ЦРК отсутствует часть таблицы.');const s=new TextDecoder('utf-8',{fatal:true}).decode(b);if(/<!DOCTYPE|<!ENTITY/i.test(s))fail('Неподдерживаемый XML.');const d=new root.DOMParser().parseFromString(s,'application/xml');if(nodes(d,'parsererror').length)fail('Повреждён XML в таблице ЦРК.');return d;}
 function parse(input,fetchedAt=Date.now()){
  const bytes=input instanceof Uint8Array?input:new Uint8Array(input);
  if(bytes.length>8*1024*1024||bytes.length<22||bytes[0]!==80||bytes[1]!==75)fail('Получен неверный файл ЦРК.');
  let count=0,total=0;const zip=root.fflate||(typeof require==='function'?require('./vendor/fflate.js'):null);
  const files=zip.unzipSync(bytes,{filter(f){total+=f.originalSize;if(++count>4000||!Number.isFinite(f.originalSize)||f.originalSize>32*1024*1024||total>64*1024*1024)fail('Таблица ЦРК слишком большая.');return /^xl\/(sharedStrings\.xml|workbook\.xml|_rels\/workbook\.xml\.rels|worksheets\/[^/]+\.xml)$/.test(f.name);}});
  const strings=files['xl/sharedStrings.xml']?nodes(xml(files['xl/sharedStrings.xml']),'si').map(n=>nodes(n,'t').map(t=>t.textContent).join('')):[];
  const paths=new Map();for(const r of nodes(xml(files['xl/_rels/workbook.xml.rels']),'Relationship')){if(r.getAttribute('TargetMode')==='External')continue;const t=r.getAttribute('Target'),p=t.startsWith('/')?t.slice(1):'xl/'+t;if(/^xl\/worksheets\/[^/]+\.xml$/.test(p))paths.set(r.getAttribute('Id'),p);}
  const groups=new Map(),seenWeeks=new Set(),unassignedEntries=[];let assigned=0,warningCount=0;
  const groupPattern='[А-ЯЁA-Z]*\\d{2,4}(?:/\\d{1,2}(?!\\d))?[А-ЯЁA-Z]*';
  const entry=new RegExp('^([ДD]'+groupPattern+'(?:\\s*[/,;+]\\s*'+groupPattern+')*)\\s+(.+)$');
  for(const sheet of nodes(xml(files['xl/workbook.xml']),'sheet')){
   const name=sheet.getAttribute('name').toUpperCase().replace(/Ё/g,'Е'),week=name.includes('НЕЧЕТНАЯ')?'odd':name.includes('ЧЕТНАЯ')?'even':'';if(!week)continue;
   if(seenWeeks.has(week))fail('Повторяется неделя в расписании ЦРК.');seenWeeks.add(week);
   const id=sheet.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id'),doc=xml(files[paths.get(id)]),cs=nodes(doc,'c');
   if(cs.length>150000)fail('Таблица ЦРК слишком большая.');
   const cells=new Map(),merged=new Map();let maxRow=0;
   for(const e of cs){const [r,c]=address(e.getAttribute('r'));let v=first(e,'v');if(e.getAttribute('t')==='s'&&v){if(!/^\d+$/.test(v)||!Object.prototype.hasOwnProperty.call(strings,Number(v)))fail('Повреждена таблица строк ЦРК.');v=strings[Number(v)];}else if(e.getAttribute('t')==='inlineStr')v=first(e,'is');v=clean(v);if(v)cells.set(key(r,c),v);maxRow=Math.max(maxRow,r);}
   let covered=0;for(const e of nodes(doc,'mergeCell')){const parts=e.getAttribute('ref').split(':');if(parts.length!==2)continue;const [r1,c1]=address(parts[0]),[r2,c2]=address(parts[1]);covered+=(r2-r1+1)*(c2-c1+1);if(r2<r1||c2<c1||covered>500000)fail('Некорректные объединения ЦРК.');const v=cells.get(key(r1,c1));if(v)for(let r=r1;r<=r2;r++)for(let c=c1;c<=c2;c++)merged.set(key(r,c),v);}
   const value=(r,c)=>merged.get(key(r,c))||cells.get(key(r,c))||'';
   let header=0;for(let r=1;r<=Math.min(20,maxRow);r++)if(value(r,1).toLowerCase().includes('день')){header=r;break;}
   if(!header)fail('В ЦРК не найден заголовок дней.');const columns=[];
   for(let c=2;c<1000;c++)if(value(header,c).toLowerCase()==='время'&&value(header,c+1))columns.push(c+1);
   if(!columns.length)fail('В ЦРК не найдены время и кабинеты.');
   let day=-1,number=0;const daysSeen=new Set();
   for(let r=header+1;r<=maxRow;r++){
    const d=DAYS.indexOf((cells.get(key(r,1))||'').toUpperCase());if(d>=0){day=d;number=0;daysSeen.add(d);}if(day<0)continue;
    const timed=columns.some(c=>TIME.test(value(r,c-1))),occupied=columns.some(c=>value(r,c));
    if(!timed&&(!occupied||value(r,1).toUpperCase()!==DAYS[day]))continue;number++;
    for(const c of columns){const raw=value(r,c);if(!raw)continue;
     const label=raw.replace(/^[’'`]+\s*/,'').replace(/^([ДD])[’'`]+\s*(?=[А-ЯЁA-Z]*\d)/,'$1'),time=TIME.exec(value(r,c-1)),item=entry.exec(label),room=value(header,c).replace(/^ауд\.?\s*/i,'');
     if(!time||!item){const needsReview=!time||/^[ДD0-9]/i.test(label)||!/[А-ЯЁ][а-яё-]+\s+[А-ЯЁ]\.\s*[А-ЯЁ]\.?$/.test(label);if(needsReview)warningCount++;unassignedEntries.push({source:'crk',week,day,number,time:value(r,c-1),room,text:raw,row:r,column:c,needsReview});continue;}
     const start=time[1].padStart(2,'0')+':'+time[2],end=time[3].padStart(2,'0')+':'+time[4],teacher=item[2].replace(/^[’'`]+/,'').trim();
     for(const match of item[1].matchAll(new RegExp(groupPattern,'g'))){let name=match[0].replace(/^D/,'Д');if(!name.startsWith('Д'))name='Д'+name;const gid='crk:'+name;
      if(!groups.has(gid))groups.set(gid,{id:gid,name,source:'crk',aliases:[name],weeks:Object.fromEntries(['even','odd'].map(w=>[w,Object.fromEntries(DAYS.map((_,i)=>[i,[]]))]))});
      const slots=groups.get(gid).weeks[week][day];let slot=slots.find(p=>p.start===start&&p.end===end);if(!slot){slot={number,start,end,variants:[],sourceRow:r};slots.push(slot);}slot.variants.push({subject:'Занятие в ЦРК',teacher,room,subgroup:0});assigned++;
     }
    }
   }
   if(daysSeen.size!==6)fail('В ЦРК не найдены все шесть учебных дней.');
  }
  if(seenWeeks.size!==2||!assigned)fail('Не найдены две недели или занятия ЦРК.');
  const result={schema:1,source:'http://www.spospk.ru/rasp_crk.xlsx',title:'Расписание ЦРК',fetchedAt,groups:[...groups.values()].sort((a,b)=>a.id<b.id?-1:1),mondayNotes:[],unassignedEntries,warningCount};
  if(!root.SpkParser.validate(result))fail('В ЦРК найдены неподдерживаемые данные.');return result;
 }
 const api={parse};root.SpkCrkParser=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window==='undefined'?globalThis:window);
