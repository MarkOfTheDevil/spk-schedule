'use strict';
const ICONS={share:'<path d="M12 16V3m-5 5 5-5 5 5M5 13v7h14v-7"/>',left:'<path d="M19 12H5m5-5-5 5 5 5"/>',calendar:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4m8-4v4M3 11h18m-14 4h3m4 0h3m-10 3h3"/>',star:'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9z"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>',moon:'<path d="M20.5 13.3A8.7 8.7 0 0 1 10.7 3.5 8.7 8.7 0 1 0 20.5 13.3Z"/>',refresh:'<path d="M3 12a9 9 0 0 1 15.4-6.4L21 8M21 3v5h-5M21 12a9 9 0 0 1-15.4 6.4L3 16M3 21v-5h5"/>',settings:'<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="3" fill="var(--panel)"/><circle cx="15" cy="17" r="3" fill="var(--panel)"/>',chevron:'<path d="m8 10 4 4 4-4"/>',close:'<path d="m6 6 12 12M6 18 18 6"/>',search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',user:'<circle cx="12" cy="8" r="3"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/>',room:'<path d="M5 21V3h14v18M3 21h18M14 12h1"/>',check:'<path d="m5 12 4 4L19 6"/>',arrow:'<path d="M5 12h14m-5-5 5 5-5 5"/>',wifi:'<path d="M3 9a14 14 0 0 1 18 0M6 12a9 9 0 0 1 12 0M9 15a4 4 0 0 1 6 0"/><circle cx="12" cy="19" r=".7"/>',screen:'<rect x="5" y="2" width="14" height="20" rx="3"/><path d="M10 18h4"/>',book:'<path d="M12 5v16M3 4c4-1 7 0 9 2 2-2 5-3 9-2v15c-4-1-7 0-9 2-2-2-5-3-9-2z"/>',external:'<path d="M14 3h7v7m0-7L10 14M10 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5"/>'};
const icon=n=>'<svg viewBox="0 0 24 24" aria-hidden="true">'+(ICONS[n]||ICONS.calendar)+'</svg>';
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const DAYS=['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'];
const SHORT=['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];
const native=()=>typeof window.College!=='undefined';
function systemTheme(){return native()&&typeof College.isSystemDark==='function'?!!College.isSystemDark():window.matchMedia('(prefers-color-scheme: dark)').matches;}
function reminderState(value){const r=value&&typeof value==='object'?value:{};return {enabled:r.enabled===true,hour:Number.isInteger(r.hour)&&r.hour>=0&&r.hour<24?r.hour:20,minute:Number.isInteger(r.minute)&&r.minute>=0&&r.minute<60?r.minute:0,group:typeof r.group==='string'?r.group:'',subgroup:[1,2].includes(r.subgroup)?r.subgroup:0,allowed:r.allowed!==false,exact:r.exact===true,nextAt:Number(r.nextAt)||0,testAt:Number(r.testAt)||0,restricted:r.restricted===true,lastAttemptAt:Number(r.lastAttemptAt)||0,lastResultAt:Number(r.lastResultAt)||0,lastResult:typeof r.lastResult==='string'?r.lastResult:'',scheduleError:typeof r.scheduleError==='string'?r.scheduleError:''};}
function readReminderState(fallback){try{if(native()&&typeof College.getReminderState==='function')return reminderState(JSON.parse(College.getReminderState()));}catch(_){}return reminderState(fallback);}
function readState(){try{const s=JSON.parse(localStorage.getItem('spk.preferences.v1')||'{}');return s&&typeof s==='object'?s:{};}catch(_){return {};}}
const saved=readState();
const state={subgroupsEnabled:saved.subgroupsEnabled===true,page:'schedule',campus:saved.campus==='crk'||String(saved.group||'').startsWith('crk:')?'crk':'spk',campusGroups:saved.campusGroups&&typeof saved.campusGroups==='object'?saved.campusGroups:{},group:typeof saved.group==='string'?saved.group:'',teacher:TeacherIndex.key(saved.teacher),teachers:[],teacherQuery:'',teacherSelecting:false,favorites:Array.isArray(saved.favorites)?saved.favorites.filter(x=>typeof x==='string'):[],subgroups:saved.subgroups&&typeof saved.subgroups==='object'?saved.subgroups:{},theme:['auto','light','dark'].includes(saved.theme)?saved.theme:'auto',palette:PALETTES.some(p=>p.id===saved.palette)?saved.palette:'dot-lime',paletteFilter:'all',haptics:saved.haptics!==false,animations:saved.animations!==false,systemDark:systemTheme(),reminder:readReminderState(saved.reminder),reminderPending:false,reminderTestPending:false,reminderMessage:'',chooserPurpose:'group',anchorDate:/^\d{4}-\d{2}-\d{2}$/.test(saved.anchorDate||'')?saved.anchorDate:'2026-10-19',anchorEven:typeof saved.anchorEven==='boolean'?saved.anchorEven:true,mode:'auto',weekDate:dateKey(monday()),explore:null,day:(new Date().getDay()+6)%7,onlyFavorites:false,loading:false,error:'',data:null};
let changeHistory=readChangeHistory();
let lastReminderConfig='',lastWidgetDefaults='';
function syncWidgetDefaults(){try{const config=JSON.stringify({group:state.group,subgroup:subgroup(),subgroupsEnabled:state.subgroupsEnabled,theme:state.theme,palette:state.palette});if(native()&&typeof College.saveWidgetDefaults==='function'&&config!==lastWidgetDefaults){College.saveWidgetDefaults(config);lastWidgetDefaults=config;}}catch(_){}}
let clockTimer=null,clockVisible=true,lastDate=dateKey(new Date());
function syncReminderConfig(){const r=state.reminder;const config=JSON.stringify({group:r.group,subgroup:state.subgroupsEnabled?r.subgroup:0,hour:r.hour,minute:r.minute,anchorDate:state.anchorDate,anchorEven:state.anchorEven});if(config!==lastReminderConfig){lastReminderConfig=config;PwaPush.updateIfEnabled({...r,subgroup:state.subgroupsEnabled?r.subgroup:0},state.anchorDate,state.anchorEven).catch(e=>toast(e.message,5200));}}
function persist(sync=true){try{localStorage.setItem('spk.preferences.v1',JSON.stringify({subgroupsEnabled:state.subgroupsEnabled,campus:state.campus,campusGroups:state.campusGroups,group:state.group,teacher:state.teacher,favorites:state.favorites,subgroups:state.subgroups,theme:state.theme,palette:state.palette,haptics:state.haptics,animations:state.animations,reminder:state.reminder,anchorDate:state.anchorDate,anchorEven:state.anchorEven}));if(sync)syncReminderConfig();syncWidgetDefaults();}catch(_){toast('Не удалось сохранить настройки на устройстве.');}}
function dateKey(d){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
function monday(d=new Date()){const m=new Date(d.getFullYear(),d.getMonth(),d.getDate(),12);m.setDate(m.getDate()-(m.getDay()+6)%7);return m;}
function dayIndex(d){return Math.floor(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())/86400000);}
function currentEven(d=new Date()){const a=state.anchorDate.split('-').map(Number);const anchor=new Date(a[0],a[1]-1,a[2],12);const diff=Math.floor((dayIndex(monday(d))-dayIndex(anchor))/7);return diff%2===0?state.anchorEven:!state.anchorEven;}
function parity(){return state.mode==='auto'?(currentEven(selectedDate())?'even':'odd'):state.mode;}
function campusGroups(){return state.data?state.data.groups.filter(g=>(g.source||'spk')===state.campus):[];}
function campusName(){return state.campus==='crk'?'ЦРК':'СПК';}
function sourceMeta(){return state.data?.sources?.[state.campus]||state.data||{};}
function indexCampus(){state.teachers=TeacherIndex.build({groups:campusGroups()});}
function updateCampusControls(){document.documentElement.dataset.campus=state.campus;document.querySelectorAll('.campus-switch [data-campus]').forEach(b=>{b.classList.toggle('active',b.dataset.campus===state.campus);b.setAttribute('aria-pressed',String(b.dataset.campus===state.campus));});}
function selectCampus(campus){if(!['spk','crk'].includes(campus))return;if(campus===state.campus){showPage('schedule');return;}const name=currentGroup()?.name;state.campusGroups[state.campus]=state.group;state.campus=campus;state.group=state.campusGroups[campus]||campusGroups().find(g=>g.name===name)?.id||'';state.teacherSelecting=true;state.teacherQuery='';indexCampus();state.page='schedule';persist();render('page');}
function currentGroup(){return state.data&&state.data.groups.find(g=>g.id===state.group);}
function currentTeacher(){const current=state.teachers.find(t=>t.id===state.teacher);if(current)return current;const changes=SpkChanges.forTeacher(changeHistory,state.teacher,TeacherIndex.key).filter(e=>(e.group.startsWith('crk:')?'crk':'spk')===state.campus);const previous=changes.find(e=>e.before);if(!previous)return null;return {id:state.teacher,name:previous.before.lessons[0].variants[0].teacher,groupCount:new Set(changes.map(e=>e.group)).size,weeks:{even:{},odd:{}}};}
function subgroup(){if(!state.subgroupsEnabled)return 0;return [1,2].includes(Number(state.subgroups[state.group]))?Number(state.subgroups[state.group]):0;}
function dark(){return state.theme==='dark'||state.theme==='auto'&&state.systemDark;}
function applyTheme(){syncWidgetDefaults();const root=document.documentElement;let d=dark();root.dataset.theme=d?'dark':'light';root.dataset.palette=state.palette;d=SpkAppearance.apply(d);$('themeToggle').innerHTML=icon(d?'sun':'moon');$('themeToggle').setAttribute('aria-label',d?'Включить светлую тему':'Включить тёмную тему');const background=getComputedStyle(root).getPropertyValue('--bg').trim();document.querySelector('meta[name="theme-color"]').content=background;if(native()){if(typeof College.themeColors==='function')College.themeColors(d,background);else College.theme(d);}}
function currentPalette(){return PALETTES.find(p=>p.id===state.palette)||PALETTES[0];}
function paletteSample(id){return '<span class="palette-sample" data-palette="'+id+'" aria-hidden="true"><span class="sample-top"><i></i><i></i><i></i></span><span class="sample-hero"><i></i><i></i></span><span class="sample-bottom"><i></i><span><i></i><i></i></span></span></span>';}
function renderPaletteSetting(){const p=currentPalette();return '<div class="palette-setting"><div class="palette-setting-heading"><h3>Цветовая схема</h3><span>'+PALETTES.length+' цветовых схем</span></div><button class="palette-summary" data-action="palette-choose" aria-label="Выбрать цветовую схему, сейчас '+esc(p.name)+'">'+paletteSample(p.id)+'<span class="palette-summary-text"><strong>'+esc(p.name)+'</strong><span>'+esc(p.description)+'</span><small>Выбрать другую схему</small></span>'+icon('chevron')+'</button><p class="palette-setting-note">Палитра подстраивается под светлую и тёмную тему.</p></div>';}
function updatePaletteSelection(){document.querySelectorAll('[data-palette-choice]').forEach(b=>{const selected=b.dataset.paletteChoice===state.palette;b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));});$('paletteSelection').textContent='Выбрана: '+currentPalette().name;}
function renderPaletteList(){
 const choices=PALETTES.filter(p=>state.paletteFilter==='all'||(state.paletteFilter==='classic'?!p.category:p.category===state.paletteFilter));
 document.querySelectorAll('[data-palette-filter]').forEach(b=>{const selected=b.dataset.paletteFilter===state.paletteFilter;b.classList.toggle('active',selected);b.setAttribute('aria-pressed',String(selected));});
 $('paletteList').innerHTML=choices.map(p=>'<button class="palette-choice" data-palette-choice="'+p.id+'" aria-label="'+esc(p.name)+': '+esc(p.description)+'" aria-pressed="false">'+paletteSample(p.id)+'<span class="palette-choice-name"><strong>'+esc(p.name)+'</strong><span class="palette-check">'+icon('check')+'</span></span><span class="palette-description">'+esc(p.description)+'</span></button>').join('');
 updatePaletteSelection();
}
function openPaletteChooser(){
 state.paletteFilter=currentPalette().category==='neon'?'neon':'all';renderPaletteList();
 $('paletteHint').textContent=PALETTES.length+' цветовых схем, из них '+PALETTES.filter(p=>p.category==='neon').length+' неоновых. У каждой есть светлый и тёмный вариант.';
 SpkMotion.showModal($('paletteModal'));document.body.classList.add('modal-open');updatePaletteSelection();$('closePalette').focus();const selected=$('paletteList').querySelector('.selected');if(selected)selected.scrollIntoView({block:'nearest'});
}
function closePaletteChooser(){const wasOpen=!$('paletteModal').hidden;SpkMotion.hideModal($('paletteModal'),()=>{if(![...document.querySelectorAll('.modal')].some(m=>!m.hidden)){document.body.classList.remove('modal-open');if(wasOpen){const b=document.querySelector('[data-action="palette-choose"]');if(b)b.focus({preventScroll:true});}}});}
function setPalette(id){if(!PALETTES.some(p=>p.id===id))return;SpkAppearance.disable();state.palette=id;persist();applyTheme();if(state.page==='settings')render();updatePaletteSelection();}
function motionHint(){return !state.animations?'Выключены. Интерфейс меняется сразу.':SpkMotion.reduced()?'Система ограничивает анимации. Они вернутся после изменения системной настройки.':'Скользящее выделение, появление пар слева и переливание неоновых градиентов.';}
function updateMotionHint(){const note=$('motionHint');if(note)note.textContent=motionHint();}
function applyMotion(){SpkMotion.setEnabled(state.animations);try{if(native()&&typeof College.areAnimationsEnabled==='function')SpkMotion.setSystemAllowed(College.areAnimationsEnabled());}catch(_){}updateMotionHint();}
function toggleAnimations(){state.animations=!state.animations;persist(false);applyMotion();render();const button=document.querySelector('[data-action="animations-toggle"]');if(button)button.focus({preventScroll:true});}
function renderMotionSetting(){return '<div class="motion-setting"><div class="reminder-title"><h3 id="motionTitle">Плавные анимации</h3><button class="reminder-switch '+(state.animations?'on':'')+'" data-action="animations-toggle" role="switch" aria-checked="'+state.animations+'" aria-labelledby="motionTitle" aria-describedby="motionHint"><span></span></button></div><p class="motion-setting-note" id="motionHint">'+esc(motionHint())+'</p></div>';}
window.onSystemMotionChanged=enabled=>SpkMotion.setSystemAllowed(enabled);
window.onMotionVisibility=visible=>{SpkMotion.setNativeVisible(visible);clockVisible=!!visible;refreshClock();};
document.addEventListener('spkmotionchange',updateMotionHint);
function syncHaptics(){try{if(native()&&typeof College.setHapticsEnabled==='function')College.setHapticsEnabled(state.haptics);}catch(_){}}
function haptic(action='tap'){if(!state.haptics)return;try{if(native()&&typeof College.haptic==='function')College.haptic(action);}catch(_){}}
function toggleHaptics(){state.haptics=!state.haptics;persist(false);syncHaptics();render();if(state.haptics)haptic('confirm');const button=document.querySelector('[data-action="haptics-toggle"]');if(button)button.focus({preventScroll:true});}
function renderHapticsSetting(){return '<section class="settings-card"><div class="reminder-title"><h3 id="hapticsTitle">Тактильный отклик</h3><button class="reminder-switch '+(state.haptics?'on':'')+'" data-action="haptics-toggle" role="switch" aria-checked="'+state.haptics+'" aria-labelledby="hapticsTitle" aria-describedby="hapticsHint"><span></span></button></div><p id="hapticsHint">Лёгкая вибрация при выборе дня, группы, темы и других действиях.</p><p class="haptics-note">'+(state.haptics?'Включён. Учитывает системную настройку вибрации при касании.':'Выключен. Можно включить в любой момент.')+'</p></section>';}
// A single capture listener runs before controls re-render. Scripted updates stay silent.
document.addEventListener('click',e=>{
 if(!e.isTrusted||!state.haptics)return;
 const b=e.target.closest('button, summary');if(!b||b.disabled||b.getAttribute('aria-disabled')==='true'||b.dataset.action==='haptics-toggle')return;
 if(b.dataset.page===state.page&&(!b.dataset.campus||b.dataset.campus===state.campus)||b.dataset.paletteChoice===state.palette||b.dataset.themeChoice===state.theme||b.dataset.paletteFilter===state.paletteFilter)return;
 if(b.dataset.day!==undefined&&Number(b.dataset.day)===state.day)return;
 if(b.dataset.subgroup!==undefined&&Number(b.dataset.subgroup)===subgroup())return;
 if(b.dataset.reminderSubgroup!==undefined&&Number(b.dataset.reminderSubgroup)===state.reminder.subgroup)return;
 if(b.dataset.parity===state.mode)return;
 if(b.id==='filterAll'&&!state.onlyFavorites||b.id==='filterFavorites'&&state.onlyFavorites)return;
 const selection=b.matches('[data-day],[data-parity],[data-subgroup],[data-theme-choice],[data-palette-choice],[data-palette-filter],[data-group],[data-teacher],[data-reminder-subgroup],[data-anchor]');
 haptic(b.dataset.favorite?'confirm':selection?'selection':'tap');
},true);
function setTheme(theme){state.theme=theme;if(theme==='auto')state.systemDark=systemTheme();persist();applyTheme();if(state.page==='settings')render();}
window.onSystemThemeChanged=function(darkMode){state.systemDark=!!darkMode;applyTheme();};
window.onReminderState=function(s){state.reminder=reminderState(s);state.reminderPending=false;state.reminderMessage=s.message||'';persist(false);if(state.page==='settings')render();if(s.message)toast(s.message);};
window.onReminderTest=function(message){state.reminderTestPending=false;if(state.page==='settings')render();toast(message);};
async function toggleReminder(){
  if(state.reminderPending)return;
  if(!state.reminder.group||!state.data?.groups.some(g=>g.id===state.reminder.group)){
    toast('Сначала выберите группу для уведомлений.');return;
  }
  state.reminderPending=true;render();
  try{
    const active=await PwaPush.toggle({
      enabled:!state.reminder.enabled,
      group:state.reminder.group,subgroup:state.subgroupsEnabled?state.reminder.subgroup:0,
      hour:state.reminder.hour,minute:state.reminder.minute,
      anchorDate:state.anchorDate,anchorEven:state.anchorEven,
    });
    state.reminder.enabled=active;
    state.reminderMessage=active?'Уведомления включены.':'Уведомления выключены.';
    persist(false);toast(state.reminderMessage);
  }catch(e){state.reminderMessage=e.message;toast(e.message);}
  finally{state.reminderPending=false;render();}
}

function toast(msg,duration=2400){$('toast').textContent=msg;$('toast').classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.remove('show'),duration);}
function readChangeHistory(){try{return SpkChanges.restore(localStorage.getItem('spk.schedule-changes.v1'));}catch(_){return null;}}
function saveChangeHistory(){try{localStorage.setItem('spk.schedule-changes.v1',JSON.stringify(changeHistory));}catch(_){}}
function acceptScheduleChanges(data){changeHistory=SpkChanges.update(changeHistory,data);saveChangeHistory();}
function scopedChanges(){if(state.page==='explore')return [];return state.page==='teachers'?SpkChanges.forTeacher(changeHistory,state.teacher,TeacherIndex.key).filter(e=>(e.group.startsWith('crk:')?'crk':'spk')===state.campus):SpkChanges.forGroup(changeHistory,state.group,subgroup());}
function dayChanges(){return scopedChanges().filter(e=>e.week===parity()&&e.day===state.day);}
function changeCount(n){return n+' '+(n%10===1&&n%100!==11?'изменение':n%10>=2&&n%10<=4&&(n%100<12||n%100>14)?'изменения':'изменений');}
function renderChangesSummary(){const changes=scopedChanges();if(!changes.length)return '';const recent=Math.max(...changes.map(e=>e.at));return '<section class="schedule-changes" role="status" aria-label="Изменения расписания"><div class="changes-heading">'+icon('refresh')+'<div><strong>'+changeCount(changes.length)+' в расписании</strong><p>После обновления '+esc(timestamp(recent))+'</p></div></div><p class="changes-explanation">Отмечены новые и изменённые пары. Убранные занятия показаны отдельно.</p><div class="changes-actions"><button class="text-button" data-action="changes-show">К изменениям '+icon('arrow')+'</button><button class="text-button" data-action="changes-ack" aria-label="Убрать просмотренные отметки изменений">Понятно</button></div></section>';}
function showScheduleChanges(){const changes=scopedChanges(),first=changes.find(e=>e.week===parity()&&e.day===state.day)||changes.find(e=>e.week===parity())||changes[0];if(!first)return;state.day=first.day;state.mode=first.week===(currentEven(selectedDate())?'even':'odd')?'auto':first.week;render('day');const results=document.querySelector('.timetable-results');if(results)results.scrollIntoView({block:'start',behavior:SpkMotion.enabled()?'smooth':'auto'});}
function acknowledgeChanges(){changeHistory=SpkChanges.acknowledge(changeHistory,scopedChanges().map(e=>e.key));saveChangeHistory();render();toast('Отметки этого расписания убраны');}
function renderChangeDetails(changes){const edited=changes.filter(e=>e.kind==='edited');if(!edited.length)return '';const id=JSON.stringify(edited.map(e=>e.key)),opened=[...document.querySelectorAll('.change-details[open]')].some(el=>el.dataset.changeId===id);return '<details class="change-details" data-change-id="'+esc(id)+'"'+(opened?' open':'')+'><summary>Что изменилось</summary>'+edited.map(e=>(state.page==='teachers'?'<p class="change-group">'+esc(e.groupName)+'</p>':'')+SpkChanges.details(e).map(line=>'<div class="change-field"><strong>'+esc(line.label)+'</strong><span class="change-before">Было: '+esc(line.before)+'</span><span class="change-after">Стало: '+esc(line.after)+'</span></div>').join('')).join('')+'</details>';}
function renderRemovedLessons(){const removed=dayChanges().filter(e=>e.kind==='removed');if(!removed.length)return '';return '<section class="removed-lessons" aria-label="Убранные занятия"><h3>Больше нет в расписании</h3><p class="removed-note">Эти занятия были в предыдущей версии таблицы.</p>'+removed.map(e=>'<article class="removed-lesson" data-change-kind="removed"><div class="removed-heading"><span class="change-badge removed">Убрано</span><strong>'+e.number+' пара'+(state.page==='teachers'?' · '+esc(e.groupName):'')+'</strong></div><p>'+esc(SpkChanges.describeSlot(e.before))+'</p></article>').join('')+'</section>';}

function timestamp(ms){if(!ms)return 'Дата не указана';return new Date(ms).toLocaleString('ru-RU',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});}
function setStatus(){const box=$('status');box.className='status'+(state.loading||state.error?' visible':'')+(state.error&&!state.loading?' error':'');box.textContent=state.loading?'Обновляем расписание с сайта колледжа…':state.error?'Не удалось обновить. '+state.error+(state.data?' Доступна сохранённая версия от '+timestamp(state.data.fetchedAt)+'.':''):'';$('refreshTop').classList.toggle('spinning',state.loading);$('refreshTop').disabled=state.loading;}
function dataValid(d){return d&&d.schema===1&&Array.isArray(d.groups)&&d.groups.length>0&&d.groups.every(g=>typeof g.id==='string'&&g.weeks&&g.weeks.even&&g.weeks.odd);}
window.onScheduleData=function(d){if(!dataValid(d)){window.onScheduleStatus({error:'Получен неизвестный формат расписания.'});return;}const firstLoad=!state.data;acceptScheduleChanges(d);state.data=d;plannerIndex=SpkPlanner.build(d);indexCampus();state.error='';if(!state.reminder.group&&currentGroup()){state.reminder.group=state.group;state.reminder.subgroup=subgroup();persist();}syncReminderConfig();syncWidgetDefaults();render(firstLoad?'page':'');if(!$('modal').hidden)renderChooser();window.onNotificationOpen();window.onScheduleLink();};
window.onScheduleStatus=function(s){state.loading=!!s.loading;if(s.error)state.error=s.error;else if(s.ok)state.error='';setStatus();if(s.ok||s.error){const n=SpkSourceStatus.notice(state.data,!!s.error);toast(n.text,n.duration);}if(state.page==='settings')render();};
async function refresh(){if(!state.loading)await checkSchedule(true);}
window.onAppResume=function(){SpkUpdater.resume();clockVisible=true;refreshClock();SpkMotion.setNativeVisible(true);applyMotion();state.systemDark=systemTheme();applyTheme();if(state.data&&!document.body.classList.contains('modal-open')&&state.page!=='settings')render();checkSchedule();};
window.onNotificationOpen=function(){
 if(!state.data||!native()||typeof College.consumeReminderOpen!=='function')return;
 try{const raw=College.consumeReminderOpen();if(!raw)return;const target=JSON.parse(raw),date=new Date(target.date+'T12:00:00');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(target.date)||isNaN(date.getTime())||dateKey(date)!==target.date)return;
  if(!state.data.groups.some(g=>g.id===target.group)){toast('Группа из уведомления не найдена. Обновите расписание.');return;}
  state.group=target.group;state.campus=state.group.startsWith('crk:')?'crk':'spk';state.campusGroups[state.campus]=state.group;indexCampus();state.subgroups[target.group]=[1,2].includes(target.subgroup)?target.subgroup:0;state.day=(date.getDay()+6)%7;
  state.weekDate=dateKey(monday(date));state.mode='auto';state.page='schedule';persist();closeNavigationDialogs();render();window.scrollTo(0,0);
 }catch(_){}
};
function showPage(page){if(state.page===page)return;state.page=page;render('page');}
function favorite(id){const i=state.favorites.indexOf(id);if(i>=0)state.favorites.splice(i,1);else state.favorites.push(id);persist();render();if(!$('modal').hidden)renderChooser();document.querySelectorAll('[data-favorite]').forEach(b=>{if(b.dataset.favorite===id)SpkMotion.pulse(b.querySelector('svg'));});toast(i>=0?'Группа удалена из избранного':'Группа добавлена в избранное');}
function chooseGroup(id,viewSubgroup){if(state.chooserPurpose==='reminder'&&!$('modal').hidden){state.reminder.group=id;state.reminder.subgroup=[1,2].includes(Number(state.subgroups[id]))?Number(state.subgroups[id]):0;closeChooser();persist();render();return;}state.group=id;state.campus=id.startsWith('crk:')?'crk':'spk';state.campusGroups[state.campus]=id;indexCampus();state.page='schedule';if(viewSubgroup!==undefined)state.subgroups[id]=Number(viewSubgroup);if(!state.reminder.group){state.reminder.group=id;state.reminder.subgroup=subgroup();}persist();closeChooser();render('page');}
function chooseTeacher(id){state.teacher=id;state.teacherSelecting=false;state.page='teachers';persist();render('page');}
function openTeacherSearch(){openSmartSearch('teacher');}
function openChooser(purpose='group'){openSmartSearch('group',purpose);}
function closeChooser(){closeSearchFilters(false);const wasOpen=!$('modal').hidden;const purpose=state.chooserPurpose;state.chooserPurpose='group';$('groupSearch').blur();SpkMotion.hideModal($('modal'),()=>{$('groupList').innerHTML='';if(![...document.querySelectorAll('.modal')].some(m=>!m.hidden)){document.body.classList.remove('modal-open');if(wasOpen){const b=document.querySelector(purpose==='reminder'?'[data-action="reminder-group"]':'[data-action="choose"]');if(b)b.focus({preventScroll:true});}}});}
function searchKey(s){return String(s).toUpperCase().replace(/[\s-]/g,'').replace(/Ё/g,'Е');}
function renderChooser(){renderSmartSearch();}
function sourceFooter(){const meta=sourceMeta(),entries=state.campus==='crk'?(state.data?.unassignedEntries||[]):[];return '<div class="footer-note">Расписание '+campusName()+' · spospk.ru<br>Сохранено '+esc(timestamp(meta.fetchedAt))+(meta.error?'<br>'+esc(meta.error):'')+'</div>'+(entries.length?'<details class="unassigned-source"><summary>Записи без учебной группы · '+entries.length+'</summary><p>Эти записи сохранены отдельно и не добавлены к парам вашей группы.</p>'+entries.map(e=>'<article><strong>'+esc(e.text)+'</strong><p>'+esc((e.week==='even'?'Чётная':'Нечётная')+' · '+DAYS[e.day]+' · '+e.time+' · '+e.room)+'</p>'+(e.needsReview?'<small>Требует проверки по исходной таблице.</small>':'')+'</article>').join('')+'</details>':'');}
function welcome(){return '<section class="hero welcome"><div class="eyebrow">ВСЁ К СЛЕДУЮЩЕЙ ПАРЕ</div><h1>Ваш учебный день.<br>В одном месте.</h1><p>Выберите группу — здесь появятся занятия, время пар и аудитории.</p><button class="button-primary" data-action="choose">Выбрать группу '+icon('arrow')+'</button></section><div class="intro-points"><div class="intro-point">'+icon('calendar')+'Чётная и нечётная недели</div><div class="intro-point">'+icon('star')+'Любимые группы всегда рядом</div><div class="intro-point">'+icon('wifi')+'Сохранённое расписание без интернета</div></div>'+sourceFooter();}
function filteredLessons(g){const day=g.weeks[parity()][String(state.day)]||[];return day.map(l=>Object.assign({},l,{variants:l.variants.filter(v=>!subgroup()||v.subgroup===0||v.subgroup===subgroup())})).filter(l=>l.variants.length);}
function lessonCount(n){return n+' '+(n%10===1&&n%100!==11?'пара':n%10>=2&&n%10<=4&&(n%100<12||n%100>14)?'пары':'пар');}
function viewingToday(now=new Date()){return state.mode==='auto'&&dateKey(selectedDate())===dateKey(now);}
function visibleLessons(){
 if(state.page==='explore')return SpkPlanner.lessons(state.data,state.explore,parity(),state.day);
 if(state.page==='schedule'){const g=currentGroup();return g?filteredLessons(g):[];}
 if(state.page==='teachers'&&!state.teacherSelecting){const t=currentTeacher();return t?t.weeks[parity()][state.day]||[]:[];}
 return [];
}
function liveContext(){return [dateKey(selectedDate()),state.page,state.page==='teachers'?state.teacher:state.page==='explore'?state.explore?.id:state.group,state.day,parity(),subgroup()].join('|');}
function liveLessonDetails(lessons){
 return lessons.map(l=>'<div class="now-slot">'+l.variants.map(v=>{
  const detail=[];
  if(v.room)detail.push(/онлайн/i.test(v.room)?v.room:'Ауд. '+v.room);
  if(Array.isArray(v.groups))detail.push(v.groups.map(g=>g.name).join(', '));
  else if(state.subgroupsEnabled&&v.subgroup)detail.push(v.subgroup+' подгруппа');
  return '<div class="now-variant"><p class="now-subject">'+esc(v.subject)+'</p>'+(detail.length?'<p class="now-detail">'+esc(detail.join(' · '))+'</p>':'')+'</div>';
 }).join('')+'</div>').join('');
}
function nowNextBody(model){
 let title='',description='',body='';
 if(model.kind==='live'){
  title=model.current.length===1?'Идёт '+model.current[0].number+'-я пара':'Идут занятия';
  description='До конца '+SpkTimetable.duration(model.remaining);
  body=liveLessonDetails(model.current)+'<progress class="now-progress" aria-label="Прошедшая часть пары" max="100" value="'+model.progress+'">'+model.progress+'%</progress>';
 }else if(model.kind==='before'){title='До первой пары';description=SpkTimetable.duration(model.remaining);}
 else if(model.kind==='break'){title='Перемена';description='До пары '+SpkTimetable.duration(model.remaining);}
 else if(model.kind==='done'){title='На сегодня всё';body='<p class="now-message">Последняя пара закончилась в '+esc(model.end)+'.</p>';}
 else if(model.kind==='empty'){title='Сегодня без пар';body='<p class="now-message">Для выбранного расписания занятий не указано.</p>';}
 else{title='Уточните время занятий';body='<p class="now-message">В сохранённом расписании не хватает времени для отсчёта.</p>';}
 if(model.next.length)body+='<div class="now-upcoming"><p class="now-next-label">'+(model.kind==='live'?'Далее':'Следующая пара')+' · '+esc(model.next[0].start)+'</p>'+liveLessonDetails(model.next)+'</div>';
 else if(model.kind==='live')body+='<p class="now-last">Последняя пара на сегодня</p>';
 return '<div class="now-kicker"><span class="dot"></span> Сейчас и далее <span class="now-clock">Время телефона</span></div><div class="now-status"><h3>'+esc(title)+'</h3>'+(description?'<span class="now-countdown">'+esc(description)+'</span>':'')+'</div>'+body;
}
function renderNowNext(lessons,now=new Date()){
 if(!viewingToday(now))return '';
 const model=SpkTimetable.daily(lessons,now);
 return '<section class="now-next" data-live-context="'+esc(liveContext())+'" data-live-state="'+model.kind+'" aria-label="Сейчас и далее">'+nowNextBody(model)+'</section>';
}
function updateLive(now=new Date()){
 const panel=document.querySelector('.now-next');
 if(!panel||!viewingToday(now)||panel.dataset.liveContext!==liveContext())return;
 const model=SpkTimetable.daily(visibleLessons(),now),html=nowNextBody(model);
 panel.dataset.liveState=model.kind;if(panel.innerHTML!==html)panel.innerHTML=html;
 panel.closest('.timetable-results').querySelectorAll('.lesson').forEach(row=>{
  const active=SpkTimetable.isLive({start:row.dataset.start,end:row.dataset.end},now),card=row.querySelector('.lesson-card'),badge=card.querySelector('.live');
  card.classList.toggle('live-card',active);
  if(!active&&badge)badge.remove();
  if(active&&!badge){const tag=document.createElement('span');tag.className='live';tag.textContent='Идёт сейчас';card.querySelector('.lesson-meta').appendChild(tag);}
 });
}
function refreshClock(){
 clearTimeout(clockTimer);clockTimer=null;if(!clockVisible||document.hidden)return;
 const now=new Date(),date=dateKey(now);
 if(date!==lastDate){const follow=state.mode==='auto'&&dateKey(selectedDate())===lastDate;lastDate=date;if(follow){state.weekDate=dateKey(monday(now));state.day=(now.getDay()+6)%7;}if(state.data)render();}
 updateLive(now);clockTimer=setTimeout(refreshClock,60000-Date.now()%60000+25);
}
function selectDay(day,motion='day'){if(day===state.day||day<0||day>6)return false;state.day=day;render(motion);return true;}
document.addEventListener('spkresultschange',()=>updateLive());
document.addEventListener('visibilitychange',refreshClock);
function timetableView(key,controls,results){return '<div class="timetable-view" data-timetable-key="'+esc(key)+'"><div class="timetable-controls">'+controls+'</div><div class="timetable-viewport"><section class="timetable-results" aria-label="Занятия">'+results+'</section></div></div>';}
function renderDayControls(){
 const m=monday(selectedDate()),changes=scopedChanges().filter(e=>e.week===parity());
 let html='<div class="section-row"><div class="section-label">Учебная неделя</div>'+(state.mode==='auto'&&viewingToday()?'<span class="week-mode"><span class="dot"></span> Автоматически</span>':'<button class="text-button" data-action="now">'+icon('refresh')+' '+(state.mode==='auto'?'Сегодня':'Сейчас')+'</button>')+'</div><div class="week-tabs" data-slider="week" role="group" aria-label="Чётность недели">'+['even','odd'].map(p=>'<button data-parity="'+p+'" class="'+(parity()===p?'active':'')+'" aria-pressed="'+(parity()===p)+'"><span class="week-dot"></span>'+(p==='even'?'Чётная':'Нечётная')+'</button>').join('')+'</div>';
 return plannerToolbar()+html+'<div class="days" data-slider="day" role="group" aria-label="Дни недели">'+SHORT.map((d,i)=>{const date=new Date(m);date.setDate(m.getDate()+i);const count=changes.filter(e=>e.day===i).length;return '<button data-day="'+i+'" aria-label="'+DAYS[i]+(count?', '+changeCount(count):'')+'" aria-pressed="'+(state.day===i)+'" class="day '+(i>4?'weekend ':'')+(i===state.day?'active ':'')+(dateKey(date)===dateKey(new Date())?'today':'')+'"><span>'+d+'</span><strong>'+date.getDate()+'</strong>'+(count?'<i class="day-change-dot" aria-hidden="true"></i>':'')+'</button>';}).join('')+'</div><p class="swipe-tip">Свайп: влево — следующий день, вправо — предыдущий</p>';
}
function renderDayHeading(count){
 const chosen=selectedDate(),isToday=viewingToday(),label=chosen.toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'})+(isToday?' · сегодня':'')+(state.mode!=='auto'?' · '+(parity()==='even'?'чётная':'нечётная')+' вручную':'');
 return '<div class="day-heading"><div><h2>'+DAYS[state.day]+'</h2><div class="day-date">'+esc(label)+'</div></div><span class="count-label">'+lessonCount(count)+'</span></div>';
}
function roomTag(room){return room?'<span class="tag room">'+icon('room')+(/онлайн/i.test(room)?esc(room):'Ауд. '+esc(room))+'</span>':'';}
function renderCards(lessons,variantHtml){
 const now=new Date(),isToday=viewingToday(now),changes=dayChanges(),teacher=state.page==='teachers';
 return '<div class="lessons">'+lessons.map(l=>{const live=isToday&&SpkTimetable.isLive(l,now),marked=SpkChanges.forLesson(changes,l,teacher),kind=marked.some(e=>e.kind==='edited')?'edited':marked.length?'added':'';
  return '<article class="lesson" data-start="'+esc(l.start)+'" data-end="'+esc(l.end)+'"'+(kind?' data-change-kind="'+kind+'"':'')+'><div class="time-col"><div class="lesson-number">'+l.number+'</div><div class="start-time">'+esc(l.start)+'</div><div class="end-time">'+esc(l.end)+'</div><div class="timeline-line"></div></div><div class="lesson-card '+(live?'live-card':'')+'"><div class="lesson-meta"><span class="pair-num">'+l.number+' ПАРА</span>'+(live?'<span class="live">Идёт сейчас</span>':'')+'</div>'+(kind?'<span class="change-badge '+kind+'">'+(kind==='added'?'Добавлено':'Изменено')+'</span>':'')+l.variants.map(variantHtml).join('')+renderChangeDetails(marked)+'</div></article>';
 }).join('')+'</div>';
}
function emptyDay(message){return '<div class="empty"><div class="empty-icon">'+icon('calendar')+'</div><h3>Занятий нет</h3><p>'+message+'</p></div>';}
function renderSchedule(){
 const g=currentGroup();if(!g)return welcome();const lessons=filteredLessons(g);
 let html='<section class="hero"><div class="hero-row"><div><div class="eyebrow">МОЯ ГРУППА</div><button class="group-title-button" data-action="choose" aria-label="Сменить группу"><h1>'+esc(g.name)+'</h1>'+icon('chevron')+'</button></div><button class="icon-button '+(state.favorites.includes(g.id)?'favorited':'')+'" data-favorite="'+esc(g.id)+'" aria-label="'+(state.favorites.includes(g.id)?'Удалить группу из избранного':'Добавить группу в избранное')+'" aria-pressed="'+state.favorites.includes(g.id)+'">'+icon('star')+'</button></div><div class="hero-bottom"><span class="sub-label">Подгруппа</span><div class="sub-tabs" data-slider="subgroup" role="group" aria-label="Подгруппа">'+[0,1,2].map(n=>'<button data-subgroup="'+n+'" class="'+(subgroup()===n?'active':'')+'" aria-pressed="'+(subgroup()===n)+'">'+(n===0?'Все':n)+'</button>').join('')+'</div></div></section>';
 html+=renderDayControls();const controls=html;html=renderChangesSummary()+renderDayHeading(lessons.length)+renderNowNext(lessons)+renderCards(lessons,v=>'<div class="variant"><h3 class="subject">'+esc(v.subject)+'</h3>'+(v.teacher?'<div class="teacher">'+icon('user')+'<span>'+esc(v.teacher)+'</span></div>':'')+'<div class="lesson-tags">'+roomTag(v.room)+(state.subgroupsEnabled?'<span class="tag">'+(v.subgroup===0?'Вся группа':v.subgroup+' подгруппа')+'</span>':'')+'</div></div>');
 if(!lessons.length)html+=emptyDay('В выбранном расписании на этот день '+(subgroup()?'для выбранной подгруппы ':'')+'пары не указаны.');
 const notes=state.campus==='spk'&&state.day===0&&Array.isArray(state.data.mondayNotes)&&state.data.mondayNotes.length?'<details class="monday-events"><summary>Перед первой парой</summary>'+state.data.mondayNotes.map(n=>'<p>'+esc(n)+'</p>').join('')+'<small>Общие объявления из заголовка таблицы. Для «Разговоров о важном» указаны два времени без привязки к группе.</small></details>':'';
 return timetableView('group:'+g.id,controls,html+renderRemovedLessons()+notes+sourceFooter());
}
function renderReminderStatus(){
 const r=state.reminder;
 let status=!r.enabled?'Уведомления выключены.':!r.allowed?'Уведомления приостановлены: разрешите их в Android.':!r.exact?'Уведомления приостановлены: разрешите точное время.':r.scheduleError||(!r.nextAt?'Таймер пока не установлен. Выключите и снова включите уведомления.':'Следующее уведомление: '+timestamp(r.nextAt));
 return '<div class="reminder-status" role="status"><p class="reminder-next">'+esc(status)+'</p>'+(r.testAt?'<p class="reminder-test-status">Проверка по таймеру: '+esc(timestamp(r.testAt))+'. Можно закрыть приложение.</p>':'')+(r.lastResult?'<p class="reminder-last">'+esc(timestamp(r.lastResultAt))+' · '+esc(r.lastResult)+'</p>':'')+(r.restricted?'<p class="reminder-message">Android ограничивает фоновую работу приложения. Разрешите её в настройках батареи.</p>':'')+'</div><details class="reminder-help"><summary>Если уведомление не пришло</summary><p>Проверьте разрешение уведомлений и доступ «Будильники и напоминания». В настройках батареи приложения выберите режим без ограничений. После принудительной остановки через настройки Android приложение нужно открыть снова.</p><button class="text-button" data-action="reminder-app-settings">Настройки приложения в Android</button></details>';
}
function renderReminderSettings(){return PwaPush.renderSettings(state,esc,icon);}
function groupCountLabel(n){return n+' '+(n%10===1&&n%100!==11?'группа':n%10>=2&&n%10<=4&&(n%100<12||n%100>14)?'группы':'групп');}
function teacherRows(teachers){return teachers.length?teachers.map((t,i)=>((i===0||teachers[i-1].name[0]!==t.name[0])?'<div class="teacher-letter">'+esc(t.name[0])+'</div>':'')+'<button class="teacher-pick" data-teacher="'+esc(t.id)+'"><span class="group-avatar">'+icon('user')+'</span><span class="teacher-result-text"><strong>'+esc(t.name)+'</strong><small>'+groupCountLabel(t.groupCount)+(t.id===state.teacher?' · выбран сейчас':'')+'</small></span>'+icon('arrow')+'</button>').join(''):'<div class="empty"><h3>Преподаватель не найден</h3><p>Введите часть фамилии или фамилию с инициалами, как в расписании.</p></div>';}
function updateTeacherResults(){const list=TeacherIndex.search(state.teachers,state.teacherQuery);$('teacherList').innerHTML=teacherRows(list);$('teacherMatches').textContent='Найдено: '+list.length;}
function renderTeachers(){
 const t=currentTeacher();
 if(!t||state.teacherSelecting){
  const found=TeacherIndex.search(state.teachers,state.teacherQuery);
  return '<div class="page-heading"><h1>Преподаватели</h1><p>Выберите преподавателя из списка или воспользуйтесь умным поиском.</p></div><button class="teacher-search-entry" data-action="teachers-choose">'+icon('search')+' Найти через умный поиск</button><div class="teacher-results-heading"><span id="teacherMatches">'+found.length+' преподавателей · '+campusName()+'</span>'+(t?'<button class="text-button" data-action="teacher-return">К расписанию</button>':'')+'</div><div id="teacherList">'+teacherRows(found)+'</div>'+sourceFooter();
 }
 const lessons=t.weeks[parity()][state.day]||[];
 let html='<section class="hero teacher-hero"><div class="eyebrow">ПРЕПОДАВАТЕЛЬ</div><button class="group-title-button teacher-title-button" data-action="teachers-choose" aria-label="Сменить преподавателя"><h1>'+esc(t.name)+'</h1>'+icon('chevron')+'</button><div class="hero-bottom"><span class="sub-label">Все группы преподавателя</span><span class="teacher-group-count">'+groupCountLabel(t.groupCount)+'</span></div></section>';
 html+=renderDayControls();const controls=html;html=renderChangesSummary()+renderDayHeading(lessons.length)+renderNowNext(lessons)+renderCards(lessons,v=>'<div class="variant"><h3 class="subject">'+esc(v.subject)+'</h3><div class="lesson-tags">'+roomTag(v.room)+'</div><div class="teacher-groups">'+v.groups.map(g=>{const all=g.subgroups.includes(0);const single=g.subgroups.length===1&&!all?g.subgroups[0]:0;return '<button class="teacher-group-button" data-group="'+esc(g.id)+'" data-view-subgroup="'+single+'" aria-label="Открыть расписание группы '+esc(g.name)+'"><span>'+esc(g.name)+'</span><small>'+(all?'Вся группа':g.subgroups.join(' и ')+' подгр.')+'</small>'+icon('arrow')+'</button>';}).join('')+'</div></div>');
 if(!lessons.length)html+=emptyDay('В выбранном расписании на этот день занятий у выбранного преподавателя не указано.');
 return timetableView('teacher:'+t.id,controls,html+renderRemovedLessons()+sourceFooter());
}
function renderFavorites(){const groups=campusGroups().filter(g=>state.favorites.includes(g.id));return '<div class="page-heading"><div class="eyebrow">БЫСТРЫЙ ДОСТУП</div><h1>Избранное</h1><p>Группы, которые вам нужны чаще всего.</p></div>'+(groups.length?groups.map(g=>'<div class="fav-card"><button class="fav-open" data-group="'+esc(g.id)+'"><strong>'+esc(g.name)+'</strong><small>Открыть расписание</small></button><button class="icon-button" data-favorite="'+esc(g.id)+'" aria-label="Удалить из избранного '+esc(g.name)+'">'+icon('star')+'</button></div>').join(''):'<div class="empty"><div class="empty-icon">'+icon('star')+'</div><h3>Сохраните свою группу</h3><p>Нажмите на звёздочку рядом с названием. Можно добавить несколько групп.</p></div>')+'<button class="button-primary" data-action="choose">'+icon('search')+' Найти группу</button>';}
function aboutFeature(name,title,body){return '<details class="about-feature"><summary><span class="about-feature-icon">'+icon(name)+'</span><span>'+title+'</span>'+icon('chevron')+'</summary><div class="about-feature-body">'+body+'</div></details>';}
function renderAbout(){return SpkUpdater.aboutCard()+'<div class="about-intro"><span class="about-app-icon">'+icon('calendar')+'</span><div><h3>Расписание СПК</h3><p>iPhone · версия 3.0.0 · Для учебных дней в Северске</p></div></div><p class="about-lead">Занятия, преподаватели и ближайшие пары — под рукой. Нажмите на раздел, чтобы узнать подробнее.</p>'+
 aboutFeature('calendar','Расписание и свайпы','<p>Выберите группу и день недели. В карточках указаны время, предмет, преподаватель и аудитория. Чётность недели меняется автоматически; при необходимости её можно выбрать вручную.</p><p>Свайп влево открывает следующий день, вправо — предыдущий. Можно нажать на день в календаре. Кнопка «Сегодня» возвращает к текущему дню, а «Сейчас» — к автоматическому режиму недели.</p>')+
 aboutFeature('share','Поделиться расписанием','<p>Нажмите «Поделиться» над расписанием. Выберите день или неделю и отправьте картинкой, текстом или ссылкой через меню «Поделиться» iPhone. Каждый день недели отправляется отдельной картинкой. Все пары сохраняются; длинный день разбивается на подписанные страницы. В «Оформить картинку» доступны цвета, стили и размер текста.</p><p>Ссылка открывает выбранное расписание по прежнему адресу приложения. Её также можно вставить в умный поиск. Для пересылки без интернета используйте картинку или текст.</p>')+
 aboutFeature('search','Умный поиск и календарь','<p>Одна строка ищет группы, преподавателей, предметы и кабинеты в СПК и ЦРК. Для предметов и кабинетов доступны занятия всех групп. Кнопка «Фильтры» открывает карточку параметров: категория, подразделение и избранное. «Применить» подтверждает выбор, а закрытие фильтра отменяет неподтверждённые изменения.</p><p>Кнопка с месяцем открывает календарь. Точки отмечают дни с занятиями. Выбор даты включает автоматическую чётность. Свайпы переходят через границы недель и месяцев; «Сегодня» возвращает к текущей дате. Будущие замены и праздники могут ещё не учитываться.</p>')+
 aboutFeature('user','Преподаватели и избранное','<p>В разделе «Преподаватели» найдите фамилию, чтобы увидеть занятия во всех группах. Нажатие на группу в карточке открывает её расписание.</p><p>Звёздочка добавляет группу в избранное. Можно сохранить несколько групп; выбранная подгруппа запоминается для каждой из них.</p>')+
 aboutFeature('book','Сейчас и далее','<p>На сегодняшнем дне в автоматическом режиме видны текущая и следующая пары, аудитория и оставшееся время. Во время перемены — время до следующей пары. После занятий приложение покажет, что учебный день завершён.</p>')+
 aboutFeature('refresh','Изменения расписания','<p>После обновления появляются метки «Добавлено» и «Изменено». Убранные занятия показываются отдельно, а дни с изменениями отмечаются точкой. Учитываются выбранная подгруппа и преподаватель.</p><p>Нажмите «Что изменилось», чтобы сравнить «Было / Стало». Кнопка «Понятно» убирает просмотренные отметки выбранного расписания. До этого они сохраняются и после перезапуска.</p><p>Первое загруженное расписание становится основой для сравнения. Изменения определяются по таблице колледжа: отдельные объявления о заменах сюда не входят. Исчезновение строки из таблицы само по себе не подтверждает отмену занятия.</p>')+
 aboutFeature('calendar','Пары на завтра','<p>В настройках можно добавить повторяющееся напоминание в Календарь iPhone. Оно предлагает открыть расписание; список пар в него не встроен.</p><p>Push при закрытом приложении работают только при подключённом сервере отправки. Состояние подключения показано в настройках.</p>')+
 aboutFeature('sun','Темы и анимации','<p>Светлая, тёмная и системная темы, '+PALETTES.length+' цветовые схемы, включая '+PALETTES.filter(p=>p.category==='neon').length+' неоновых. Палитра сохраняется при смене яркости.</p><p>Настройки → Оформление → Конструктор приложения: свой фон, акценты и градиент, скругление карточек, отступы и размер текста. Цвета светлого и тёмного режима настраиваются отдельно. «Сохранить» применяет дизайн, «Отмена» возвращает предыдущий. Выбор готовой палитры выключает собственный дизайн.</p><p>Скользящее выделение, появление пар и переливающиеся градиенты можно отключить в настройках. Приложение учитывает системное уменьшение движения.</p>')+
 aboutFeature('wifi','Обновление и работа без интернета','<p>Расписания СПК и ЦРК загружаются при открытии приложения из файлов rasp.xlsx и rasp_crk.xlsx. Для каждого источника своя сохранённая версия. В ЦРК, если предмет не указан в таблице, отображается «Занятие в ЦРК». Обновить его вручную можно кнопкой со стрелками. Последняя сохранённая таблица доступна без интернета, время её загрузки указано под расписанием.</p><p>Это личное приложение без рекламы и регистрации. Оно показывает основное расписание из файла колледжа.</p>');}
function openAbout(){
 $('aboutContent').innerHTML=renderAbout();$('aboutContent').scrollTop=0;
 SpkMotion.showModal($('aboutModal'));document.body.classList.add('modal-open');$('closeAbout').focus({preventScroll:true});
}
function closeAbout(){const wasOpen=!$('aboutModal').hidden;SpkMotion.hideModal($('aboutModal'),()=>{if(![...document.querySelectorAll('.modal')].some(m=>!m.hidden)){document.body.classList.remove('modal-open');if(wasOpen){const button=document.querySelector('[data-action="about"]');if(button)button.focus({preventScroll:true});}}});}
function renderAboutLink(){return '<button class="settings-card about-link" data-action="about" aria-haspopup="dialog"><span class="about-link-icon">'+icon('book')+'</span><span><strong>О приложении</strong><small>Возможности и подсказки</small></span>'+icon('arrow')+'</button>';}

function renderSettingsFull(){return '<div class="page-heading"><div class="eyebrow">КАК ВАМ УДОБНО</div><h1>Настройки</h1></div><section class="settings-card"><h3>Оформление</h3><p>Выберите тему приложения.</p><div class="theme-options">'+[['auto','screen','Как в системе'],['light','sun','Светлая'],['dark','moon','Тёмная']].map(v=>'<button class="theme-option '+(state.theme===v[0]?'active':'')+'" data-theme-choice="'+v[0]+'" aria-pressed="'+(state.theme===v[0])+'">'+icon(v[1])+'<span>'+v[2]+'</span></button>').join('')+'</div>'+renderPaletteSetting()+SpkAppearance.setting()+renderMotionSetting()+'</section>'+renderReminderSettings()+'<section class="settings-card"><h3>Параметры расписания</h3><button class="subgroups-setting" data-action="subgroups-toggle" role="switch" aria-checked="'+state.subgroupsEnabled+'"><span><strong>Учитывать подгруппы</strong><small>Сейчас отключено по умолчанию. Можно вернуть, если разделение возобновится.</small></span><b>'+(state.subgroupsEnabled?'Вкл.':'Выкл.')+'</b></button><h4>Чётность текущей недели</h4><p>Меняется автоматически каждый понедельник. Если колледж изменит порядок, укажите здесь правильную неделю.</p><div class="week-tabs">'+[['even','Чётная'],['odd','Нечётная']].map(v=>'<button data-anchor="'+v[0]+'" class="'+(currentEven()===(v[0]==='even')?'active':'')+'" aria-pressed="'+(currentEven()===(v[0]==='even'))+'">'+v[1]+'</button>').join('')+'</div><p class="source-detail">Исходная настройка: 19–25 октября 2026 — чётная неделя.</p></section><section class="settings-card"><h3>Расписание с сайта колледжа</h3><p>Обновляется при запуске приложения. Последняя загруженная версия доступна без интернета.</p><div class="source-url">www.spospk.ru/rasp.xlsx<br>www.spospk.ru/rasp_crk.xlsx</div><p class="source-detail">Сохранено: '+esc(timestamp(state.data.fetchedAt))+'</p><p class="source-detail">Групп в таблице: '+state.data.groups.length+'</p><div class="settings-row"><button class="button-primary" data-action="refresh" '+(state.loading?'disabled':'')+'>'+icon('refresh')+' Обновить</button><button class="text-button" data-action="source">Открыть файл '+icon('external')+'</button></div><p class="source-title">Это основное расписание из указанного файла. Отдельные объявления о заменах не включены.</p></section>'+renderAboutLink()+installBanner()+'<div class="settings-note">Расписание СПК · iPhone · версия 3.0.0<br>Личное приложение. Без рекламы и регистрации.</div>';}
function renderSettings(){
 const t=document.createElement('template');t.innerHTML=renderSettingsFull();
 const opened=new Set([...document.querySelectorAll('.settings-fold[open]')].map(n=>n.dataset.section));
 t.content.querySelectorAll('section.settings-card').forEach((section,i)=>{
  const title=section.querySelector('h3')?.textContent||'Параметры';const fold=document.createElement('details');fold.className='settings-fold';fold.dataset.section=String(i);fold.open=opened.has(String(i));
  fold.innerHTML='<summary>'+icon({'Оформление':'sun','Пары на завтра':'calendar','Параметры расписания':'calendar','Расписание с сайта колледжа':'refresh','Приложение на iPhone':'screen'}[title]||'settings')+'<span>'+esc(title)+'</span>'+icon('chevron')+'</summary>';
  section.replaceWith(fold);fold.append(section);
 });return t.innerHTML;
}
function render(motion=''){
 document.documentElement.dataset.screen=state.page;document.documentElement.dataset.subgroups=state.subgroupsEnabled?'on':'off';
 updateCampusControls();
 if(!state.data){$('content').innerHTML='<div class="empty"><div class="empty-icon">'+icon('calendar')+'</div><h3>Загружаем расписание</h3><p>Читаем сохранённую таблицу колледжа.</p><button class="button-primary" data-action="refresh">Повторить загрузку</button></div>';return;}
 const focused=document.activeElement&&document.activeElement.id==='teacherSearch';
 document.querySelectorAll('[data-page]').forEach(el=>{const active=el.dataset.page===state.page&&(!el.dataset.campus||el.dataset.campus===state.campus);el.classList.toggle('active',active);if(active)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current');});
 const html=state.page==='favorites'?renderFavorites():state.page==='settings'?renderSettings():state.page==='teachers'?renderTeachers():state.page==='explore'?renderExplore():renderSchedule();
 SpkMotion.replaceContent($('content'),html,motion,()=>{if(focused&&$('teacherSearch'))$('teacherSearch').focus({preventScroll:true});});
 setStatus();
}
window.handleBack=function(){if(closeWebDialogs())return true;if(!$('appearanceModal').hidden){SpkAppearance.close();return true;}if(!$('shareModal').hidden){if(!shareBusy&&$('shareDesigner').open){$('shareDesigner').open=false;$('shareDesigner').querySelector('summary').focus();}else closeShare();return true;}if(!$('plannerModal').hidden){closePlanner();return true;}if(!$('aboutModal').hidden){closeAbout();return true;}if(!$('paletteModal').hidden){closePaletteChooser();return true;}if(!$('modal').hidden){if(!$('searchFilterPanel').hidden)closeSearchFilters();else closeChooser();return true;}if(state.page==='teachers'&&state.teacherSelecting&&currentTeacher()){state.teacherSelecting=false;render('page');return true;}if(state.page!=='schedule'){showPage('schedule');return true;}return false;};
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||b.disabled)return;if(b.dataset.action==='subgroups-toggle'){state.subgroupsEnabled=!state.subgroupsEnabled;persist();render();}else if(b.dataset.action==='about')openAbout();else if(b.dataset.action==='changes-show')showScheduleChanges();else if(b.dataset.action==='changes-ack')acknowledgeChanges();else if(b.dataset.action==='haptics-toggle')toggleHaptics();else if(b.dataset.action==='animations-toggle')toggleAnimations();else if(b.dataset.paletteFilter){state.paletteFilter=b.dataset.paletteFilter;renderPaletteList();}else if(b.dataset.campus)selectCampus(b.dataset.campus);else if(b.dataset.page)showPage(b.dataset.page);else if(b.dataset.favorite)favorite(b.dataset.favorite);else if(b.dataset.teacher)chooseTeacher(b.dataset.teacher);else if(b.dataset.group)chooseGroup(b.dataset.group,b.dataset.viewSubgroup);else if(b.dataset.subgroup!==undefined){if(subgroup()===Number(b.dataset.subgroup))return;state.subgroups[state.group]=Number(b.dataset.subgroup);persist();render('day');}else if(b.dataset.parity){if(state.mode===b.dataset.parity)return;state.mode=b.dataset.parity;render('day');}else if(b.dataset.day!==undefined)selectDay(Number(b.dataset.day));else if(b.dataset.themeChoice)setTheme(b.dataset.themeChoice);else if(b.dataset.paletteChoice)setPalette(b.dataset.paletteChoice);else if(b.dataset.action==='palette-choose')openPaletteChooser();else if(b.dataset.anchor){state.anchorDate=dateKey(monday());state.anchorEven=b.dataset.anchor==='even';state.mode='auto';persist();render();toast('Чётность сохранена');}else if(b.dataset.action==='choose')openChooser();else if(b.dataset.action==='teachers-choose')openTeacherSearch();else if(b.dataset.action==='teacher-return'){state.teacherSelecting=false;render('page');}else if(b.dataset.action==='now'){setSelectedDate(new Date());}else if(b.dataset.action==='refresh')refresh();else if(b.dataset.action==='source'){if(native()&&typeof College.openScheduleSource==='function')College.openScheduleSource(state.campus);else window.open('http://www.spospk.ru/'+(state.campus==='crk'?'rasp_crk.xlsx':'rasp.xlsx'),'_blank','noopener,noreferrer');}});
document.addEventListener('input',e=>{if(e.target.id==='teacherSearch'){state.teacherQuery=e.target.value;updateTeacherResults();}});
document.addEventListener('change',e=>{if(e.target.id==='reminderTime'&&/^\d{2}:\d{2}$/.test(e.target.value)){const a=e.target.value.split(':').map(Number);if(a[0]<24&&a[1]<60){state.reminder.hour=a[0];state.reminder.minute=a[1];persist();render();}}});
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||b.disabled)return;
 if(b.dataset.action==='reminder-toggle')toggleReminder();
 else if(b.dataset.action==='reminder-group')openChooser('reminder');
 else if(b.dataset.reminderSubgroup!==undefined){state.reminder.subgroup=Number(b.dataset.reminderSubgroup);persist();render();}
 else if(b.dataset.action==='reminder-test')PwaPush.test().then(()=>toast('Проверочное уведомление отправлено')).catch(e=>toast(e.message,5200));
 else if(b.dataset.action==='reminder-calendar')PwaPush.downloadCalendar(state.reminder);
});
$('themeToggle').onclick=()=>setTheme(dark()?'light':'dark');$('refreshTop').innerHTML=icon('refresh');$('refreshTop').onclick=refresh;$('navCalendar').innerHTML=icon('calendar');$('navCrk').innerHTML=icon('screen');$('navTeachers').innerHTML=icon('user');$('navStar').innerHTML=icon('star');$('navSettings').innerHTML=icon('settings');$('closeModal').innerHTML=icon('close');$('searchIcon').innerHTML=icon('search');$('closeModal').onclick=closeChooser;document.querySelector('.scrim').onclick=closeChooser;$('groupSearch').oninput=()=>{searchLimit=80;renderChooser();};
$('closePalette').innerHTML=icon('close');$('closePalette').onclick=closePaletteChooser;$('paletteDone').onclick=closePaletteChooser;$('paletteScrim').onclick=closePaletteChooser;
$('closeAbout').innerHTML=icon('close');$('closeAbout').onclick=closeAbout;$('aboutDone').onclick=closeAbout;$('aboutScrim').onclick=closeAbout;
document.addEventListener('keydown',e=>{if(e.key==='Escape')window.handleBack();const dialog=!$('installModal').hidden?$('installModal'):!$('appearanceModal').hidden?$('appearanceModal'):!$('shareModal').hidden?$('shareModal'):!$('plannerModal').hidden?$('plannerModal'):!$('aboutModal').hidden?$('aboutModal'):!$('paletteModal').hidden?$('paletteModal'):!$('modal').hidden?$('modal'):null;if(e.key==='Tab'&&dialog){const all=[...dialog.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),a[href],summary,[tabindex="0"]')].filter(el=>el.getClientRects().length);const first=all[0],last=all[all.length-1];if(e.shiftKey&&document.activeElement===first){last.focus();e.preventDefault();}else if(!e.shiftKey&&document.activeElement===last){first.focus();e.preventDefault();}}});
const media=window.matchMedia('(prefers-color-scheme: dark)');const onMediaTheme=()=>{if(!native()||typeof College.isSystemDark!=='function')window.onSystemThemeChanged(media.matches);};if(media.addEventListener)media.addEventListener('change',onMediaTheme);else if(media.addListener)media.addListener(onMediaTheme);
SpkTimetable.bindSwipes($('content'),{
 allowed:()=>clockVisible&&!document.hidden&&$('modal').hidden&&$('paletteModal').hidden&&$('aboutModal').hidden&&!document.body.classList.contains('modal-open'),
 context:()=>liveContext(),
 onTap:day=>{if(selectDay(day))haptic('selection');},
 onStep:direction=>{if(setSelectedDate(SpkPlanner.add(selectedDate(),direction),direction>0?'swipe-next':'swipe-previous',state.mode==='auto'))haptic('selection');}
});
initPlanner();SpkAppearance.init();
refreshClock();
syncHaptics();applyMotion();applyTheme();render();SpkUpdater.init();
bootWebApp();

// Native state can change while the settings page is open (alarm / service / permissions).
setInterval(()=>{
 if(!native()||state.page!=='settings'||document.hidden||state.reminderPending||document.activeElement?.id==='reminderTime'||!$('modal').hidden)return;
 const r=readReminderState(state.reminder);
 if(JSON.stringify(r)!==JSON.stringify(state.reminder)){state.reminder=r;persist(false);render();}
},5000);
